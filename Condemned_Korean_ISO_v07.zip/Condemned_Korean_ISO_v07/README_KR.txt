﻿Condemned: Criminal Origins — 한글 ISO 패치 v0.7
한글화: 슬림쉐이디

사용 방법
1. ZIP을 폴더에 전부 압축 해제합니다.
2. RUN_ISO_PATCH.bat를 실행하고, 패치하지 않은 원본 ISO를 선택합니다.
3. 복사와 검사가 끝나면 원본 옆에 '원본이름_Korean_v07.iso'가 생깁니다.
4. Xenia에서 새 ISO를 엽니다. 콘솔 언어는 English 또는 Korean으로 설정합니다.

ISO를 RUN_ISO_PATCH.bat 위로 끌어다 놓아도 됩니다.
관리자 권한이나 별도 ISO 압축 해제/재생성 프로그램은 필요하지 않습니다.
원본 ISO가 있는 드라이브에 ISO 한 개 크기만큼의 여유 공간이 필요합니다.
작업 중 창을 닫지 말고 '완료!' 메시지까지 기다려 주세요.

어떤 원본이 필요한가요?
이전에 제공된 원본 파일과 일치하는 Xbox 360판 Condemned ISO가 대상입니다.
게임 실행 파일, Layer0 크기/원본 리소스, Layer1 리소스 충돌 여부를 검사합니다.
디스크 전체 이미지와 게임 파티션만 있는 XDVDFS 이미지의 알려진 배치를 인식합니다.
압축 파일, 분할 ISO, 암호화된 다른 컨테이너, 내용이 다른 게임 판본은 지원하지 않습니다.
기존 0.1~0.7 폴더 패치를 적용한 파일로 다시 만든 ISO에는 적용하지 마세요.
다른 판본이나 수정된 ISO는 강제로 적용하지 않고 중단합니다.

무엇이 들어 있나요?
현재 만족하신 v0.7의 번역·한글 폰트·UI 리소스를 그대로 사용합니다.
앞서 수정한 입력 안내의 특수 태그, 확인된 Dickenson 대사의 반말 처리,
메인 화면 오른쪽 위 '한글화: 슬림쉐이디' 표기가 포함됩니다.
ISO 내부 파일의 크기와 디스크 배치는 유지합니다.

검수 범위
식별된 캠페인 대사·문서·목표·메뉴의 번역 데이터는 포함되어 있습니다.
현재까지 사용자 테스트 화면과 리소스/설치 구조를 확인했습니다.
엔딩까지 실제 게임을 플레이하며 전수 검수한 상태는 아닙니다.
이번 ISO 패처는 실제 원본 리소스를 넣은 테스트용 ISO로 적용/보존/오류 거부를
검사했습니다. 사용자의 전체 게임 ISO로 Xenia 부팅까지 확인한 것은 아닙니다.
따라서 첫 실행에서 메인 화면과 기존 세이브 불러오기를 확인해 주세요.

원본과 복구
원본 ISO는 읽기 전용으로 열며 덮어쓰지 않습니다. 세이브 파일도 건드리지 않습니다.
원본으로 돌아가려면 Xenia에서 기존 ISO를 열면 됩니다.
결과 ISO와 같은 이름의 .patch-info.txt에는 원본/결과 파일의 SHA-256이 기록됩니다.
복사 후 전체 결과 ISO를 다시 읽어 해시를 검증한 뒤 최종 파일명으로 저장합니다.
이미 같은 결과 파일명이 있으면 덮어쓰지 않고 중단합니다.

오류가 나면
- 'Output already exists': 이전 결과 파일을 다른 곳으로 옮기거나 이름을 바꾸세요.
- 'already contains Korean ISO': 이미 이 ISO 패치를 적용한 파일입니다.
- 'Layer0 ... differs' / 'default.xex differs': 원본이 다르거나 이미 수정되었습니다.
- 'No compatible XDVDFS ...': 지원하는 Xbox 360 ISO 구조를 찾지 못했습니다.
- 'Insufficient free space': 출력 위치에 ISO 크기만큼의 공간이 필요합니다.
- 'payload ... mismatch': ZIP을 다시 내려받아 새 폴더에 압축 해제하세요.
오류 화면 또는 패치 폴더의 iso_patch_error.txt를 보내주시면 원인을 확인할 수 있습니다.
오류 기록에는 ISO 내용이나 계정 정보가 들어가지 않습니다.
강제로 창을 닫아 .partial-... 파일이 남았으면 실행이 끝난 것을 확인한 뒤 그 파일만
삭제할 수 있습니다. 정상 오류 처리 시에는 해당 임시 파일을 자동 삭제합니다.

다른 드라이브로 출력하는 방법 (선택 사항)
폴더에서 PowerShell을 열고 다음처럼 실행합니다.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\PatchISO.ps1 -IsoPath "D:\Games\Condemned.iso" -OutputPath "E:\Games\Condemned_Korean.iso"

파일 생성 없이 호환성만 검사하는 방법 (선택 사항)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\PatchISO.ps1 -IsoPath "D:\Games\Condemned.iso" -InspectOnly

환경
Windows 10/11의 Windows PowerShell 5.1을 대상으로 작성했습니다.
설치 로직 검증은 Linux PowerShell 7.4.6에서 수행했습니다.
Xenia에서 사용할 ISO를 만드는 패치입니다. 실기기 구동은 검증하지 않았습니다.
원본 게임 ISO, default.xex, 원본 아카이브는 패키지에 포함하지 않습니다.
폰트 라이선스: FONT_LICENSE.txt / Xenia 참조 라이선스: XENIA_LICENSE.txt
