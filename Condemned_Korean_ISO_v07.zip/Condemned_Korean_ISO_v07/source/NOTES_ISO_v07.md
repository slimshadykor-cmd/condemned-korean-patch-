# Condemned Korean ISO v0.7 implementation notes

The payloads are exactly the accepted v0.7 folder patch's three compressed files.
No translation or UI changes are introduced by this ISO packaging step.

## Container handling

The tool reads XDVDFS directly; it does not extract or rebuild the disc.
It probes partition bases 0, 0xFB20, 0x20600, 0x2080000 and 0xFD90000,
then checks the sector-32 media descriptor and bounded root directory tree.
The layout interpretation follows the primary Xenia source:
https://github.com/xenia-project/xenia/blob/master/src/xenia/vfs/devices/disc_image_device.cc

The supported Layer0 archive length is 1,452,989,910 bytes. Its original first
8 MiB SHA-256 is `108df9002fcad8e6cccc5d7606197abcdb55d2d478928cb5ea31b0d1b24f578b`.
The original executable SHA-256 is
`9d2dbd7a709b68f587e59564819315f3955585b91a533ddae241cc832da59fcf`.
These are resource/edition checks, not proof that an entire retail ISO is authentic.
Layer1 is also checked for resources that could override the translated assets.

## Same-size archive transformation

The original RATL v3 entries are big endian and explicitly store each resource's
offset, compressed size and uncompressed size. The region [85448, 6669716)
contains exactly 25 contiguous resource blobs. They are compacted into the same
region, with 16-byte alignment. Identical default and English string resources
(records 11 and 12) share one compressed payload. All other locale resources
remain byte-exact. No decoder state is shared: each directory entry points at
the complete same immutable compressed stream.

The compacted region has 52,807 trailing free bytes. The full Layer0 length,
ISO filesystem entries, executable, other archives and every byte after the
first 8 MiB of Layer0 remain unchanged. Prefix bytes outside the repack region
and the selected 25 directory records remain unchanged as well.

Patched prefix SHA-256:
`b201b397816b50b7ebe704bf4246a3e40d34a944468eea010f74fc0ef2ee4551`.

Only the relocation plan and translated compressed payloads are distributed.
The tool obtains all unmodified resource bytes from the user's own ISO.

## Write behavior

The input is opened read-only with a Windows sharing mode that denies writers.
A separate, uniquely named temporary output is created with CreateNew.
The copy loop hashes original bytes before substituting the prefix, then hashes
the exact bytes written. The complete output is flushed to disk and re-read to
verify its SHA-256, length and patched prefix. Only then is the temporary file
renamed to the final output name. File.Move never overwrites another file.
The source and any preexisting output are never deleted or modified.

## Validation and limits

`test_iso_patcher.py` uses the actual supplied 8 MiB prefix, executable and full
original archive length in synthetic sparse XDVDFS images. It does not shorten
the manifest's archive size to make tests pass. Tests include bare and partitioned
full-size archive copies; every byte outside the changed prefix is independently
compared to the source, and source/output hashes are independently verified.
All five known partition bases are checked. Wrong resources, malformed directory
trees/extents, conflicting Layer1 files, damaged patch payloads, existing output,
same input/output and repeated application must fail before producing output.

The source uses .NET Framework-compatible APIs, C# 5 syntax and PowerShell 5.1
syntax. Automated execution used Linux PowerShell 7.4.6. The Windows file dialog
and BAT launcher require Windows and were not executed in this environment.
No full retail ISO was available here, no Xenia boot of the newly packaged ISO
was performed, and no complete campaign/ending playthrough is claimed.

The user accepted v0.7's in-game visual quality before this ISO packaging work.
Translation coverage and runtime QA are separate: the supplied campaign text is
translated, but full runtime QA remains open. This archive compaction likewise
needs its first actual Xenia launch confirmation.
