"""Container/installer regression tests using real supplied resources in synthetic ISOs.
No complete retail disc is required or implied by these tests.

Usage: python test_iso_patcher.py PACKAGE PREFIX DEFAULT_ZIP PWSH TEST_DIRECTORY
Requires Python 3.8+, PowerShell 7 on Linux or Windows PowerShell 5.1.
Creates ~6 GB of temporary fixture/output data. The original files stay untouched.
"""
from pathlib import Path
import hashlib, json, os, shutil, struct, subprocess, sys, zipfile

PACKAGE, PREFIX, DEFAULT_ZIP, PWSH, WORK = map(lambda p: Path(p).resolve(), sys.argv[1:6])
WORK.mkdir(parents=True, exist_ok=False)
package = WORK/'package'
shutil.copytree(PACKAGE,package)
m=json.loads((package/'iso_manifest.json').read_text())
prefix=PREFIX.read_bytes()
with zipfile.ZipFile(DEFAULT_ZIP) as z: xex=z.read('default.xex')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(prefix)==m['original_prefix_sha256'] and sha(xex)==m['xex_sha256']
results=[]

def hash_file(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
    return h.hexdigest()

def fixture(name,base=0):
    path=WORK/name
    root=base+34*2048
    xex_at=base+64*2048
    l1_at=(xex_at+len(xex)+2047)//2048*2048
    # Round relative to the partition, which may have a non-sector-aligned base.
    l1_at=base+((l1_at-base+2047)//2048)*2048
    l0_at=l1_at+2048
    length=l0_at+m['original_size']+4096
    layer1=bytearray(49)
    struct.pack_into('>4sIIII',layer1,0,b'RATL',3,1,0,0)
    desc=bytearray(2048)
    desc[:20]=b'MICROSOFT*XBOX*MEDIA'
    desc[-20:]=b'MICROSOFT*XBOX*MEDIA'
    struct.pack_into('<II',desc,20,34,2048)
    table=bytearray(2048)
    for at,left,right,offset,size,nm in [(0,8,16,l0_at,m['original_size'],'Layer0.Arch00'),
        (32,0,0,xex_at,len(xex),'default.xex'),(64,0,0,l1_at,len(layer1),'Layer1.Arch00')]:
        encoded=nm.encode('ascii')
        struct.pack_into('<HHIIBB',table,at,left,right,(offset-base)//2048,size,0,len(encoded))
        table[at+14:at+14+len(encoded)]=encoded
    with path.open('wb') as f:
        f.truncate(length)
        for offset,data in [(base+65536,desc),(root,table),(xex_at,xex),(l1_at,layer1),(l0_at,prefix),
            (l0_at+100*1024*1024,b'PRESERVE-MIDDLE-DATA-\x81\xff'),
            (l0_at+m['original_size']-128,b'PRESERVE-END-OF-LAYER0'),(length-128,b'PRESERVE-DISC-TAIL')]:
            f.seek(offset);f.write(data)
    return dict(path=path,base=base,root=root,xex=xex_at,l1=l1_at,l0=l0_at,length=length)

def run(fix,outname,inspect=False,expect=None,source=None,output=None):
    src=Path(source) if source else fix['path']
    out=Path(output) if output else WORK/outname
    cmd=[str(PWSH),'-NoLogo','-NoProfile','-File',str(package/'PatchISO.ps1'),'-IsoPath',str(src),'-OutputPath',str(out)]
    if inspect:cmd.append('-InspectOnly')
    p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=300)
    (WORK/(outname+'.log')).write_text(p.stdout,encoding='utf-8')
    if expect:
        assert p.returncode!=0 and expect in p.stdout, p.stdout
    else:assert p.returncode==0,p.stdout
    assert not list(WORK.glob('*.partial-*'))
    return out,p.stdout

def verify_output(fix,out,original_hash):
    assert out.stat().st_size==fix['length']
    with fix['path'].open('rb') as a, out.open('rb') as b:
        a.seek(fix['l0']);old=a.read(len(prefix))
        b.seek(fix['l0']);new=b.read(len(prefix))
        assert old==prefix and sha(new)==m['patched_prefix_sha256']
        ns,folders,count=struct.unpack_from('>III',old,8)
        table=48+ns
        targets={11,12,769,770}
        for i in range(count):
            oe=struct.unpack_from('>IQQQI',old,table+32*i)
            ne=struct.unpack_from('>IQQQI',new,table+32*i)
            assert oe[0]==ne[0] and oe[4]==ne[4]
            if i not in targets and oe[1]+oe[2]<=len(prefix):
                assert old[oe[1]:oe[1]+oe[2]]==new[ne[1]:ne[1]+ne[2]],i
            if oe[1]>=m['region_end']:assert oe==ne
        for row in m['moves']:
            blob=new[row['destination']:row['destination']+row['size']]
            assert sha(blob)==row['sha256']
        # Independent byte-for-byte comparison of every byte outside the prefix.
        for begin,end in [(0,fix['l0']),(fix['l0']+len(prefix),fix['length'])]:
            a.seek(begin);b.seek(begin)
            remaining=end-begin
            while remaining:
                n=min(8*1024*1024,remaining)
                assert a.read(n)==b.read(n)
                remaining-=n
    assert hash_file(fix['path'])==original_hash
    report=Path(str(out)+'.patch-info.txt').read_text(encoding='utf-8-sig')
    assert original_hash in report and hash_file(out) in report

# Full-length, same-size archive tests: the released manifest is not modified.
bare=fixture('clean original 한글.iso')
bare_hash=hash_file(bare['path'])
out,_=run(bare,'bare_Korean.iso')
verify_output(bare,out,bare_hash)
results.append('PASS: bare XDVDFS full-length ISO apply; all non-prefix bytes unchanged; source unchanged; complete hashes match')
run(bare,'already_patched',source=out,expect='already contains Korean ISO')
results.append('PASS: already-patched ISO rejected')

for i,base in enumerate([0xFB20,0x20600,0x2080000,0xFD90000]):
    f=fixture('partition_'+str(i)+'.iso',base)
    run(f,'inspect_'+str(i),inspect=True)
    results.append('PASS: partition base 0x%X detected and validated'%base)
    if base==0xFD90000:
        original_hash=hash_file(f['path'])
        fullout,_=run(f,'partition_Korean.iso')
        verify_output(f,fullout,original_hash)
        results.append('PASS: partitioned full-length ISO apply; all other bytes/source unchanged; complete hashes match')
        fullout.unlink()
    f['path'].unlink()

existing=WORK/'existing.iso';existing.write_bytes(b'NEVER OVERWRITE')
run(bare,'existing_refused',output=existing,expect='Output already exists')
assert existing.read_bytes()==b'NEVER OVERWRITE'
run(bare,'same_path_refused',output=bare['path'],expect='must be different')
results.append('PASS: existing output and same source/output rejected without overwrite')

def mutate_test(label,offset,new,expected):
    with bare['path'].open('r+b') as f:
        f.seek(offset);old=f.read(len(new));f.seek(offset);f.write(new)
    try:
        rejected=WORK/(label+'.iso')
        run(bare,label+'.iso',expect=expected)
        assert not rejected.exists()
    finally:
        with bare['path'].open('r+b') as f:f.seek(offset);f.write(old)
    results.append('PASS: '+label+' rejected before output creation')

mutate_test('damaged_prefix',bare['l0']+12345,b'\xfa','Layer0 contents differ')
mutate_test('wrong_executable',bare['xex']+23,b'\xfa','default.xex differs')
mutate_test('cycle_in_directory',bare['root']+32,struct.pack('<H',8),'Cycle or shared node')
mutate_test('invalid_directory_pointer',bare['root']+2,struct.pack('<H',65535),'pointer outside')
mutate_test('extent_outside_iso',bare['root']+4,struct.pack('<I',0xffffffff),'extent outside ISO')
mutate_test('wrong_archive_size',bare['root']+8,struct.pack('<I',m['original_size']-1),'Layer0 size differs')
mutate_test('layer1_bad_format',bare['l1'],b'FAIL','Unsupported Layer1')

# Valid conflicting Layer1 archive, not merely an invalid signature.
conflict=bytearray(48+11+32)
struct.pack_into('>4sIIII',conflict,0,b'RATL',3,11,0,1)
conflict[48:59]=b'assets.xzp\0'
with bare['path'].open('r+b') as f:
    f.seek(bare['root']+64+8);oldlen=f.read(4);f.seek(bare['root']+64+8);f.write(struct.pack('<I',len(conflict)))
try:mutate_test('layer1_resource_conflict',bare['l1'],conflict,'conflicting translation resources')
finally:
    with bare['path'].open('r+b') as f:f.seek(bare['root']+64+8);f.write(oldlen)

payload=package/'payload/common_strings.bin'
original_payload=payload.read_bytes()
try:
    bad=bytearray(original_payload);bad[10]^=255;payload.write_bytes(bad)
    run(bare,'damaged_payload.iso',expect='payload hash mismatch')
    assert not (WORK/'damaged_payload.iso').exists()
finally:payload.write_bytes(original_payload)
results.append('PASS: damaged payload rejected before output creation')
assert hash_file(bare['path'])==bare_hash
results.append('PASS: original ISO still byte-exact after every rejected attempt')

report='\n'.join(results)+'\n\nLIMIT: synthetic XDVDFS images with actual supplied prefix/default.xex; PowerShell runtime: '+str(PWSH)+'\nNo retail ISO boot or full campaign/ending playthrough was performed.\n'
(WORK/'test_results.txt').write_text(report,encoding='utf-8')
print(report,flush=True)
