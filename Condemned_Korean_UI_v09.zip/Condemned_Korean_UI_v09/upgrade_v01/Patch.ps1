﻿param(
    [ValidateSet('Apply','Restore')][string]$Mode = 'Apply',
    [string]$GameDirectory = ''
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$package = Split-Path -Parent $MyInvocation.MyCommand.Path
$manifest = Get-Content -LiteralPath (Join-Path $package 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$createdTemp = $false
$inputStream = $null
$outputStream = $null
$committed = $false
$source = ''
$backup = ''
$temp = ''
$statePath = ''

function Hash-Bytes([byte[]]$Data) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($Data))).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function Hash-Stream([IO.Stream]$Stream) {
    $Stream.Position = 0
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash($Stream))).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function Read-Bytes([IO.Stream]$Stream, [long]$Offset, [int]$Count) {
    if ($Offset -lt 0 -or $Count -lt 0 -or $Offset + $Count -gt $Stream.Length) { throw 'Read outside file bounds.' }
    [void]$Stream.Seek($Offset, [IO.SeekOrigin]::Begin)
    $data = New-Object byte[] $Count
    $done = 0
    while ($done -lt $Count) {
        $n = $Stream.Read($data, $done, $Count-$done)
        if ($n -le 0) { throw 'Unexpected end of file.' }
        $done += $n
    }
    return ,$data
}
function From-Hex([string]$Hex) {
    if ($Hex.Length % 2) { throw 'Invalid hex length.' }
    $bytes = New-Object byte[] ($Hex.Length/2)
    for ($i=0; $i -lt $bytes.Length; $i++) { $bytes[$i] = [Convert]::ToByte($Hex.Substring($i*2,2),16) }
    return ,$bytes
}
function BE32([byte[]]$Data,[int]$At) {
    return [long]$Data[$At]*16777216 + [long]$Data[$At+1]*65536 + [long]$Data[$At+2]*256 + [long]$Data[$At+3]
}
function Put-BE64([byte[]]$Data,[int]$At,[long]$Value) {
    if ($Value -lt 0) { throw 'Negative archive value.' }
    $bytes = [BitConverter]::GetBytes($Value)
    if ([BitConverter]::IsLittleEndian) { [Array]::Reverse($bytes) }
    [Array]::Copy($bytes,0,$Data,$At,8)
}
function Check-Layer1([string]$Path) {
    if (!(Test-Path -LiteralPath $Path -PathType Leaf)) { throw 'Layer1.Arch00 is missing from the selected game folder.' }
    $fs = [IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
    try {
        $h = Read-Bytes $fs 0 48
        if ([Text.Encoding]::ASCII.GetString($h,0,4) -ne 'RATL' -or (BE32 $h 4) -ne 3) {
            throw 'Layer1 uses an unsupported archive format. No game files were changed.'
        }
        $ns = BE32 $h 8
        $fc = BE32 $h 16
        if ($ns -gt 16777216 -or $fc -gt 1000000 -or $ns -lt 1) { throw 'Invalid Layer1 directory.' }
        $names = Read-Bytes $fs 48 ([int]$ns)
        $table = Read-Bytes $fs (48+$ns) ([int]($fc*32))
        $conflicts = New-Object 'System.Collections.Generic.List[string]'
        for ($i=0; $i -lt $fc; $i++) {
            $no = BE32 $table ($i*32)
            if ($no -ge $ns) { throw 'Invalid Layer1 name offset.' }
            $end = [Array]::IndexOf($names,[byte]0,[int]$no)
            if ($end -lt 0) { throw 'Unterminated Layer1 name.' }
            $name = [Text.Encoding]::ASCII.GetString($names,[int]$no,[int]($end-$no))
            if ($name -ieq 'assets.xzp' -or $name -ieq 'font_pack.xpr' -or $name -ieq 'DARK.Strdb00p') { $conflicts.Add(('entry {0}: {1}' -f $i,$name)) }
        }
        if ($conflicts.Count) {
            throw ('Layer1 contains another UI resource: '+($conflicts -join ', ')+'. This edition requires additional analysis. No game files were changed.')
        }
    } finally { $fs.Dispose() }
}

try {
    if ([string]::IsNullOrWhiteSpace($GameDirectory)) {
        foreach ($candidate in @($package,(Split-Path -Parent $package))) {
            if (Test-Path -LiteralPath (Join-Path $candidate 'Layer0.Arch00') -PathType Leaf) { $GameDirectory=$candidate; break }
        }
    }
    if ([string]::IsNullOrWhiteSpace($GameDirectory)) {
        throw 'Put the extracted Condemned_Korean_UI_v01 folder beside default.xex and Layer0.Arch00, then run again.'
    }
    $GameDirectory = [IO.Path]::GetFullPath($GameDirectory)
    $source = Join-Path $GameDirectory 'Layer0.Arch00'
    $backup = Join-Path $GameDirectory 'Layer0.Arch00.pre_KoreanUI_v01.bak'
    $temp = Join-Path $GameDirectory 'Layer0.Arch00.KoreanUI_v01.tmp'
    $statePath = Join-Path $GameDirectory 'Condemned_KoreanUI_v01.state.json'
    Write-Host ('Game folder: '+$GameDirectory)

    if ($Mode -eq 'Restore') {
        if (!(Test-Path -LiteralPath $backup -PathType Leaf) -or !(Test-Path -LiteralPath $statePath -PathType Leaf)) {
            throw 'The original backup or installation record is missing. No files were changed.'
        }
        $state = Get-Content -LiteralPath $statePath -Raw -Encoding UTF8 | ConvertFrom-Json
        $fs = [IO.File]::OpenRead($backup)
        try {
            if ($fs.Length -ne $manifest.original_size -or (Hash-Bytes (Read-Bytes $fs 0 $manifest.prefix_size)) -ne $manifest.original_prefix_sha256) {
                throw 'Backup validation failed. No files were changed.'
            }
            if ((Hash-Stream $fs) -ne $state.original_sha256) { throw 'Backup contents changed. No files were changed.' }
        } finally { $fs.Dispose() }
        $fs = [IO.File]::OpenRead($source)
        try {
            if ($fs.Length -ne $state.patched_size -or (Hash-Bytes (Read-Bytes $fs 0 $manifest.prefix_size)) -ne $state.patched_prefix_sha256) {
                throw 'Layer0 changed after installation. Automatic restore stopped to preserve your changes.'
            }
            foreach ($span in $state.appended) {
                if ((Hash-Bytes (Read-Bytes $fs $span.offset $span.size)) -ne $span.sha256) { throw 'Patched resource changed. Automatic restore stopped.' }
            }
            if ((Hash-Stream $fs) -ne $state.patched_sha256) { throw 'Layer0 contents changed after installation. Automatic restore stopped.' }
        } finally { $fs.Dispose() }
        $removed = Join-Path $GameDirectory 'Layer0.Arch00.KoreanUI_v01.removed'
        if (Test-Path -LiteralPath $removed) { throw 'A previous restore temporary file exists. Move it elsewhere first.' }
        [IO.File]::Replace($backup,$source,$removed)
        Remove-Item -LiteralPath $removed
        Remove-Item -LiteralPath $statePath
        Write-Host 'RESTORED: original Layer0.Arch00 is back in place.' -ForegroundColor Green
        exit 0
    }

    if ((Test-Path -LiteralPath $backup) -or (Test-Path -LiteralPath $statePath)) {
        throw 'A Korean UI backup or installation record already exists. Use RUN_RESTORE.bat before applying again.'
    }
    if (Test-Path -LiteralPath $temp) { throw 'A temporary patch file already exists. Move it elsewhere before retrying.' }
    $xex = Join-Path $GameDirectory 'default.xex'
    if (!(Test-Path -LiteralPath $xex -PathType Leaf)) { throw 'default.xex was not found.' }
    if ((Get-FileHash -LiteralPath $xex -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.xex_sha256) {
        throw 'default.xex differs from the supplied game edition. No files were changed.'
    }
    Check-Layer1 (Join-Path $GameDirectory 'Layer1.Arch00')
    $inputStream = [IO.File]::Open($source,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
    if ($inputStream.Length -ne $manifest.original_size) { throw 'Layer0 size differs from the original. Restore a clean game copy first.' }
    if ((Hash-Bytes (Read-Bytes $inputStream 0 $manifest.prefix_size)) -ne $manifest.original_prefix_sha256) {
        throw 'Layer0 differs from the supplied original. Earlier experimental patches must be removed first.'
    }
    $payloads = @()
    foreach ($target in $manifest.targets) {
        $expected = From-Hex $target.original_entry_hex
        if ((Hash-Bytes (Read-Bytes $inputStream $target.entry_offset 32)) -ne (Hash-Bytes $expected)) { throw 'Archive directory validation failed.' }
        if ((Hash-Bytes (Read-Bytes $inputStream $target.original_offset $target.original_compressed_size)) -ne $target.original_sha256) {
            throw 'Original resource validation failed.'
        }
        $payload = [IO.File]::ReadAllBytes((Join-Path $package $target.payload))
        if ($payload.Length -ne $target.payload_size -or (Hash-Bytes $payload) -ne $target.payload_sha256) { throw 'Patch payload is damaged. Download and extract the package again.' }
        $payloads += ,$payload
    }
    Write-Host 'Original verified. Creating and validating the patched archive...'
    $originalHash = Hash-Stream $inputStream
    $outputStream = [IO.File]::Open($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    $createdTemp = $true
    $inputStream.Position = 0
    $inputStream.CopyTo($outputStream,1048576)
    $inputStream.Dispose(); $inputStream = $null
    $appended = @()
    for ($i=0; $i -lt $manifest.targets.Count; $i++) {
        $target = $manifest.targets[$i]
        [byte[]]$payload = $payloads[$i]
        $position = $outputStream.Length
        $padding = [int]((16-($position % 16)) % 16)
        $outputStream.Position = $position
        if ($padding) { $zeros=New-Object byte[] $padding; $outputStream.Write($zeros,0,$zeros.Length) }
        $position += $padding
        $outputStream.Write($payload,0,$payload.Length)
        $entry = From-Hex $target.original_entry_hex
        Put-BE64 $entry 4 $position
        Put-BE64 $entry 12 $payload.Length
        Put-BE64 $entry 20 $target.raw_size
        $outputStream.Position = $target.entry_offset
        $outputStream.Write($entry,0,$entry.Length)
        $outputStream.Flush()
        if ((Hash-Bytes (Read-Bytes $outputStream $position $payload.Length)) -ne $target.payload_sha256) { throw 'Written payload verification failed.' }
        if ((Hash-Bytes (Read-Bytes $outputStream $target.entry_offset 32)) -ne (Hash-Bytes $entry)) { throw 'Written archive directory verification failed.' }
        $appended += [pscustomobject]@{offset=$position;size=$payload.Length;sha256=$target.payload_sha256}
    }
    $state = [pscustomobject]@{
        version='0.1'; patched_size=$outputStream.Length;
        patched_prefix_sha256=(Hash-Bytes (Read-Bytes $outputStream 0 $manifest.prefix_size));
        original_sha256=$originalHash; patched_sha256=(Hash-Stream $outputStream);
        appended=$appended
    }
    $outputStream.Flush($true)
    $outputStream.Dispose(); $outputStream=$null
    # The complete replacement is ready before the first original-file mutation.
    [IO.File]::Replace($temp,$source,$backup)
    $createdTemp=$false; $committed=$true
    try { [IO.File]::WriteAllText($statePath,($state | ConvertTo-Json -Depth 6),[Text.Encoding]::UTF8) }
    catch {
        # Restore the original if recording the successful installation fails.
        [IO.File]::Replace($backup,$source,$temp)
        $committed=$false; $createdTemp=$true
        throw
    }
    Write-Host 'APPLIED: Korean UI text and font resources installed.' -ForegroundColor Green
    Write-Host 'Open default.xex in Xenia. Select English or Korean as the console language.'
    Write-Host 'Scope: menus/settings/UI help. Story dialogue is unchanged.'
    Write-Host 'Use RUN_RESTORE.bat to restore the original.'
    exit 0
} catch {
    $message = $_.Exception.Message
    Write-Host ('ERROR: '+$message) -ForegroundColor Red
    try { [IO.File]::WriteAllText((Join-Path $package 'patch_error.txt'),$message,[Text.Encoding]::UTF8) } catch {}
    exit 1
} finally {
    if ($null -ne $inputStream) { $inputStream.Dispose() }
    if ($null -ne $outputStream) { $outputStream.Dispose() }
    if ($createdTemp -and !$committed -and (Test-Path -LiteralPath $temp)) { Remove-Item -LiteralPath $temp -ErrorAction SilentlyContinue }
}
