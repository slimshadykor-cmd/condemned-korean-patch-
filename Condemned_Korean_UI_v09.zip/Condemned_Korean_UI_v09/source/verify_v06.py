"""python verify_v06.py ORIGINAL_DB ORIGINAL_FONT_XPR V05_PACKAGE
Read-only checks of the shipped payloads; creates a font proof PNG in the package.
"""
from pathlib import Path
import hashlib,json,re,struct,sys,zlib
from PIL import Image
P=Path(__file__).resolve().parent.parent
original=Path(sys.argv[1]).read_bytes();ofont=Path(sys.argv[2]).read_bytes();BASE=Path(sys.argv[3])
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
r=read(P/'build_report.json');changes={x['offset']:x for x in r['common_string_changes']}
assert sha(original)==r['common_original_sha256']
data=zlib.decompress((P/'payload/common_strings.bin').read_bytes())
olddata=zlib.decompress((BASE/'payload/common_strings.bin').read_bytes())
assert len(data)==len(original) and sha(data)==r['common_fixed_sha256']
exceptions={x['offset']:x for x in read(P/'source/literal_input_tag_allowlist_v06.json')}
revised={x['offset']:x for x in read(P/'translations_revised_v06.json')}
def entries(b):
    p=0x17548
    while p<len(b):
        end=p
        while end+2<=len(b) and b[end:end+2]!=b'\0\0':end+=2
        if end+2>len(b):return
        yield p,b[p:end]
        p=(end+5)&~3
A=list(entries(original));B=list(entries(data));C=list(entries(olddata))
assert len(A)==len(B)==len(C)
actual=set();found=set();allowed=bytearray(len(data))
token=r'<%[^>]+%>|%\d+![^!]+!|%(?:\.\d+)?[sdf]|%%|<\?>'
control=r'<%(?:action|flashlight|tools|fire|ammocheck|togglemelee|sprint|taser|kick|block|pause|aim|move)%>'
for (p,s),(q,t),(v,w) in zip(A,B,C):
    assert p==q==v
    if t!=w:actual.add(p)
    if p not in changes:assert s==t;continue
    row=changes[p];found.add(p)
    assert s.decode('utf-16-be')==row['source']
    assert t.decode('utf-16-be').rstrip('\u200b')==row['korean']
    oldtokens=re.findall(token,row['source'])
    if p in exceptions:
        assert row['korean']==exceptions[p]['korean']
        oldtokens=[x for x in oldtokens if not re.fullmatch(control,x)]
    assert oldtokens==re.findall(token,row['korean'])
    assert re.findall(r'<%time%>\s*[\d.]+',row['source'])==re.findall(r'<%time%>\s*[\d.]+',row['korean'])
    allowed[p:p+row['slot_bytes']]=b'\1'*row['slot_bytes']
    assert not re.search(control,row['korean'])
assert found==set(changes) and actual==set(revised)
assert all(a==b or allowed[i] for i,(a,b) in enumerate(zip(original,data)))
assert sum('<%page%>' in x['source'] or '<%time%>' in x['source'] for x in changes.values())>0
for row in read(P/'source/all_strings.json'):
    if '<%page%>' in row['text'] or '<%time%>' in row['text']:assert row['offset'] in changes
print(f'PASS: {len(changes)} DB translations; {len(revised)} v06 revisions; all sequential boundaries, pages, timing values, printf fields; {len(exceptions)} explicit input-tag exceptions.')

def xus(b):
    assert b[:6]==b'XUIS\x01\x00' and struct.unpack_from('>I',b,6)[0]==len(b)
    q=12;rows=[]
    for _ in range(struct.unpack_from('>H',b,10)[0]):
        row=[]
        for _ in range(2):
            n=struct.unpack_from('>H',b,q)[0];q+=2;row.append(b[q:q+n*2].decode('utf-16-be'));q+=n*2
        rows.append(row)
    assert q==len(b)
    return rows
def assets(b):
    assert b[:4]==b'XUIZ' and struct.unpack_from('>I',b,8)[0]==len(b)
    base=22+struct.unpack_from('>I',b,16)[0];p=22;records=[]
    for _ in range(struct.unpack_from('>H',b,20)[0]):
        size,off,n=struct.unpack_from('>IIB',b,p);name=b[p+9:p+9+n*2].decode('utf-16-be');p+=9+n*2
        records.append((name,base+off,size))
    assert p==base
    result={}
    for i,(name,start,size) in enumerate(records):
        nxt=records[i+1][1] if i+1<len(records) else len(b)
        result[name]=(b[start:start+size],b[start+size:nxt])
    return result
oldassets=assets(zlib.decompress((BASE/'payload/ui_assets.bin').read_bytes()))
newassets=assets(zlib.decompress((P/'payload/ui_assets.bin').read_bytes()))
assert oldassets.keys()==newassets.keys()
edited=set();menu_text=[]
for name,(content,trailer) in newassets.items():
    old,oldtrailer=oldassets[name];assert trailer==oldtrailer
    if content==old:continue
    edited.add(name);a=xus(old);b=xus(content);assert len(a)==len(b)
    for (ov,ok),(nv,nk) in zip(a,b):
        assert ok==nk
        if nk=='XuiScene1.MenuLabel.Text':assert nv=='한글화: 슬림쉐이디';menu_text.append(nv)
        elif nk=='XuiScene1.MenuLabel.PointSize':assert nv=='24'
        else:assert ov==nv
assert edited=={'en-US\\frontEndMenu.xus','ko-kR\\frontEndMenu.xus'}
print('PASS: credit in both front-end locales; all other XUS values, XUR layouts, images, paths and trailers unchanged.')

font=zlib.decompress((P/'payload/korean_font.bin').read_bytes())
u16=lambda b,p:struct.unpack_from('>H',b,p)[0]
u32=lambda b,p:struct.unpack_from('>I',b,p)[0]
maxc=u16(font,0x88);cmap=struct.unpack_from('>'+str(maxc+1)+'H',font,0x8a)
gb=0x8a+(maxc+1)*2;ng=u32(font,gb)
glyphs=[struct.unpack_from('>4H3hH',font,gb+4+i*16) for i in range(ng)]
ogb=0x8a+(u16(ofont,0x88)+1)*2;on=u32(ofont,ogb)
assert on==325
assert glyphs[:on]==[struct.unpack_from('>4H3hH',ofont,ogb+4+i*16) for i in range(on)]
for txt in [x['korean'] for x in changes.values()]+menu_text:
    for ch in txt:
        if not ch.isspace():assert ord(ch)<=maxc and cmap[ord(ch)]>0,ch
def decode_font(f):
    d=u32(f,0x64);w=(d&8191)+1;h=((d>>13)&8191)+1;t=f[12+u32(f,4):]
    linear=bytearray(w*h)
    for y in range(h//4):
        for x in range(w//4):
            q=(((((y>>5)*((w//4)>>5)+(x>>5))<<6)|(((y>>1)&7)<<3)|(x&7))<<4)
            a=((q>>8)<<12)|(((q>>5)&7)<<8)|(((q>>4)&1)<<5)|(q&15)|(((y>>4)&1)<<11)|((((x>>3)&3)^(((y>>3)&1)<<1))<<6)|((y&1)<<4)
            block=t[a:a+16];o=(y*(w//4)+x)*16
            linear[o:o+16]=b''.join(block[i:i+2][::-1] for i in range(0,16,2))
    return Image.frombytes('RGBA',(w,h),bytes(linear),'bcn',3)
atlas=decode_font(font);oldatlas=decode_font(ofont)
assert atlas.crop((0,0,*oldatlas.size)).tobytes()==oldatlas.tobytes()
g=glyphs[cmap[0x200b]];assert g[5]==g[6]==0
assert atlas.crop(g[:4]).getchannel('A').getbbox() is None
print('PASS: decoded font: original 325 glyphs and original pixels preserved; all translations and 쉐 mapped; padding invisible.')

# Proof uses glyph pixels decoded from the shipped BC3/XPR payload, not a system font.
def render(txt,size):
    advances=[glyphs[cmap[ord(ch)]][6] for ch in txt];width=sum(advances)
    out=Image.new('RGBA',(max(width,1),62))
    x=0
    for ch in txt:
        g=glyphs[cmap[ord(ch)]]
        if g[5]>0:out.alpha_composite(atlas.crop(g[:4]),(x+g[4],0))
        x+=g[6]
    return out.resize((max(1,round(width*size/58)),round(62*size/58)),Image.Resampling.LANCZOS)
proof=Image.new('RGBA',(1024,640),(24,30,38,255))
sample_rows=[(40,'한글화: 슬림쉐이디',24),(110,'흰 화살표가 모두 안쪽을',30),
             (150,'향하게 도구를 조준하세요.',30),(220,'화면 테두리가 밝게 빛나도록',30),
             (260,'확대·축소를 조절하세요.',30),(330,'마치면 계단 옆 철제 책상을',30),
             (370,'옮기고 나가세요.',30),(440,'폭발 소리가 들렸어.',36),
             (510,'막힌 길을 뚫을 도구는',36),(554,'근처에서 찾을 수 있어.',36)]
for y,txt,size in sample_rows:
    rendered=render(txt,size)
    assert rendered.width<=(256 if y==40 else 440 if size==30 else 900),(txt,rendered.width)
    proof.alpha_composite(rendered,(32,y))
proof.convert('RGB').save(P/'font_preview.png')
for t in read(P/'manifest.json')['targets']:
    c=(P/t['payload']).read_bytes();assert len(c)==t['payload_size'] and sha(c)==t['payload_sha256']
    assert len(zlib.decompress(c))==t['raw_size']
print('PASS: credit width <256px at 24pt; captured hint lines <440px at 30pt; payload sizes and hashes verified. Runtime layout still requires Xenia.')

# Mixed-speaker dialogue keeps Becker's polite opening; check only Dickenson pages.
review=read(P/'source/dickenson_review_v06.json')
for row in review:
    text=row['korean']
    if row['catalog_index']==492:text='<%page%>'.join(text.split('<%page%>')[2:])
    assert not re.search(r'(?:습니다|세요|어요|아요|해요|예요|에요|십시오)[.!?\s<]',text),row
print(f'PASS: {len(review)} context-identified Dickenson entries reviewed for informal endings; mixed-speaker radio split respected.')
