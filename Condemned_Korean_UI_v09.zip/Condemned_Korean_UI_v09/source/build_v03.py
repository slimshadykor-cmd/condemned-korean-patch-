from pathlib import Path
import importlib.util,json,struct,zlib,hashlib,shutil,re
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'Condemned_Korean_UI_v02'
OUT=ROOT/'Condemned_Korean_UI_v03'
RES=ROOT/'resources'
BUILD=ROOT/'v03_build'
sha=lambda b:hashlib.sha256(b).hexdigest()
if not OUT.exists():shutil.copytree(BASE,OUT)
BUILD.mkdir(exist_ok=True);(BUILD/'prior').mkdir(exist_ok=True)
for name in ['NotoSansCJKkr-Regular.otf','asset_770.bin']:
    shutil.copy2(RES/name,BUILD/'prior'/name)
shutil.copy2(BASE/'source/build_ui_patch.py',BUILD/'build_ui_patch.py')
T=json.loads((BASE/'ui_translations.json').read_text())
new=json.loads((ROOT/'gameplay_translations_v03.json').read_text())
old=json.loads((BASE/'build_report.json').read_text())['common_string_changes']
changes={r['offset']:r.copy() for r in old}
for r in new:changes[r['offset']]=r.copy();T[r['source']]=r['korean']
T['__zero_width_padding__']='\u200b'
(BUILD/'ui_translations.json').write_text(json.dumps(T,ensure_ascii=False),encoding='utf-8')
spec=importlib.util.spec_from_file_location('font_builder',BUILD/'build_ui_patch.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
font,info=m.make_font(set(T))
font=bytearray(font)
# Explicitly make U+200B an invisible, zero-advance padding glyph. This keeps
# database entry boundaries without adding long runs of visible-width spaces
# to centered dialogue or wrapping text. Its atlas pixels must be transparent.
cmap_count=struct.unpack_from('>H',font,0x88)[0]+1
glyph_index=struct.unpack_from('>H',font,0x8a+0x200b*2)[0]
glyph_base=0x8a+cmap_count*2+4
gp=glyph_base+glyph_index*16
assert glyph_index>0
struct.pack_into('>hh',font,gp+10,0,0) # width, advance
info.update(padding_codepoint='U+200B',padding_glyph_index=glyph_index,padding_advance=0)
original=(ROOT.parent/'diagnosis/00012_DARK.Strdb00p').read_bytes()
data=bytearray(original)
for p,r in sorted(changes.items()):
    enc=r['source'].encode('utf-16-be')+b'\0\0'
    assert original[p:p+len(enc)]==enc,(p,r)
    slot=(len(enc)+3)&~3
    assert original[p+len(enc):p+slot]==bytes(slot-len(enc))
    replacement=r['korean'].encode('utf-16-be')
    assert len(replacement)+2<=slot,(r['source'],r['korean'])
    before=re.findall(r'<%[^>]+%>|%\d+![^!]+!',r['source'])
    after=re.findall(r'<%[^>]+%>|%\d+![^!]+!',r['korean'])
    assert before==after,(r,before,after)
    # Page timings are preserved verbatim as well as format/control tokens.
    assert re.findall(r'<%time%>\s*[\d.]+',r['source'])==re.findall(r'<%time%>\s*[\d.]+',r['korean'])
    data[p:p+slot]=replacement+b'\x20\x0b'*((slot-len(replacement)-2)//2)+b'\0\0'
    r['slot_bytes']=slot
assert len(data)==len(original)
for name,raw in [('common_strings.bin',data),('korean_font.bin',font)]:
    (OUT/'payload'/name).write_bytes(zlib.compress(raw,9))
manifest=json.loads((BASE/'manifest.json').read_text())
for target in manifest['targets']:
    comp=(OUT/target['payload']).read_bytes()
    target.update(payload_size=len(comp),payload_sha256=sha(comp),raw_size=len(zlib.decompress(comp)))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')

patch=(BASE/'Patch.ps1').read_text(encoding='utf-8-sig').replace('Korean_UI_v02','Korean_UI_v03').replace('KoreanUI_v02','KoreanUI_v03').replace("version='0.2'","version='0.3'")
patch=patch.replace('Scope: menus/settings/UI help. Story dialogue is unchanged.','Scope: menus, objectives, loading reports and selected early dialogue. Partial translation.')
(OUT/'Patch.ps1').write_text(patch,encoding='utf-8-sig',newline='\r\n')
for version,path in [('v02',BASE),('v01',BASE/'upgrade_v01')]:
    folder=OUT/('upgrade_'+version);folder.mkdir(exist_ok=True)
    for name in ['Patch.ps1','manifest.json']:shutil.copy2(path/name,folder/name)
(OUT/'gameplay_translations.json').write_text(json.dumps(new,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'ui_translations.json').write_text(json.dumps({k:v for k,v in T.items() if not k.startswith('__')},ensure_ascii=False,indent=2),encoding='utf-8')
report=json.loads((BASE/'build_report.json').read_text())
report.update(version='0.3',runtime_tested=False,story_dialogue_translated='partial: selected opening/investigation dialogue',
    gameplay_translation_count=len(new),objective_translation_count=sum(r['source'].startswith('OBJECTIVE:') for r in new),
    loading_report_count=sum(r['source'].startswith('Internal Report') for r in new),
    common_string_changes=list(changes.values()),common_original_sha256=sha(original),common_fixed_sha256=sha(data),font=info,
    fix='Preserve original entry boundaries; U+200B padding has an explicit transparent glyph with width/advance 0.',
    runtime_evidence_v02='User screenshots confirm Normal=보통, Duck Under and early dialogue restored; Korean menus render.',
    installer_validation='Inherited verified installer core; version names updated; Windows/Xenia v0.3 not executed.')
report['validation']=['Every original sequential DB entry start preserved','Untranslated entries byte-identical',
 'Format placeholders, page markers, time tokens and values preserved','All translated characters mapped to font glyphs',
 'Original 325 glyph records and texture region preserved','U+200B width and advance explicitly zero; texture region transparent',
 'XUI assets payload byte-identical to user-confirmed v0.2']
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
for f in ['verify_v02.py','screenshot_regressions.json']:
    (OUT/'source'/f).unlink(missing_ok=True)
shutil.copy2(ROOT/'translate_v03.py',OUT/'source/translate_v03.py')
shutil.copy2(Path(__file__),OUT/'source/build_v03.py')
print(json.dumps({'changes_total':len(changes),'new':len(new),'font':info,'payloads':[(t['payload'],t['payload_size']) for t in manifest['targets']]},ensure_ascii=False))
