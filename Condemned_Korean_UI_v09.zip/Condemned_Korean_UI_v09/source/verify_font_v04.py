from pathlib import Path
import struct,zlib,json,sys,importlib.util
from PIL import Image
ROOT=Path(__file__).resolve().parent
p=ROOT/'Condemned_Korean_UI_v04'
b=zlib.decompress((p/'payload/korean_font.bin').read_bytes())
be=lambda off:struct.unpack_from('>I',b,off)[0]
maxc=struct.unpack_from('>H',b,0x88)[0];cmap=struct.unpack_from('>'+str(maxc+1)+'H',b,0x8a);gb=0x8a+(maxc+1)*2;ng=be(gb)
glyphs=[struct.unpack_from('>4H3hH',b,gb+4+i*16) for i in range(ng)]
v=be(0x64);w=(v&8191)+1;h=((v>>13)&8191)+1;t=b[12+be(4):]
# Independent untile calculation, then use Pillow's BC3 decoder.
def address(x,y,pitch):
 q=((((y>>5)*(pitch>>5)+(x>>5))<<6)|(((y>>1)&7)<<3)|(x&7))<<4
 return ((q>>8)<<12)|(((q>>5)&7)<<8)|(((q>>4)&1)<<5)|(q&15)|(((y>>4)&1)<<11)|((((x>>3)&3)^(((y>>3)&1)<<1))<<6)|((y&1)<<4)
linear=bytearray(w*h)
for y in range(h//4):
 for x in range(w//4):
  a=address(x,y,w//4);block=t[a:a+16];o=(y*(w//4)+x)*16
  linear[o:o+16]=b''.join(block[i:i+2][::-1] for i in range(0,16,2))
atlas=Image.frombytes('RGBA',(w,h),bytes(linear),'bcn',3)
g=glyphs[cmap[0x200b]]
assert atlas.crop(g[:4]).getchannel('A').getbbox() is None
assert g[5]==g[6]==0
orig=(ROOT/'resources/asset_770.bin').read_bytes();om=struct.unpack_from('>H',orig,0x88)[0];og=0x8a+(om+1)*2;on=struct.unpack_from('>I',orig,og)[0]
assert [struct.unpack_from('>4H3hH',orig,og+4+i*16) for i in range(on)]==glyphs[:on]
examples=['무전: 시신의 체온으로 보아','살해된 지 얼마 안 됐어요.','수사 도구 / 채취 도구 / 증거 수집','목의 멍을 스캔하라.','유기물 증거는 밝은 보라색으로 빛납니다.','제1장: 와이즈먼 사무실 건물','황금 탐정 배지 / 근접전 달인 동상','로사: 준비되면 데이터를 보내요.']
canvas=Image.new('RGBA',(1600,600),(21,27,34,255))
for row,txt in enumerate(examples):
 x=30;y=12+row*72
 for ch in txt+'\u200b'*300:
  g=glyphs[cmap[ord(ch)]]
  if g[5]>0:
   crop=atlas.crop(g[:4]);canvas.alpha_composite(crop,(int(x+g[4]),y))
  x+=g[6]
 assert x<1600,(txt,x)
canvas.convert('RGB').save(p/'font_preview.png')
print('PASS: decoded BC3 atlas, transparent zero-advance padding, original 325 glyph records preserved; preview rendered.')
