# v0.4 제작 기록

증상: 0.3 스크린샷의 도입 대사와 보고서는 한글로 표시되지만 로사 무전, 수사 HUD, 도전 과제와 장 설명은 영어였다.
확인: 해당 문구는 원본 DB에서 찾았으며 0.3 번역 목록에 없었다. 이미 검증된 항목 경계 보존 방식으로 추가했다.

- 351개 추가, 3개 수정, 누적 667개 DB 항목.
- UTF-16BE 원본 항목 경계 유지. U+200B 채움 글리프는 투명·폭 0·전진 폭 0.
- 모든 자막 page/time 토큰 및 시간값, 컨트롤러 토큰, printf 형식 순서 보존.
- 2048×2048 글꼴, 한글 675자와 원본 325개 글리프 및 패딩 1개.
- UI assets는 사용자가 표시를 확인한 이전 파일과 동일.
- 0.1/0.2/0.3 복원 스크립트와 manifest는 해당 배포본 그대로 포함.
- 시험에 쓴 작은 archive fixture와 원본 실행 파일은 배포에 포함하지 않음.

source의 제작 스크립트는 작업 폴더 기준의 기록이다. 재생성에는 이전 0.3 패키지,
원본 DB, 원본 font_pack 리소스, NotoSansCJKkr-Regular.otf 등이 필요하다.
all_strings.json의 번호는 추출 목록의 순번이며 게임 내부 문자열 ID가 아니다.
verify_v04.py는 이 패키지의 source 폴더에서 실행 가능하다:
python verify_v04.py /path/to/original_00012_DARK.Strdb00p

검증 결과는 verification_v04.txt. 실제 0.4의 Windows/Xenia 표시 검증은 사용자의 후속 플레이가 필요하다.
