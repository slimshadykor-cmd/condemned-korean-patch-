from pathlib import Path
import struct, json, zlib, hashlib, math, shutil
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'Condemned_Korean_UI_v02'
OUT.mkdir(exist_ok=True)
(OUT / 'payload').mkdir(exist_ok=True)
T = json.loads((ROOT / 'ui_translations.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
be16 = lambda b, p: struct.unpack_from('>H', b, p)[0]
be32 = lambda b, p: struct.unpack_from('>I', b, p)[0]


def read_xus(data):
    assert data[:6] == b'XUIS\x01\x00'
    assert be32(data, 6) == len(data)
    count, p, pairs = be16(data, 10), 12, []
    for _ in range(count):
        pair = []
        for _ in range(2):
            n = be16(data, p)
            p += 2
            pair.append(data[p:p+n*2].decode('utf-16-be'))
            p += n*2
        pairs.append(pair)
    assert p == len(data)
    return pairs


def write_xus(pairs):
    body = bytearray()
    for pair in pairs:
        for s in pair:
            enc = s.encode('utf-16-be')
            body.extend(struct.pack('>H', len(enc)//2))
            body.extend(enc)
    return b'XUIS\x01\x00' + struct.pack('>IH', 12+len(body), len(pairs)) + body


def build_assets():
    original = (ROOT / 'prior/assets.xzp').read_bytes()
    assert original[:4] == b'XUIZ' and be32(original, 8) == len(original)
    base = 22 + be32(original, 16)
    count, p = be16(original, 20), 22
    records = []
    for i in range(count):
        size, offset, namelen = struct.unpack_from('>IIB', original, p)
        name = original[p+9:p+9+namelen*2].decode('utf-16-be')
        records.append((p, name, base+offset, size))
        p += 9 + namelen*2
    assert p == base
    replacements = {}
    changed, used, occurrences = [], set(), 0
    for entry, name, start, size in records:
        if not (name.startswith(('en-US\\', 'ko-kR\\')) and name.endswith('.xus')):
            continue
        raw = original[start:start+size]
        pairs = read_xus(raw)
        assert write_xus(pairs) == raw
        updates = 0
        for pair in pairs:
            value, key = pair
            if key.endswith('.Text') and value in T:
                used.add(value)
                pair[0] = T[value]
                updates += 1
        if updates:
            new = write_xus(pairs)
            replacements[name] = new
            assert read_xus(new) == pairs
            changed.append({'name': name, 'strings': updates})
            occurrences += updates
    # Rebuild the directory offsets while retaining each file's original
    # FILETIME and source-path trailer immediately after its content.
    table = bytearray(original[:base])
    body = bytearray()
    for i,(entry,name,start,size) in enumerate(records):
        nextstart = records[i+1][2] if i+1<len(records) else len(original)
        trailer=original[start+size:nextstart]
        assert len(trailer)==10+be16(trailer,8)*2
        raw=replacements.get(name,original[start:start+size])
        struct.pack_into('>II',table,entry,len(raw),len(body))
        body.extend(raw)
        body.extend(trailer)
    result=table+body
    struct.pack_into('>I',result,8,len(result))
    # Prove that all non-target assets (images, sounds, XUR layouts, other
    # languages) remain byte-identical and every changed XUS is parseable.
    changed_names = {r['name'] for r in changed}
    for entry, name, start, size in records:
        newsize=be32(result,entry)
        newstart=base+be32(result,entry+4)
        if name in changed_names:
            check = read_xus(result[newstart:newstart+newsize])
            old = read_xus(original[start:start+size])
            assert len(check) == len(old)
            for (nv, nk), (ov, ok) in zip(check, old):
                assert nk == ok
                assert nv == (T.get(ov, ov) if ok.endswith('.Text') else ov)
        else:
            assert result[newstart:newstart+newsize] == original[start:start+size]
    return bytes(result), changed, used, occurrences


def tiled_offset(x, y, pitch, logbpp=4):
    # Xenos 2D block address layout. All pitches supplied here are 32-aligned.
    outer = ((y >> 5) * (pitch >> 5) + (x >> 5)) << 6
    inner = (((y >> 1) & 7) << 3) | (x & 7)
    q = (outer | inner) << logbpp
    bank = (y >> 4) & 1
    pipe = ((x >> 3) & 3) ^ (((y >> 3) & 1) << 1)
    return ((q >> 8) << 12) | (((q >> 5) & 7) << 8) | (((q >> 4) & 1) << 5) | (q & 15) | (bank << 11) | (pipe << 6) | ((y & 1) << 4)


def make_font(used):
    face = ImageFont.truetype(str(ROOT/'prior/NotoSansCJKkr-Regular.otf'), 50)
    original = (ROOT/'prior/asset_770.bin').read_bytes()
    oldmax = be16(original, 0x88)
    oldmap = struct.unpack_from('>'+str(oldmax+1)+'H', original, 0x8a)
    oldstart = 0x8a + len(oldmap)*2
    oldcount = be32(original, oldstart)
    glyphs = [struct.unpack_from('>4H3hH',original,oldstart+4+i*16) for i in range(oldcount)]
    wanted = {ord(c) for s in used for c in T[s] if not c.isspace()}
    codes = sorted(c for c in wanted if c>oldmax or oldmap[c]==0)
    chars = [chr(c) for c in codes]
    cmap = list(oldmap) + [0] * (max(max(wanted),oldmax)-oldmax)
    for i, c in enumerate(codes, oldcount): cmap[c] = i
    width, cellh, x, y = 2048, 62, 524, 2
    placements = []
    for c in chars:
        bb = face.getbbox(c, anchor='ls')
        advance = max(1, int(math.ceil(face.getlength(c))))
        gw = max(advance, bb[2]-bb[0], 1)
        if x + gw + 2 > width:
            x, y = 524, y+cellh
        placements.append((x, y, gw, advance, bb[0]))
        x += gw + 4
    height = 1 << max(y+60,max(g[3] for g in glyphs)).bit_length()
    atlas = Image.new('L', (width, height))
    draw = ImageDraw.Draw(atlas)
    for c, (x, y, gw, advance, bearing) in zip(chars, placements):
        draw.text((x-bearing, y+45), c, font=face, fill=255, anchor='ls')
        glyphs.append((x, y, x+gw, y+58, 0, gw, advance, 0))
    # BC3/DXT5, white RGB and eight-level antialiased alpha. Font shader
    # glyph mask zero uses the texture RGBA directly, as in the original.
    blocks_w, blocks_h = width//4, height//4
    pixels = atlas.tobytes()
    alpha_palette = [255, 0, 218, 182, 145, 109, 72, 36]
    lookup = [min(range(8), key=lambda k: abs(v-alpha_palette[k])) for v in range(256)]
    tiled = bytearray(width*height)
    seen = set()
    linear = bytearray(width*height)
    oldhs = be32(original,4)
    oldtexture = original[12+oldhs:]
    oldpixelsize = be32(original,0x64)
    oldbw = ((oldpixelsize & 8191)+1)//4
    oldbh = (((oldpixelsize>>13)&8191)+1)//4
    oldlinear = bytearray(len(oldtexture))
    for by in range(oldbh):
        for bx in range(oldbw):
            a=tiled_offset(bx,by,oldbw)
            block=oldtexture[a:a+16]
            q=(by*oldbw+bx)*16
            oldlinear[q:q+16]=b''.join(block[j:j+2][::-1] for j in range(0,16,2))
    oldmaxbx=(max(g[2] for g in glyphs[:oldcount])+3)//4
    oldmaxby=(max(g[3] for g in glyphs[:oldcount])+3)//4
    for by in range(blocks_h):
        for bx in range(blocks_w):
            indices = 0
            for iy in range(4):
                row = (by*4+iy)*width+bx*4
                for ix in range(4):
                    indices |= lookup[pixels[row+ix]] << (3*(iy*4+ix))
            block = bytes((255, 0)) + indices.to_bytes(6, 'little') + b'\xff\xff\x00\x00\x00\x00\x00\x00'
            if bx<oldmaxbx and by<oldmaxby:
                # Preserve original Latin glyphs and colored controller icons.
                # A few original coordinates wrap past the original texture;
                # explicitly retain that repeat sampling when the atlas grows.
                q=((by % oldbh)*oldbw+(bx % oldbw))*16
                block=bytes(oldlinear[q:q+16])
            idx = (by*blocks_w+bx)*16
            linear[idx:idx+16] = block
            address = tiled_offset(bx, by, blocks_w)
            assert address % 16 == 0 and address+16 <= len(tiled) and address not in seen
            seen.add(address)
            # The original fetch descriptor requests 8-in-16 endian swap.
            tiled[address:address+16] = b''.join(block[j:j+2][::-1] for j in range(0,16,2))
    assert len(seen)*16 == len(tiled)
    # Roundtrip each tile back to BC3 and confirm its exact bytes.
    untiled = bytearray(len(tiled))
    for by in range(blocks_h):
        for bx in range(blocks_w):
            a = tiled_offset(bx,by,blocks_w)
            block = tiled[a:a+16]
            a2 = (by*blocks_w+bx)*16
            untiled[a2:a2+16] = b''.join(block[j:j+2][::-1] for j in range(0,16,2))
    assert untiled == linear
    for by in range(oldbh):
        for bx in range(oldbw):
            q=(by*blocks_w+bx)*16;oldq=(by*oldbw+bx)*16
            assert linear[q:q+16]==oldlinear[oldq:oldq+16]
    fd = bytearray(struct.pack('>I4fH', 5, 58., 0., 0., 58., len(cmap)-1))
    fd += struct.pack('>'+str(len(cmap))+'H', *cmap)
    fd += struct.pack('>I', len(glyphs))
    for glyph in glyphs: fd += struct.pack('>4H3hH', *glyph)
    # Resource offsets remain relative to the CPU header beginning at +12.
    cpu = bytearray(original[12:0x74]) + fd
    struct.pack_into('>I', cpu, 0x28-12, len(fd))
    word0 = be32(original, 0x5c)
    word0 = (word0 & ~(511 << 22)) | ((width//32) << 22)
    struct.pack_into('>I', cpu, 0x5c-12, word0)
    struct.pack_into('>I', cpu, 0x64-12, (width-1) | ((height-1) << 13))
    cpusize = (len(cpu)+2047)//2048*2048
    cpu += bytes(cpusize-len(cpu))
    result = b'XPR2' + struct.pack('>II', cpusize, len(tiled)) + cpu + tiled
    assert len(result) == 12+cpusize+width*height
    assert be32(result, 0x28) == len(fd)
    assert all(cmap[ord(c)] > 0 for s in used for c in T[s] if not c.isspace())
    for x0,y0,x1,y1,_,_,_,_ in glyphs:
        assert 0 <= x0 < x1 <= width and 0 <= y0 < y1 <= height
    atlas.save(ROOT/'prior/korean_font_atlas.png')
    preview = Image.new('RGB', (1100, 380), '#151c25')
    pd = ImageDraw.Draw(preview)
    pf = ImageFont.truetype(str(ROOT/'prior/NotoSansCJKkr-Regular.otf'), 34)
    for i, line in enumerate(['컨뎀드: 메뉴·설정 한글 번역', '새 게임   이어 하기   불러오기   설정', '화면 설정   소리 설정   조작 설정', '자막   난이도   진동   조준 감도', '과학 수사 도구   가스 분석기   증거 수집']):
        pd.text((35, 28+i*66), line, font=pf, fill='#eef5ff')
    preview.save(ROOT/'prior/korean_type_preview.png')
    return result, {'glyph_count':len(glyphs), 'original_glyphs_preserved':oldcount, 'hangul_glyphs':sum(0xac00<=c<=0xd7a3 for c in codes), 'width':width, 'height':height, 'max_codepoint':len(cmap)-1}


def build_common_strings():
    import re
    original=(ROOT/'prior/00012_DARK.Strdb00p').read_bytes()
    replacements={k:v for k,v in T.items() if len(k)<70 and '\n' not in k}
    extra={'On':'켬','Off':'끔','Yes':'예','No':'아니요','Easy':'쉬움','Normal':'보통','Hard':'어려움',
        'Medium':'중간','High':'높음','Low':'낮음','Very High':'최고','Enabled':'사용','Disabled':'사용 안 함',
        'Audio':'소리','Video':'화면','Controls':'조작','Game':'게임','None':'없음','Default':'기본값'}
    replacements.update(extra)
    for k,v in list(replacements.items()):
        replacements.setdefault(k.upper(),v)
    result=bytearray(original);changed=[];used=set()
    for match in re.finditer(rb'(?:\x00[\x09\x0a\x0d\x20-\x7e]){2,}\x00\x00',original):
        start,end=match.span()
        if start%4 or start<0x17548: continue
        value=match.group()[:-2].decode('utf-16-be')
        if value not in replacements:continue
        new=replacements[value].encode('utf-16-be')+b'\0\0'
        available=end-start
        # Only the zero padding up to this string's 4-byte alignment belongs
        # to its slot. Never borrow bytes from the next string.
        aligned=(end+3)&~3
        if original[end:aligned]==bytes(aligned-end): available=aligned-start
        if len(new)>available:continue
        result[start:start+available]=new[:-2]+b'\x00 '*((available-len(new))//2)+b'\x00\x00'
        changed.append({'offset':start,'source':value,'korean':replacements[value],'slot_bytes':available})
        T[value]=replacements[value];used.add(value)
    allowed=set()
    for c in changed:
        p=c['offset'];slot=c['slot_bytes'];allowed.update(range(p,p+slot))
        assert result[p:p+len(c['korean'].encode('utf-16-be'))].decode('utf-16-be')==c['korean']
    assert len(result)==len(original)
    assert all(a==b or i in allowed for i,(a,b) in enumerate(zip(original,result)))
    return bytes(result),changed,used


def main():
    assets, changed, used, occurrences = build_assets()
    strings, common_changes, common_used = build_common_strings()
    used |= common_used
    font, fontinfo = make_font(used)
    head = (ROOT/'prior/Layer0_first_8MB.bin').read_bytes()
    names_size = be32(head,8)
    manifest = {'format_version':1, 'archive_name':'Layer0.Arch00',
        'original_size':1452989910, 'prefix_size':len(head), 'original_prefix_sha256':sha(head),
        'xex_sha256':sha((ROOT/'default_input/default.xex').read_bytes()), 'targets':[]}
    for idx, raw, name in [(11,strings,'common_strings.bin'),(12,strings,'common_strings.bin'),(769,assets,'ui_assets.bin'),(770,font,'korean_font.bin')]:
        e = 48+names_size+idx*32
        _,offset,csize,usize,flag = struct.unpack_from('>IQQQI', head,e)
        assert flag == 1
        compressed = zlib.compress(raw,9)
        assert zlib.decompress(compressed) == raw
        (OUT/'payload'/name).write_bytes(compressed)
        manifest['targets'].append({'index':idx, 'entry_offset':e, 'original_entry_hex':head[e:e+32].hex(),
            'original_offset':offset, 'original_compressed_size':csize, 'original_sha256':sha(head[offset:offset+csize]),
            'payload':'payload/'+name, 'payload_size':len(compressed), 'payload_sha256':sha(compressed), 'raw_size':len(raw)})
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (OUT/'ui_translations.json').write_text(json.dumps(T,ensure_ascii=False,indent=2),encoding='utf-8')
    shutil.copy2(ROOT/'prior/Noto-LICENSE.txt', OUT/'FONT_LICENSE.txt')
    report = {'unique_translated_texts':len(used),'xus_translated_occurrences':occurrences,'changed_xus_files':changed,'common_string_changes':common_changes,
        'font':fontinfo,'target_locales':['en-US','ko-kR'],
        'untranslated_english_texts':[s for s in json.loads((ROOT/'prior/xus_texts.json').read_text()) if s not in used],
        'validation':['Every original XUS roundtrips exactly','All modified XUS parse and preserve property keys',
        'Non-target XUIZ assets remain byte-identical','BC3 tiling/endian roundtrip is exact',
        'All translated non-whitespace characters have font glyphs','Both compressed payloads decompress exactly'],
        'runtime_tested':False,'story_dialogue_translated':False}
    (OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k not in ['changed_xus_files','untranslated_english_texts','common_string_changes']},ensure_ascii=False,indent=2))
    print('Common database strings modified:',len(common_changes))
    print('Payload sizes:',[(t['payload'],t['payload_size']) for t in manifest['targets']])


if __name__ == '__main__': main()
