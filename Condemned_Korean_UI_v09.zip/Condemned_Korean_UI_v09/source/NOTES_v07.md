# 0.7 — 출처 표기를 우측 상단으로 이동

사용자 화면 image(20260929-122405).png에서 종이 라벨에 '한글화: 슬림쉐'까지만 표시됐다.
사용자가 전체 이름 표시와 우측 상단 배치를 요청했다.

원인: MenuLabel은 종이 스킨을 쓰는 XuiControl이며, 좁은 내부 글자 영역에 전체 이름이 맞지 않았다.
0.7은 기존 MenuLabel을 원래의 '주 메뉴'로 되돌리고 별도의 XuiText를 추가한다.
새 ID KoreanCreditText, 텍스트 '한글화: 슬림쉐이디', 1280x720 기준 위치 (860,24),
너비 360, 높이 48, PointSize 26, 색 ARGB FFF5EDDE, 회전 없음. 기존 XuiText의 TextStyle 0x410 사용.

frontEndMenu.xur의 STRN에 두 문자열, VECT에 위치·피벗, QUAT에 항등 회전을 추가하고
XuiScene 자식 수를 11에서 12로 바꿨다. 새 텍스트는 이 게임의 기존 XuiText leaf 형식을 사용한다.
모든 원본 노드 바이트와 속성을 유지했다. 두 locale XUS에서 새 요소의 Text/PointSize도 제공한다.
실제 달라진 UI 리소스는 frontEndMenu.xur 및 en-US/ko-kR frontEndMenu.xus의 세 개뿐이다.
대사·글꼴 압축 페이로드는 0.6과 바이트 단위로 동일하다.

검증: 별도의 구조 파서로 기존/새 XUR 트리를 전부 읽었다. 모든 기존 노드와 속성이 같고
새 텍스트의 참조, 속성 수, 위치와 전체 이름을 확인했다. 원본 메뉴 연결도 동일하다.
폰트 측정상 기본 문자열 폭 176.6px. 2배를 적용한 353.2px도 확보된 너비 360px 안이다.
이는 글자 영역 계산이며 Xenia 실기 화면 검증을 뜻하지 않는다.
Linux PowerShell 7.4.6 + 원본 8MiB prefix fixture에서 0.6 설치 → 0.7 교체 → 원본 완전 복원 통과.
실행 파일과 저장 파일 sentinel은 변경되지 않았다.
실제 Windows/Xenia 0.7 화면 표시와 메뉴 탐색은 후속 사용자 확인이 필요하다.

재생성: python build_v07.py V06_PACKAGE NEW_V07_PACKAGE
검증: python verify_v07.py V06_PACKAGE
빌더는 이전 패키지를 복사하고 UI·설치기·manifest를 갱신한다. 이번 문서와 새 검증 소스는 배포 시 추가한다.
독립 파서의 XUR v5 구조/속성 순서는 공개 XUIHelper 자료와 실제 게임 바이트를 대조했다:
https://github.com/SGCSam/XUIHelper/tree/main/XUIHelper.Core/XUR/V5
https://github.com/SGCSam/XUIHelper/blob/main/XUIHelper.Core/Assets/Extensions/V5/XuiElements.xml
외부 프로그램 소스나 XML 원문은 이 배포 ZIP에 포함하지 않았다.
