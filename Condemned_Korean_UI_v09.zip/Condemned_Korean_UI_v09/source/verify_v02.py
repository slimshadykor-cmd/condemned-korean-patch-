"""Verify against the supplied original 00012_DARK.Strdb00p.

Usage: python verify_v02.py /path/to/00012_DARK.Strdb00p
This script only reads files and never patches the game.
"""
from pathlib import Path
import hashlib
import json
import sys
import zlib

package = Path(__file__).resolve().parent.parent
original = Path(sys.argv[1]).read_bytes()
report = json.loads((package / 'build_report.json').read_text())
manifest = json.loads((package / 'manifest.json').read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
assert sha(original) == report['common_original_sha256']
patched = zlib.decompress((package / 'payload/common_strings.bin').read_bytes())
assert len(original) == len(patched)
assert sha(patched) == report['common_fixed_sha256']
changes = {v['offset']:v for v in report['common_string_changes']}

def entries(data):
    start = 0x17548
    while start < len(data):
        end = start
        while end + 2 <= len(data) and data[end:end+2] != b'\0\0':
            end += 2
        if end + 2 > len(data):
            return
        yield start, data[start:end]
        start = (end + 5) & ~3

before, after = list(entries(original)), list(entries(patched))
assert len(before) == len(after)
allowed = set()
for c in changes.values():
    allowed.update(range(c['offset'], c['offset']+c['slot_bytes']))
assert all(a == b or i in allowed for i,(a,b) in enumerate(zip(original,patched)))
seen = set()
for (old_start,old),(new_start,new) in zip(before,after):
    assert old_start == new_start
    if old_start in changes:
        assert new.decode('utf-16-be').rstrip(' ') == changes[old_start]['korean']
        seen.add(old_start)
    else:
        assert old == new
assert seen == set(changes)
for target in manifest['targets']:
    payload = (package / target['payload']).read_bytes()
    assert len(payload) == target['payload_size']
    assert sha(payload) == target['payload_sha256']
    assert len(zlib.decompress(payload)) == target['raw_size']
assert manifest['targets'][0]['payload_sha256'] == manifest['targets'][1]['payload_sha256']
print('PASS: all sequential entry starts preserved; 52 intended changes; all payload sizes and hashes verified.')
