"""python verify_v07.py V06_PACKAGE
Independently parse the old/new XUR trees, then compare every original node.
Format cross-check: https://github.com/SGCSam/XUIHelper (V5 DATA reader/schema).
No external code or XML is required by this verifier.
"""
from pathlib import Path
import copy,hashlib,json,struct,sys,zlib
P=Path(__file__).resolve().parent.parent;BASE=Path(sys.argv[1])
u16=lambda b,p:struct.unpack_from('>H',b,p)[0]
u32=lambda b,p:struct.unpack_from('>I',b,p)[0]
sha=lambda b:hashlib.sha256(b).hexdigest()
def unpack_assets(path):
 b=zlib.decompress(path.read_bytes());assert b[:4]==b'XUIZ' and u32(b,8)==len(b)
 base=22+u32(b,16);p=22;rows=[]
 for _ in range(u16(b,20)):
  size,off,n=struct.unpack_from('>IIB',b,p);name=b[p+9:p+9+n*2].decode('utf-16-be');p+=9+n*2;rows.append((name,base+off,size))
 assert p==base
 return {name:(b[start:start+size],b[start+size:rows[i+1][1] if i+1<len(rows) else len(b)]) for i,(name,start,size) in enumerate(rows)}
def pairs(b):
 assert b[:6]==b'XUIS\x01\x00' and u32(b,6)==len(b)
 p=12;r={}
 for _ in range(u16(b,10)):
  a=[]
  for _ in range(2):
   n=u16(b,p);p+=2;a.append(b[p:p+n*2].decode('utf-16-be'));p+=n*2
  assert a[1] not in r;r[a[1]]=a[0]
 assert p==len(b)
 return r

# Type/property ordering for the seven classes present in this game's menu.
# These factual field definitions let the reader walk all properties and children,
# rather than assuming the writer's byte offsets are valid.
schema={
'XuiElement':(None,'Id:s Width:f Height:f Position:v Scale:v Rotation:q Opacity:f Anchor:u Pivot:v Show:b BlendMode:u DisableTimelineRecursion:b DesignTime:b ColorWriteFlags:u ClipChildren:b EnableEffects:b DisableFocusRecursion:b GripTarget:b Hittable:b LayoutLineBreak:b LayoutFloat:b Column:u Row:u ColumnSpan:u RowSpan:u ColorFactor:u CenterPivot:b'),
'XuiCanvas':('XuiElement',''),
'XuiControl':('XuiElement','ClassOverride:s Visual:s Enabled:b UnfocusedInput:b NavLeft:s NavRight:s NavUp:s NavDown:s NavTabForward:s NavTabBackward:s Text:s PointSize:f ImagePath:s'),
'XuiScene':('XuiControl','DefaultFocus:s TransFrom:s TransTo:s TransBackFrom:s TransBackTo:s InterruptTransitions:u IgnorePresses:b RecurseTransitions:b'),
'XuiButton':('XuiControl','PressKey:u PressAnimObject:s PressAnimStartFrame:s PressAnimEndFrame:s FocusAnimObject:s FocusAnimStartFrame:s FocusAnimEndFrame:s'),
'XuiNavButton':('XuiButton','PressPath:s StayVisible:b SrcTransIndex:u DestTransIndex:u'),
'XuiText':('XuiElement','Text:s TextColor:u DropShadowColor:u PointSize:f Font:s TextStyle:u LineSpacingAdjust:i TextScale:f')}
def tree(b):
 assert b[:8]==b'XUIB\0\0\0\5' and u32(b,14)==len(b)
 count=u16(b,18);sections={};end=20+12*count
 for i in range(count):
  tag,off,size=struct.unpack_from('>4sII',b,20+i*12);assert off==end;end+=size;sections[tag]=b[off:end]
 assert end==len(b)
 strings=[''];p=0;s=sections[b'STRN']
 while p<len(s):
  n=u16(s,p);p+=2;strings.append(s[p:p+n*2].decode('utf-16-be'));p+=n*2
 assert p==len(s)
 vec=list(struct.iter_unpack('>3f',sections[b'VECT']));quat=list(struct.iter_unpack('>4f',sections[b'QUAT']))
 data=sections[b'DATA'];p=0
 def get(fmt):
  nonlocal p
  val=struct.unpack_from('>'+fmt,data,p)[0];p+=struct.calcsize('>'+fmt);return val
 def value(kind):
  if kind=='s':return strings[get('H')]
  if kind=='v':return vec[get('I')]
  if kind=='q':return quat[get('I')]
  return get({'f':'f','b':'B','i':'i','u':'I'}[kind])
 def hierarchy(cls):
  parent,fields=schema[cls]
  return (hierarchy(parent) if parent else [])+[fields]
 def node():
  cls=strings[get('H')];flags=get('B');result={'class':cls,'properties':{},'children':[]}
  assert flags&~3==0,'This menu has no timelines or unknown flags.'
  if flags&1:
   n=get('H')
   for fields in hierarchy(cls):
    packed=get('B');masks=get('B') if packed&7==1 else None
    if packed==0:continue
    if masks is None:
     masks=0
     for _ in range(packed&7):masks=masks*256+get('B')
    props=[f.split(':') for f in fields.split()]
    assert masks>>len(props)==0
    for i,(name,typ) in enumerate(props):
     if masks&(1<<i):result['properties'][name]=value(typ)
   assert len(result['properties'])==n,(cls,result)
  if flags&2:
   n=get('I')
   for _ in range(n):result['children'].append(node())
  return result
 result=node();assert p==len(data),(p,len(data));return result

a=unpack_assets(BASE/'payload/ui_assets.bin');b=unpack_assets(P/'payload/ui_assets.bin')
assert a.keys()==b.keys()
changed=set()
for name,(content,trailer) in b.items():
 assert trailer==a[name][1]
 if content!=a[name][0]:changed.add(name)
assert changed=={'frontEndMenu.xur','en-US\\frontEndMenu.xus','ko-kR\\frontEndMenu.xus'}
old=tree(a['frontEndMenu.xur'][0]);new=tree(b['frontEndMenu.xur'][0])
assert old['class']=='XuiCanvas' and new['class']=='XuiCanvas'
scene=new['children'][0];assert scene['class']=='XuiScene' and len(scene['children'])==12
credit=scene['children'][-1];assert credit['class']=='XuiText'
p=credit['properties']
assert p=={'Id':'KoreanCreditText','Width':360.,'Height':48.,'Position':(860.,24.,0.),
           'Rotation':(0.,0.,0.,1.),'Pivot':(0.,0.,0.),'Text':'한글화: 슬림쉐이디',
           'TextColor':0xfff5edde,'PointSize':26.,'TextStyle':0x410},p
comparison=copy.deepcopy(new);comparison['children'][0]['children'].pop();assert comparison==old
for loc in ['en-US','ko-kR']:
 name=loc+'\\frontEndMenu.xus';op=pairs(a[name][0]);np=pairs(b[name][0])
 assert np.pop('XuiScene1.KoreanCreditText.Text')==p['Text']
 assert np.pop('XuiScene1.KoreanCreditText.PointSize')=='26'
 assert np['XuiScene1.MenuLabel.Text']=='주 메뉴'
 assert np['XuiScene1.MenuLabel.PointSize']=='-1.000000'
 np['XuiScene1.MenuLabel.Text']=op['XuiScene1.MenuLabel.Text'];np['XuiScene1.MenuLabel.PointSize']=op['XuiScene1.MenuLabel.PointSize']
 assert np==op
for name in ['common_strings.bin','korean_font.bin']:
 assert (BASE/'payload'/name).read_bytes()==(P/'payload'/name).read_bytes()
font=zlib.decompress((P/'payload/korean_font.bin').read_bytes());n=u16(font,0x88)+1;cmap=struct.unpack_from('>'+str(n)+'H',font,0x8a);gb=0x8a+n*2+4
units=0
for ch in p['Text']:
 assert ord(ch)<n and cmap[ord(ch)]>0
 glyph=struct.unpack_from('>4H3hH',font,gb+cmap[ord(ch)]*16);units+=glyph[6]
# Conservative fit checks include up to 2x point-to-pixel scaling, allowing more
# margin than the nominal 96dpi 4/3 factor. This is a bounds check, not runtime proof.
width=units/58*p['PointSize']
assert width*2<p['Width']
assert p['Position'][0]+p['Width']<=1220
assert p['Position'][1]+p['Height']<=72
for t in json.loads((P/'manifest.json').read_text())['targets']:
 c=(P/t['payload']).read_bytes();assert sha(c)==t['payload_sha256'] and len(c)==t['payload_size'];assert len(zlib.decompress(c))==t['raw_size']
print('PASS: full old/new XUR trees parse, property counts/string/vector/quaternion references valid; one new non-focusable text leaf.')
print('PASS: all 11 original scene children and properties identical; both locales restore original paper title and provide the full credit.')
print('PASS: exactly 3 menu resources changed; all other assets/trailers, dialogue and font unchanged.')
print(f'PASS: complete credit glyph coverage; nominal width {width:.1f}px, doubled {width*2:.1f}px fits 360px; bounds in upper-right area.')
print('PASS: compressed payload hashes/lengths. Actual Xenia placement remains untested here.')
