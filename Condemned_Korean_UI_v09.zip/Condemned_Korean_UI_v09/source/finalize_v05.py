from pathlib import Path
from collections import Counter
import json,shutil,zipfile,hashlib,re
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'Condemned_Korean_UI_v05'
added=json.loads((ROOT/'gameplay_translations_v05.json').read_text())
report=json.loads((OUT/'build_report.json').read_text())
retained=json.loads((ROOT/'retained_catalog_v05.json').read_text())
report['v05_revised_count']=2
report['retained_catalog_count']=len(retained)
report['installer_validation']='PASS: shipped PowerShell scripts parse; Linux PowerShell 7.4.6 with 8MiB original-prefix fixture: v04 apply -> v05 upgrade -> byte-exact original restore. Windows/Xenia v05 not executed.'
report['category_counts_added_v05']=dict(Counter(r['category'] for r in added))
report['xui_unique_translated_texts']=report.pop('unique_translated_texts',216)
report['common_string_changes']=[({**r,**next((a for a in added if a['offset']==r['offset']),{})}) for r in report['common_string_changes']]
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'translations_added_v05.json').write_text(json.dumps(added,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'gameplay_translations.json').write_text(json.dumps(report['common_string_changes'],ensure_ascii=False,indent=2),encoding='utf-8')
for name in ['translate_v05.py','build_v05.py','verify_font_v05.py','test_installer_v05.py','finalize_v05.py','retained_catalog_v05.json']:
    shutil.copy2(ROOT/name,OUT/'source'/name)
catalog=json.loads((ROOT/'all_strings.json').read_text())
changed={r['offset']:r for r in report['common_string_changes']}
assert len(changed)==2091
assert not [r for r in retained if '<%page%>' in r['text'] or '<%time%>' in r['text']]
sample_ids=[2188,2118,214,2994,255,2290,8,47,138,199,210,343,407,524,636,691,1429,1686,1788,1956,1964,2999]
samples=[]
for i in sample_ids:
    r=changed[catalog[i]['offset']]
    samples.append({'catalog_index':i,**r})
(OUT/'source/regressions_v05.json').write_text(json.dumps(samples,ensure_ascii=False,indent=2),encoding='utf-8')
verification='''PASS: 2091 intended DB changes; original sequential entry boundaries and byte length preserved.
PASS: bytes outside translated entry slots unchanged.
PASS: controller/printf placeholders, page markers and time values preserved.
PASS: all source-catalog page/timed dialogue entries translated.
PASS: complete non-ASCII March 25 report translated at 0x2ae7c; invalid ASCII suffix excluded from remaining list.
PASS: all translated characters present in the 2048x2048 BC3/XPR font.
PASS: transparent zero-advance U+200B; original 325 glyph records and original texture region preserved.
PASS: real font atlas decoded and sample output visually inspected.
PASS: shipped PowerShell scripts parse.
PASS: real Linux PowerShell 7.4.6 with original 8MiB prefix fixture: v04 apply -> v05 upgrade -> byte-exact original restore.
LIMIT: actual Windows/Xenia v05 execution and complete playthrough not performed here.
'''
(OUT/'source/verification_v05.txt').write_text(verification,encoding='utf-8')

readme='''컨뎀드 Xbox 360 한글화 0.5 — 전체 대사·문서 확장판

0.5만 사용하면 됩니다
ISO를 푼 원본 게임 폴더에 바로 적용할 수 있습니다.
0.1~0.4를 먼저 설치할 필요가 없습니다.
이미 이전 버전을 적용한 폴더도 설치 기록과 원본 백업이 남아 있으면 자동으로 교체합니다.

설치
1. 게임과 Xenia를 완전히 종료합니다.
2. ZIP을 풀고 Condemned_Korean_UI_v05 폴더를 게임 폴더 안에 넣습니다.
   default.xex, Layer0.Arch00, Condemned_Korean_UI_v05 폴더가 나란히 있으면 됩니다.
3. Condemned_Korean_UI_v05 안의 RUN_FIX.bat를 실행합니다.
4. FIX APPLIED가 나오면 Xenia에서 같은 게임 폴더의 default.xex를 실행합니다.

기존 .bak 백업과 .state.json 설치 기록을 삭제하거나 이름을 바꾸지 마세요.
설치기는 기존 원본 백업을 검증하여 복원한 뒤 0.5를 적용합니다.
약 1.6GB 이상의 여유 공간이 필요합니다. 파일 복사와 검증 중 창을 닫지 마세요.
별도로 PowerShell 7이나 Python을 설치할 필요는 없습니다.
ERROR가 나오면 해당 창을 캡처해 주세요. FIX APPLIED가 없으면 설치 완료가 아닙니다.

번역 범위
- 제공된 영어/기본 문자열 DB에서 식별한 캠페인 대사 전체: 도입부, 무전, 후반부, 엔딩 포함
- 수사·행동·목표·전투·수집 안내, 무기 이름, 장 설명, 도전 과제
- 메뉴와 확인/경고 창의 동적 문구
- 선전 자료, 언어학 연구실 문서, 잠입 요원 기록 및 최종 보고
- 이전 버전의 메뉴와 로딩 보고서 번역 포함
0.4 대비 새 문구 1,424개를 추가하고 2개 항목의 줄바꿈을 수정했습니다.
누적 DB 번역은 2,091개 항목입니다.

이번 화면 제보 반영
- This is Agent Thomas speaking. → 토머스 요원입니다.
- Investigate → 조사
- Warning → 경고
- 체크포인트를 불러올 때 나타나는 영문 확인창 번역
- 탐지 도구 안내와 로사의 첫 전화 설명에 읽기 쉬운 줄바꿈 추가

확인 범위와 남은 한계
자막 페이지와 표시 시간, 버튼 표시 및 수치 형식을 유지했습니다.
원본 DB 구조와 글꼴을 검사했고 0.4에서 0.5로 교체한 뒤 원본 복원까지 파일 테스트를 통과했습니다.
검증 파일은 실제 원본 앞부분 8MiB와 Linux PowerShell을 사용했습니다.
실제 Windows/Xenia에서 0.5의 전 구간 플레이 확인은 아직 하지 못했습니다.
이미지·동영상 자체에 새겨진 영문과 에뮬레이터/시스템 화면은 이 텍스트 패치 범위에 포함되지 않습니다.
원본 DB에 섞인 다른 게임용 잔여 대사, 멀티플레이/서버 관리 문구, 내부 식별자는 보존했습니다.
남은 영어가 실제 플레이에서 보이면 장면과 문구를 함께 캡처해 주세요.

원본 복원
게임을 종료하고 이 폴더의 RUN_RESTORE.bat를 실행합니다.
0.5 백업: Layer0.Arch00.pre_KoreanUI_v05.bak
0.5 설치 기록: Condemned_KoreanUI_v05.state.json

W키 입력 문제
Caps Lock을 끄고 Shift에서 손을 뗀 뒤 W를 다시 눌러 보세요.
게임 화면을 클릭해 입력 초점을 돌려 주세요.
계속 발생하면 xenia-canary.config.toml과 W만 안 되는지 A/S/D도 안 되는지 알려 주세요.
게임 한글 패치와 Xenia 키 설정은 별개입니다.

번역 및 제작 기록
translations_added_v05.json: 이번 버전의 추가·수정 번역
gameplay_translations.json: 누적 DB 번역 대조표
font_preview.png: 실제 압축 글꼴을 복원해 만든 미리보기이며 게임 화면이 아닙니다.
source: 후속 제작용 스크립트와 검증 기록. 일반 설치에는 사용할 필요가 없습니다.
JSON만 편집해서는 실제 패치가 바뀌지 않습니다.
글꼴 및 참고 코드 라이선스는 FONT_LICENSE.txt와 XENIA_LICENSE.txt에 있습니다.
'''
(OUT/'README_KR.txt').write_text(readme,encoding='utf-8-sig',newline='\r\n')
notes='''# 0.5 제작 기록

사용자 요청: 첫 무전 인사말 누락 수정 후 전체 게임 텍스트로 번역 범위 확대.
화면 증거: 0.4에서 대사와 수사 안내의 한글 표시는 작동함. Investigate와 체크포인트 복원 경고는 영어였음.

- 원본 영어/기본 DB의 모든 페이지/시간 태그 대사를 번역. 태그 없는 캠페인 대사와 수집 문서도 목록 전체를 검토해 추가.
- 새 DB 항목 1424개, 줄바꿈 수정 2개, 누적 2091개.
- 기존 영어 ASCII 추출기는 독일어 3월 25일 보고서의 일부만 630번으로 기록했음. 실제 시작 0x2ae7c의 완전한 항목을 번역하고 잘못된 접미부 기록은 남은 문구 목록에서 제외.
- retained_catalog_v05.json에는 게임 외 잔여 문자열/멀티플레이 및 엔진 문구/내부 식별자를 그대로 기록. 전체 DB의 영문을 무조건 게임 대사라고 간주하지 않음.
- 글꼴은 2048x2048 유지, 한글 827자, 원본 글리프 325개 및 투명 패딩 글리프 1개.
- 모든 원본 문자열 시작점과 다음 항목 위치 유지. 짧아진 문구는 투명하고 전진 폭이 0인 U+200B로 채움.
- 원본 라틴 문자와 컨트롤러 아이콘의 글리프/텍스처 보존.
- Xbox 기본/영어 DB 두 항목에 같은 새 문자열 payload 적용. UI assets는 이전 사용자 확인본 유지.
- 이전 0.1/0.2/0.3/0.4 복원 코드와 manifest는 원래 배포본 그대로 포함.

제작 스크립트는 work 폴더 구조 기준이다. 재생성에는 이전 0.4 패키지, 원본 DB,
원본 font_pack 리소스, NotoSansCJKkr-Regular.otf가 필요하다.
all_strings.json의 번호는 추출 순번이며 게임 내부 ID가 아니다.
이 패키지의 source/verify_v05.py에 원본 00012_DARK.Strdb00p 경로를 넘기면 DB와 글꼴을 검증할 수 있다.
실제 0.5 전 구간 구동은 사용자 후속 플레이로 확인해야 한다. 영상/이미지 안의 글자는 이 DB 작업과 별도다.
'''
(OUT/'source/NOTES_v05.md').write_text(notes,encoding='utf-8')
archive=ROOT.parent/'Condemned_Korean_UI_v05_FullText.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(OUT.rglob('*')):
        if f.is_file() and '__pycache__' not in f.parts:
            z.write(f,f.relative_to(ROOT))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'new':1424,'total':2091,'retained':len(retained)},ensure_ascii=False))
