"""Fixture test, NOT a full-game test.
python test_installer_v07.py V06_PACKAGE RESOURCE_DIRECTORY POWERSHELL_PATH TEST_DIRECTORY
Resources: Layer0_first_8MB.bin, default.zip. Never pass a real game directory as TEST_DIRECTORY.
"""
from pathlib import Path
import hashlib,json,os,shutil,struct,subprocess,sys,zipfile
P=Path(__file__).resolve().parent.parent
BASE,RES,PWSH,FIX=map(lambda s:Path(s).resolve(),sys.argv[1:5])
assert not FIX.exists(), 'Test directory must not exist.'
FIX.mkdir();game=FIX/'game';game.mkdir()
original=(RES/'Layer0_first_8MB.bin').read_bytes();(game/'Layer0.Arch00').write_bytes(original)
with zipfile.ZipFile(RES/'default.zip') as z:xex=z.read('default.xex');(game/'default.xex').write_bytes(xex)
h=bytearray(48);h[:4]=b'RATL';struct.pack_into('>IIII',h,4,3,1,0,0);(game/'Layer1.Arch00').write_bytes(h+b'\0')
save=game/'savedata';save.mkdir();(save/'checkpoint.sentinel').write_bytes(b'Save-data-must-remain-unchanged')
parse="$ErrorActionPreference='Stop'; Get-ChildItem -LiteralPath '"+str(P).replace("'","''")+"' -Filter *.ps1 -Recurse | ForEach-Object { $t=$null; $e=$null; [void][System.Management.Automation.Language.Parser]::ParseFile($_.FullName,[ref]$t,[ref]$e); if($e.Count){throw ($e | Out-String)} }; Write-Host 'PASS: shipped PowerShell scripts parse.'"
subprocess.run([str(PWSH),'-NoProfile','-Command',parse],check=True)
for src in [BASE,P]:
    dst=FIX/src.name;shutil.copytree(src,dst)
    for m in dst.rglob('manifest.json'):
        j=json.loads(m.read_text());j['original_size']=len(original);m.write_text(json.dumps(j))
    if os.name!='nt':
        f=dst/'Upgrade.ps1';s=f.read_text(encoding='utf-8-sig')
        s=s.replace("$psExe = Join-Path $PSHOME 'powershell.exe'","$psExe = Join-Path $PSHOME 'pwsh'")
        f.write_text(s,encoding='utf-8-sig')
def run(script,mode=None):
    args=[str(PWSH),'-NoProfile','-File',str(script),'-GameDirectory',str(game)]
    if mode:args+=['-Mode',mode]
    subprocess.run(args,check=True)
run(FIX/BASE.name/'Patch.ps1','Apply')
assert (game/'Condemned_KoreanUI_v06.state.json').exists()
run(FIX/P.name/'Upgrade.ps1')
assert not (game/'Condemned_KoreanUI_v06.state.json').exists()
assert (game/'Condemned_KoreanUI_v07.state.json').exists()
b=(game/'Layer0.Arch00').read_bytes();m=json.loads((P/'manifest.json').read_text());allowed=set()
for t in m['targets']:
    pos=t['entry_offset'];allowed.update(range(pos,pos+32))
    _,off,cs,us,flag=struct.unpack_from('>IQQQI',b,pos)
    assert flag==1 and us==t['raw_size'] and b[off:off+cs]==(P/t['payload']).read_bytes()
assert all(x==y or i in allowed for i,(x,y) in enumerate(zip(original,b)))
assert (game/'default.xex').read_bytes()==xex
assert (save/'checkpoint.sentinel').read_bytes()==b'Save-data-must-remain-unchanged'
run(FIX/P.name/'Patch.ps1','Restore')
assert (game/'Layer0.Arch00').read_bytes()==original
assert not (game/'Condemned_KoreanUI_v07.state.json').exists()
assert (game/'default.xex').read_bytes()==xex
assert (save/'checkpoint.sentinel').read_bytes()==b'Save-data-must-remain-unchanged'
print('PASS: PowerShell v06 apply -> v07 upgrade -> byte-exact original restore on 8MiB fixture; executable and save sentinel untouched.')
