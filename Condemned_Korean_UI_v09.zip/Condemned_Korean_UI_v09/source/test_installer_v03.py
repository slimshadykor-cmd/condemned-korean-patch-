from pathlib import Path
import shutil,json,subprocess,zipfile,struct,hashlib
root=Path(__file__).resolve().parent
fixture=root/'installer_test_v03';fixture.mkdir(exist_ok=True)
game=fixture/'game';game.mkdir(exist_ok=True)
original=(root/'resources/Layer0_first_8MB.bin').read_bytes()
(game/'Layer0.Arch00').write_bytes(original)
with zipfile.ZipFile(root.parent/'downloads/default.zip') as z:(game/'default.xex').write_bytes(z.read('default.xex'))
# Minimal unrelated Layer1 directory for the existing no-conflict check.
h=bytearray(48);h[:4]=b'RATL';struct.pack_into('>IIII',h,4,3,1,0,0);(game/'Layer1.Arch00').write_bytes(h+b'\0')
pwsh=Path('/workspace/scratch/f34e7c805924/pwsh_runtime/pwsh')
for version in ('v02','v03'):
 src=root/('Condemned_Korean_UI_'+version);dst=fixture/src.name
 shutil.copytree(src,dst,dirs_exist_ok=True)
 for m in dst.rglob('manifest.json'):
  j=json.loads(m.read_text());j['original_size']=len(original);m.write_text(json.dumps(j))
 if version=='v03':
  f=dst/'Upgrade.ps1';s=f.read_text(encoding='utf-8-sig');s=s.replace("$psExe = Join-Path $PSHOME 'powershell.exe'","$psExe = Join-Path $PSHOME 'pwsh'");f.write_text(s,encoding='utf-8-sig')
# Parse the shipped scripts themselves without changing them.
parse="""$ErrorActionPreference='Stop'; Get-ChildItem -LiteralPath '"""+str(root/'Condemned_Korean_UI_v03')+"""' -Filter *.ps1 -Recurse | ForEach-Object { $t=$null; $e=$null; [void][System.Management.Automation.Language.Parser]::ParseFile($_.FullName,[ref]$t,[ref]$e); if($e.Count){throw ($e | Out-String)} }; Write-Host 'PASS: shipped PowerShell scripts parse.'"""
subprocess.run([str(pwsh),'-NoProfile','-Command',parse],check=True)
def run(script,mode=None):
 args=[str(pwsh),'-NoProfile','-File',str(script),'-GameDirectory',str(game)]
 if mode:args+=['-Mode',mode]
 subprocess.run(args,check=True)
run(fixture/'Condemned_Korean_UI_v02/Patch.ps1','Apply')
assert (game/'Condemned_KoreanUI_v02.state.json').exists()
run(fixture/'Condemned_Korean_UI_v03/Upgrade.ps1')
assert not (game/'Condemned_KoreanUI_v02.state.json').exists()
assert (game/'Condemned_KoreanUI_v03.state.json').exists()
b=(game/'Layer0.Arch00').read_bytes();manifest=json.loads((fixture/'Condemned_Korean_UI_v03/manifest.json').read_text())
allowed=set()
for t in manifest['targets']:
 p=t['entry_offset'];allowed.update(range(p,p+32));_,off,cs,us,flag=struct.unpack_from('>IQQQI',b,p)
 assert flag==1 and us==t['raw_size'];assert b[off:off+cs]==(fixture/'Condemned_Korean_UI_v03'/t['payload']).read_bytes()
assert all(x==y or i in allowed for i,(x,y) in enumerate(zip(original,b)))
run(fixture/'Condemned_Korean_UI_v03/Patch.ps1','Restore')
assert (game/'Layer0.Arch00').read_bytes()==original
assert not (game/'Condemned_KoreanUI_v03.state.json').exists()
print('PASS: real PowerShell on 8 MiB fixture: v02 apply -> v03 upgrade -> byte-exact original restore.')
