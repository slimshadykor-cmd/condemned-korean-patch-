# Current checkpoint: v0.7

See NOTES_v07.md and verify_v07.py for the latest layout fix.

# Current checkpoint: v0.6

See NOTES_v06.md, verification_v06.txt, and verify_v06.py for the current package.
The following records describe earlier versions.

# v0.3 project checkpoint — 2026-09-29

User confirmed v0.2 in Xenia: menus and Hangul render, Normal=보통,
Duck Under and opening dialogue are correctly linked. Seven runtime screenshots.

v0.3 adds 264 source-offset-verified translations: 96 OBJECTIVE blocks,
10 Internal Reports, selected opening/early investigation dialogue, hints and
interaction labels. 316 common-DB changes including the previous 52.
This is a PARTIAL story translation, not a full Chapter 1 or full-game release.

All DB entry boundaries, page markers and exact time tokens are preserved.
Unused slot code units are U+200B; the font contains an explicitly transparent
U+200B glyph with width=advance=0 to avoid space-padding layout expansion.
This new runtime behavior needs confirmation in the game. Font has 550 Hangul
glyphs; original 325 glyph records and original texture region are preserved.
Menu assets payload unchanged from v0.2. Same four archive targets.

Hashes are recorded in build_report.json and manifest.json. verify_v03.py
checks a supplied original 00012 DB. Authoring indices refer only to
source/all_strings.json, NOT game IDs. Builder and integration test are
workspace checkpoints, not standalone portable tools. Reproduction requires
v0.2 package, original DB, asset_770.bin from the supplied 8MiB prefix and Noto font.

Installer core retained; v01/v02 restored through exact previous scripts and
manifests, then v03 applied. Shipped scripts parsed successfully.
PowerShell 7.4.6 Linux executed v02 install -> v03 upgrade -> byte-exact restore
on an 8MiB fixture. Fixture-only changes: original_size and child binary name.
Windows and actual Xenia v03 have NOT been executed.

Keyboard evidence: official canary_experimental binding table uses _W for
left stick up and ^W for dpad up. OnKey uses CapsLock OR Shift as uppercase.
Default left-stick press is F. User config not supplied, so this remains a
supported candidate cause, not a confirmed diagnosis.

The following are inherited format research and v0.1/v0.2 history.

# v0.2 correction — 2026-09-29

The user confirmed Hangul renders. Seven runtime screenshots revealed dynamic text misalignment.
An independent sequential reader reproduced Normal -> Gas Pipe, Duck Under -> Load the game saved in this slot., and three dialogue mismatches exactly.
The new payload fixes 52 entries with space padding. Original per-entry aligned boundaries and all other bytes are preserved.
Menu assets and font payloads are identical to v0.1. No new characters or dialogue translations are added.
Windows installer and Xenia v0.2 runtime remain untested. RUN_FIX safely restores a verified v0.1 installation before applying v0.2.

The following is the inherited v0.1 format checkpoint; its runtime-unverified notes describe that prior creation stage.

# Condemned Korean UI project checkpoint — 2026-09-29

Scope delivered: UI 0.1, NOT a full story translation. No Xenia runtime execution performed.

Authoritative inputs already supplied:
- default.zip (default.xex, default.archcfg, autoexec.cfg), libfile_a3f3b0617c4c8191a428775ebe6bdc57.
- Condemned_Diagnostic.zip, libfile_74b375b0107c81919d1984da050eb2c8: actual Layer0_first_8MB.bin.
- 00012_DARK.Strdb00p, libfile_eea9832bdbc08191af23302500dc236b.

RATL v3: big endian; 48-byte header. Names size at +8; folder count +12; file count +16.
File table immediately after names. Each entry is >IQQQI: name offset, file offset, compressed size, raw size, flag.
Folder records follow the file table and are 16 bytes each; folder names are complete paths.
Original Layer0 size 1,452,989,910; names 38,536; files 1,318; folders 293.
Index 11 and 12 are default and English DARK.Strdb00p; their decompressed bytes are identical.
Index 769 is global\ui\XUI\assets.xzp; index 770 is global\ui\XUI\font_pack.xpr.
Both entire resources exist within the 8MiB sample. No additional StartupAssets upload was needed.
The previous one-word patch targeted StrDB, but menu labels live in XUI XUS files.
Do not repeat the old test strategy or claim the menu is driven solely by StrDB.

assets.xzp is XUIZ v1, 464 entries. Header length is 22 bytes. The u32 at +16 is the following directory length.
Entry: u32 file length, u32 offset relative to data base, u8 UTF-16 filename length, filename bytes.
Data base = 22 + directory length. Each payload has an 8-byte FILETIME + u16 path length + UTF-16 source path trailer.
Rebuild directory offsets and total length while preserving all trailers. Non-target resource content remains identical.
XUS: XUIS + 0x0100 + u32 total size + u16 pair count. Each pair has length-prefixed UTF-16BE value then property key.
Translate only property keys ending .Text. Resource paths and property identifiers are untouched.
English and Korean tables are patched; XUR scene layout bytes are untouched.

Font XPR2: CPU header size at +4 excludes the initial 12 bytes; GPU data length at +8.
Two 16-byte resources TX2D and USER; original CPU-relative offsets 0x40 and 0x68.
FontData version 5: version u32; four f32 metrics; max wchar u16; (max+1) u16 charmap; u32 glyph count; 16-byte glyph records.
Glyph record >4H3hH: UV rectangle, left offset, width, advance, channel mask.
Runtime parser verified in uploaded executable at 0x82A45EA0, renderer glyph mask logic near 0x82A4724C.
Original font: 325 glyphs, max wchar 355. Texture: tiled BC3/DXT5, 8-in-16 swap, 512x1024.
Original controller icon RGB/alpha blocks are preserved exactly; do not flatten them into monochrome text.
A few original UVs wrap beyond the old texture dimensions: explicitly repeat source blocks in the enlarged atlas.
New texture: 2048x2048. FontData table grows for actual translated Hangul; new glyphs start right of original content.
The new glyphs were decoded from the final BC3 resource and visually inspected (font_preview.png).

XEX is basic-compressed/encrypted XEX2; analysis used Xenia's published format and key.
Do not distribute a modified executable: installer leaves default.xex byte-identical.
autoexec.cfg has XUIRender=1. default.archcfg lists Layer1 then Layer0.
Actual Layer1 contents have not been supplied. Installer checks its directory and refuses conflicting target resources.

Installer: PowerShell 5.1-compatible APIs, prepared compressed payloads; no ZLibStream dependency.
Stages a full copy, appends payloads on 16-byte boundaries, updates the four target directory records,
verifies written resources, and uses File.Replace with original backup. Restore checks complete SHA-256 hashes.
Verified via actual PowerShell 7.4.6 on Linux using an 8MiB fixture and independent Python binary checks.
Windows 5.1 and the game itself are unexecuted. Treat runtime compatibility and layout as unverified.

Build source is a checkpoint, not a standalone end-user tool. For reproduction place build_ui_patch.py at a project root,
ui_translations_base.json there as ui_translations.json, and reconstruct prior/ files from the authoritative inputs above:
Layer0_first_8MB.bin, 00012_DARK.Strdb00p, asset_770.bin, assets.xzp, xus_texts.json;
place uploaded default.xex under default_input/. NotoSansCJKkr-Regular.otf and Noto-LICENSE.txt go under prior/.
Noto source: https://github.com/notofonts/noto-cjk/tree/main/Sans/OTF/Korean
Reference code: https://github.com/xenia-project/xenia/blob/master/src/xenia/gpu/texture_address.h
Also xenos.h, xex_module.cc, and kernel/util/xex2_info.h in the same project.
Common DB replacements MUST retain the original aligned next-entry boundary: use UTF-16BE space padding before the single terminator. NUL padding caused dynamic string indices to shift in v0.1.
No pointer relocation or whole-story translation has been implemented.
