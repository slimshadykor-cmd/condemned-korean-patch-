from pathlib import Path
import struct,zlib,json,sys,importlib.util
from PIL import Image
ROOT=Path(__file__).resolve().parent
p=ROOT/'Condemned_Korean_UI_v03'
b=zlib.decompress((p/'payload/korean_font.bin').read_bytes())
be=lambda off:struct.unpack_from('>I',b,off)[0]
maxc=struct.unpack_from('>H',b,0x88)[0];cmap=struct.unpack_from('>'+str(maxc+1)+'H',b,0x8a);gb=0x8a+(maxc+1)*2;ng=be(gb)
glyphs=[struct.unpack_from('>4H3hH',b,gb+4+i*16) for i in range(ng)]
v=be(0x64);w=(v&8191)+1;h=((v>>13)&8191)+1;t=b[12+be(4):]
# Independent untile calculation, then use Pillow's BC3 decoder.
def address(x,y,pitch):
 q=((((y>>5)*(pitch>>5)+(x>>5))<<6)|(((y>>1)&7)<<3)|(x&7))<<4
 return ((q>>8)<<12)|(((q>>5)&7)<<8)|(((q>>4)&1)<<5)|(q&15)|(((y>>4)&1)<<11)|((((x>>3)&3)^(((y>>3)&1)<<1))<<6)|((y&1)<<4)
linear=bytearray(w*h)
for y in range(h//4):
 for x in range(w//4):
  a=address(x,y,w//4);block=t[a:a+16];o=(y*(w//4)+x)*16
  linear[o:o+16]=b''.join(block[i:i+2][::-1] for i in range(0,16,2))
atlas=Image.frombytes('RGBA',(w,h),bytes(linear),'bcn',3)
g=glyphs[cmap[0x200b]]
assert atlas.crop(g[:4]).getchannel('A').getbbox() is None
assert g[5]==g[6]==0
orig=(ROOT/'resources/asset_770.bin').read_bytes();om=struct.unpack_from('>H',orig,0x88)[0];og=0x8a+(om+1)*2;on=struct.unpack_from('>I',orig,og)[0]
assert [struct.unpack_from('>4H3hH',orig,og+4+i*16) for i in range(on)]==glyphs[:on]
examples=['보통 / 자동 / 숙여서 통과','토머스, 하루 종일 기다릴 순 없어.','좀 움직이자.','목표: 디킨슨 형사를 따라 범죄 현장으로 가라.','어서 가자. 시신은 지금도 썩고 있어.','내부 보고서 #898: 원인 불명의 범죄율 급증','다양한 근접 무기를 사용해 보세요.','경찰 통제선 아래로 몸을 숙여 통과하라.']
canvas=Image.new('RGBA',(1600,600),(21,27,34,255))
for row,txt in enumerate(examples):
 x=30;y=12+row*72
 for ch in txt+'\u200b'*300:
  g=glyphs[cmap[ord(ch)]]
  if g[5]>0:
   crop=atlas.crop(g[:4]);canvas.alpha_composite(crop,(int(x+g[4]),y))
  x+=g[6]
 assert x<1600,(txt,x)
canvas.convert('RGB').save(p/'font_preview.png')
print('PASS: decoded BC3 atlas, transparent zero-advance padding, original 325 glyph records preserved; preview rendered.')
