"""Build v0.6 from a v0.5 package and the user's original resources.
Usage: python build_v06.py BASE_V05 RESOURCE_DIRECTORY OUTPUT_V06
Resources: 00012_DARK.Strdb00p, asset_770.bin, NotoSansCJKkr-Regular.otf.
The output is a new package; input packages and game archives are not edited.
"""
from pathlib import Path
import hashlib, importlib.util, json, re, shutil, struct, sys, zlib

BASE, RES, OUT = map(lambda s: Path(s).resolve(), sys.argv[1:4])
BUILD = OUT.parent / 'v06_build'
sha = lambda b: hashlib.sha256(b).hexdigest()
def jread(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def jwrite(p,o): p.write_text(json.dumps(o,ensure_ascii=False,indent=2),encoding='utf-8')
assert BASE != OUT and not OUT.exists(), 'Output must be a new directory.'
shutil.copytree(BASE, OUT, ignore=shutil.ignore_patterns('__pycache__','installer_test*'))
BUILD.mkdir(exist_ok=True)
(BUILD/'prior').mkdir(exist_ok=True)
catalog = jread(BASE/'source/all_strings.json')
changes = {r['offset']:r.copy() for r in jread(BASE/'gameplay_translations.json')}

# These 18 *input-binding* tokens are printed literally in the Xbox build.
# Use the action's Korean name rather than hardcoding keyboard/controller keys.
# Page/time tokens, printf fields and inline controller glyphs remain intact.
hints = {
1360:'통제선에 다가가 행동 버튼으로\n몸을 숙여 통과하세요.',
1367:'손전등 버튼으로\n불을 켜고 끄세요.',
1378:'수사 도구 버튼으로\n도구를 준비하세요.',
1459:'복부에 채취기를 조준하고\n사용 버튼으로 자료를 수집하세요.',
1462:'증거에 스캐너를 조준하고\n사용 버튼으로 자료를 수집하세요.',
1466:'공격 버튼으로 총을 쏘세요.',
1470:'탄약 확인 버튼을 누르세요.',
1473:'공격 전환 버튼으로\n근접 공격으로 바꾸세요.',
1533:'달리기 버튼으로 달리세요.',
1549:'테이저 버튼으로 발사하세요.',
1554:'발차기 버튼으로\n적을 걷어차세요.',
1629:'공격 버튼으로 무기를 휘두르세요.',
1633:'방어 버튼으로 막으세요.',
1653:'일시 정지 메뉴에서\n목표를 확인하세요.',
1726:'흰 화살표가 모두 안쪽을\n향하게 도구를 조준하세요.',
1730:'화면 테두리가 밝게 빛나도록\n확대·축소를 조절하세요.',
1738:'작은 삼각형이 맞닿도록\n초점을 조절하세요.',
1743:'공격 전환 버튼으로\n사격과 근접 공격을 바꾸세요.',
}
revised = []
def set_line(i,text,reason):
    row=catalog[i];old=changes[row['offset']]
    assert old['source']==row['text']
    if old['korean']==text:return
    oldtext=old['korean'];old['korean']=text
    revised.append({'catalog_index':i,'offset':row['offset'],'source':row['text'],
                    'before':oldtext,'korean':text,'reason':reason})
for i,text in hints.items():set_line(i,text,'literal_input_tag')
set_line(1719,'마치면 계단 옆 철제 책상을\n옮기고 나가세요.','hint_wrapping')

# Speaker is Dickenson, identified by the Becker/Dickenson radio exchange and
# the fire-axe scene. Review exact dialogue entries, not all polite text globally.
# 492 has two speakers: Becker's first two pages stay polite.
speaker_indices=[449,453,455,480,481,484,489,491,492,493,528,531,534,540,547,
                 567,569,2194,2196,2197,2200,2202,2238,2239,2241,2242,2243,
                 2244,2245,2246,2248,2278,2455,2709,2714,2715,2717,2718,2719,2724]
def pages(i,parts):
    old=changes[catalog[i]['offset']]['korean']
    suffix=re.search(r'\s*<%time%>.*$',old)
    assert len(parts)==old.count('<%page%>')+1
    return ' <%page%> '.join(parts)+(suffix.group() if suffix else '')
set_line(2709,'폭발 소리가 들렸어.','dickenson_informal')
set_line(569,pages(569,['베커, 불 좀 꺼.','토머스의 레이저는\n어두워야 잘 보이거든.']),'dickenson_informal')
set_line(567,pages(567,['토머스 요원, 이쪽은 베커 경관이야.','순찰 중에 시신을 발견했지.']),'dickenson_introduction')
set_line(2278,pages(2278,['토머스 요원, 이쪽은 베커 형사야.','순찰 중에 시신을 발견했지.']),'dickenson_introduction')
set_line(2719,pages(2719,['막힌 길을 뚫을 도구는\n근처에서 찾을 수 있어.',
                       '도끼나 대형 망치는\n무기로도 쓸 수 있지.',
                       '강력한 대신 휘두르는 속도가 느려.',
                       '더 빠르게 머리를 깨고 싶으면\n쇠파이프를 써.']),'dickenson_wrapping')
set_line(2724,pages(2724,['그래, 자넨 조언이 좀 필요하지.',
                       '베커와 난 다른 쪽으로 돌아갈 테니\n몸조심해.',
                       '아, 한 가지 더.',
                       '곤란할 땐 테이저로\n적을 잠깐 기절시켜.',
                       '충분히 가까이 있다면\n그 틈에 놈의 무기를 빼앗을 수 있어.']),'dickenson_informal')

original=(RES/'00012_DARK.Strdb00p').read_bytes()
assert sha(original)==jread(BASE/'build_report.json')['common_original_sha256']
data=bytearray(original)
allow_offsets={catalog[i]['offset'] for i in hints}
token=r'<%[^>]+%>|%\d+![^!]+!|%(?:\.\d+)?[sdf]|%%|<\?>'
for p,r in sorted(changes.items()):
    enc=r['source'].encode('utf-16-be')+b'\0\0'
    assert original[p:p+len(enc)]==enc
    slot=(len(enc)+3)&~3
    assert not any(original[p+len(enc):p+slot])
    new=r['korean'].encode('utf-16-be')
    assert len(new)+2<=slot,(p,r['source'],r['korean'],slot)
    expected=re.findall(token,r['source'])
    if p in allow_offsets:
        expected=[t for t in expected if not re.fullmatch(r'<%(?:action|flashlight|tools|fire|ammocheck|togglemelee|sprint|taser|kick|block|pause|aim|move)%>',t)]
    assert expected==re.findall(token,r['korean']),(p,expected,r['korean'])
    assert re.findall(r'<%time%>\s*[\d.]+',r['source'])==re.findall(r'<%time%>\s*[\d.]+',r['korean'])
    data[p:p+slot]=new+b'\x20\x0b'*((slot-len(new)-2)//2)+b'\0\0'
    r['slot_bytes']=slot

# Existing title label (XUR position 800,245; bounds 256x128). Keep the scene
# layout, navigation, and button labels; localize only this title's XUS properties.
credit='한글화: 슬림쉐이디'
T=jread(BASE/'ui_translations.json')
for r in changes.values():T[r['source']]=r['korean']
T['__translation_credit__']=credit
T['__zero_width_padding__']='\u200b'
jwrite(BUILD/'ui_translations.json',T)
shutil.copy2(BASE/'source/build_ui_patch.py',BUILD/'build_ui_patch.py')
for name in ['NotoSansCJKkr-Regular.otf','asset_770.bin']:shutil.copy2(RES/name,BUILD/'prior'/name)
spec=importlib.util.spec_from_file_location('v06_font_builder',BUILD/'build_ui_patch.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
font,info=m.make_font(set(T))
font=bytearray(font)
maxchar=struct.unpack_from('>H',font,0x88)[0]
cmap=struct.unpack_from('>'+str(maxchar+1)+'H',font,0x8a)
gb=0x8a+(maxchar+1)*2+4
struct.pack_into('>hh',font,gb+cmap[0x200b]*16+10,0,0)
info.update(padding_codepoint='U+200B',padding_glyph_index=cmap[0x200b],padding_advance=0)

assets=zlib.decompress((BASE/'payload/ui_assets.bin').read_bytes())
count=m.be16(assets,20);base=22+m.be32(assets,16);p=22;records=[]
for _ in range(count):
    size,off,n=struct.unpack_from('>IIB',assets,p)
    name=assets[p+9:p+9+n*2].decode('utf-16-be')
    records.append((p,name,base+off,size));p+=9+n*2
assert p==base
table=bytearray(assets[:base]);body=bytearray();asset_edits=[]
for i,(entry,name,start,size) in enumerate(records):
    raw=assets[start:start+size];oldraw=raw
    if name in ['en-US\\frontEndMenu.xus','ko-kR\\frontEndMenu.xus']:
        pairs=m.read_xus(raw);found=set()
        for pair in pairs:
            if pair[1]=='XuiScene1.MenuLabel.Text':
                assert pair[0]=='주 메뉴';pair[0]=credit;found.add('text')
            elif pair[1]=='XuiScene1.MenuLabel.PointSize':
                pair[0]='24';found.add('size')
        assert found=={'text','size'}
        raw=m.write_xus(pairs);assert m.read_xus(raw)==pairs
        asset_edits.append({'resource':name,'key':'XuiScene1.MenuLabel.Text','before':'주 메뉴','after':credit,'point_size':24})
    nextstart=records[i+1][2] if i+1<len(records) else len(assets)
    trailer=assets[start+size:nextstart]
    assert len(trailer)==10+m.be16(trailer,8)*2
    struct.pack_into('>II',table,entry,len(raw),len(body))
    body+=raw+trailer
assert len(asset_edits)==2
newassets=table+body;struct.pack_into('>I',newassets,8,len(newassets))
for entry,name,start,size in records:
    n=m.be32(newassets,entry);s=base+m.be32(newassets,entry+4)
    if name not in {x['resource'] for x in asset_edits}:
        assert newassets[s:s+n]==assets[start:start+size],name

for name,raw in [('common_strings.bin',data),('korean_font.bin',font),('ui_assets.bin',newassets)]:
    (OUT/'payload'/name).write_bytes(zlib.compress(raw,9))
manifest=jread(BASE/'manifest.json')
for t in manifest['targets']:
    comp=(OUT/t['payload']).read_bytes()
    t.update(payload_size=len(comp),payload_sha256=sha(comp),raw_size=len(zlib.decompress(comp)))
jwrite(OUT/'manifest.json',manifest)

# Preserve the exact v0.5 restore implementation and manifests as well as 0.1-0.4.
(OUT/'upgrade_v05').mkdir(exist_ok=True)
for name in ['Patch.ps1','manifest.json']:shutil.copy2(BASE/name,OUT/'upgrade_v05'/name)
for name in ['Patch.ps1','Upgrade.ps1']:
    text=(BASE/name).read_text(encoding='utf-8-sig')
    text=text.replace('Korean_UI_v05','Korean_UI_v06').replace('KoreanUI_v05','KoreanUI_v06').replace("version='0.5'","version='0.6'").replace('v0.5','v0.6')
    if name=='Upgrade.ps1':text=text.replace("@('v04','v03','v02','v01')","@('v05','v04','v03','v02','v01')")
    (OUT/name).write_text(text,encoding='utf-8-sig',newline='\r\n')
jwrite(OUT/'gameplay_translations.json',list(changes.values()))
jwrite(OUT/'translations_revised_v06.json',revised)
jwrite(OUT/'ui_translations.json',{k:v for k,v in T.items() if not k.startswith('__')})
jwrite(OUT/'source/literal_input_tag_allowlist_v06.json',[
    {'catalog_index':i,'offset':catalog[i]['offset'],'source':catalog[i]['text'],'korean':hints[i]}
    for i in hints])
jwrite(OUT/'source/dickenson_review_v06.json',[
    {'catalog_index':i,'offset':catalog[i]['offset'],'source':catalog[i]['text'],
     'korean':changes[catalog[i]['offset']]['korean'],
     'speaker_note':'Becker first two pages; Dickenson remaining pages' if i==492 else 'Dickenson (scene/context attribution)'}
    for i in speaker_indices])
jwrite(OUT/'source/menu_credit_v06.json',asset_edits)
report=jread(BASE/'build_report.json')
report.update(version='0.6',runtime_tested=False,common_fixed_sha256=sha(data),
              common_string_changes=list(changes.values()),font=info,
              v06_revised_count=len(revised),v06_literal_input_tags_removed=len(hints),
              v06_dickenson_reviewed_count=len(speaker_indices),v06_menu_credit=asset_edits,
              runtime_evidence_v05='User reports generally good early gameplay; screenshots show literal aim/move tokens, long hint wrapping, and Dickenson axe dialogue.',
              installer_validation='Pending v05 -> v06 fixture validation.',
              validation=['Original DB slot boundaries and total byte length preserved',
                          'All dialogue pages/timings and printf fields preserved',
                          '18 input-binding token exceptions explicitly recorded after runtime evidence',
                          'Only two front-end title XUS resources altered; all other UI resources byte-identical to v05',
                          'Original controller glyphs and texture region preserved',
                          'All current translations and credit covered by font'])
jwrite(OUT/'build_report.json',report)
shutil.copy2(__file__,OUT/'source/build_v06.py')
print(json.dumps({'revised':len(revised),'control_prompts':len(hints),'speaker_entries_reviewed':len(speaker_indices),'font':info,'credit':credit},ensure_ascii=False))
