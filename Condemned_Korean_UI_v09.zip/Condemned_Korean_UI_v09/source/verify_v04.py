"""Read-only validation: python verify_v04.py original_00012_DARK.Strdb00p"""
from pathlib import Path
import json,sys,zlib,hashlib,struct,re
p=Path(__file__).resolve().parent.parent
original=Path(sys.argv[1]).read_bytes()
r=json.loads((p/'build_report.json').read_text())
m=json.loads((p/'manifest.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(original)==r['common_original_sha256']
b=zlib.decompress((p/'payload/common_strings.bin').read_bytes())
font=zlib.decompress((p/'payload/korean_font.bin').read_bytes())
assert sha(b)==r['common_fixed_sha256'] and len(b)==len(original)
changes={x['offset']:x for x in r['common_string_changes']}
def entries(data):
    start=0x17548
    while start<len(data):
        end=start
        while end+2<=len(data) and data[end:end+2]!=b'\0\0':end+=2
        if end+2>len(data):return
        yield start,data[start:end]
        start=(end+5)&~3
A=list(entries(original));B=list(entries(b));assert len(A)==len(B)
found=set()
for (op,ov),(np,nv) in zip(A,B):
    assert op==np
    if op in changes:
        c=changes[op];found.add(op)
        assert nv.decode('utf-16-be').rstrip('\u200b')==c['korean']
        token=r'<%[^>]+%>|%\d+![^!]+!|%(?:\.\d+)?[sdf]|%%'
        assert re.findall(token,c['source'])==re.findall(token,c['korean'])
        assert re.findall(r'<%time%>\s*[\d.]+',c['source'])==re.findall(r'<%time%>\s*[\d.]+',c['korean'])
    else:assert ov==nv
assert found==set(changes)
allowed=set()
for c in changes.values():allowed.update(range(c['offset'],c['offset']+c['slot_bytes']))
assert all(x==y or i in allowed for i,(x,y) in enumerate(zip(original,b)))
maxchar=struct.unpack_from('>H',font,0x88)[0]
cmap=struct.unpack_from('>'+str(maxchar+1)+'H',font,0x8a)
gb=0x8a+(maxchar+1)*2+4
for c in changes.values():
    for char in c['korean']:
        if not char.isspace():assert ord(char)<=maxchar and cmap[ord(char)]>0,char
pad=struct.unpack_from('>4H3hH',font,gb+cmap[0x200b]*16)
assert pad[5]==pad[6]==0
for t in m['targets']:
    comp=(p/t['payload']).read_bytes()
    assert len(comp)==t['payload_size'] and sha(comp)==t['payload_sha256']
    assert len(zlib.decompress(comp))==t['raw_size']
print('PASS: '+str(len(changes))+' intended changes; original DB boundaries; page/timing tokens; glyph coverage; payload hashes.')
