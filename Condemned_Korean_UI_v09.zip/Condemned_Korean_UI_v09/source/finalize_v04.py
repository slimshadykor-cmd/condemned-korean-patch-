from pathlib import Path
import json,shutil,subprocess,zipfile,hashlib

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'Condemned_Korean_UI_v04'
readme='''컨뎀드 Xbox 360 한글화 0.4 — 무전·수사 안내 보완

추가 범위
- 새 DB 문구 351개 추가, 기존 문구 3개 수정. 누적 667개 DB 항목 번역.
- 첫 범죄 현장의 로사 무전: 체온·사인·멍·담뱃재·담배 필터 분석과 주변 대사
- 아파트와 초기 지하철 수사: 사진·현상액·지문·열차 시간표 분석, 밴혼·패럴 통화 등
- 수사 도구 준비, 증거 탐지·수집, 확대·초점 안내
- 장 선택 설명 10개, 게임 내 도전 과제 이름, 로딩 도움말과 행동 안내
- 기존 메뉴, 목표 96개, 로딩 보고서 10개 유지
전체 대사 한글화는 아직 아닙니다. 이 목록 밖의 대사에는 영어가 남아 있습니다.
음성은 원본이며, 게임 내 자막과 안내 문구를 번역한 패치입니다.

설치 — 현재 0.3에서 바로 교체 가능
1. 게임과 Xenia를 완전히 종료합니다.
2. ZIP을 풀고 Condemned_Korean_UI_v04 폴더를 default.xex와 Layer0.Arch00이 있는 게임 폴더에 넣습니다.
   Condemned_Korean_UI_v04 폴더와 default.xex가 나란히 있으면 됩니다.
3. Condemned_Korean_UI_v04 폴더 안의 RUN_FIX.bat를 실행합니다.
4. FIX APPLIED가 나오면 Xenia에서 같은 게임 폴더의 default.xex를 실행합니다.

0.1·0.2·0.3 설치 기록이 있으면 기존 원본 백업을 검증해 복원한 뒤 0.4를 적용합니다.
기존 .bak 파일과 .state.json 파일을 삭제하거나 이름을 바꾸지 마세요.
원본 게임에서 처음 적용할 때도 RUN_FIX.bat를 사용할 수 있습니다.
약 1.6GB 이상의 여유 공간이 필요합니다. 복사와 검증 중에는 창을 닫지 마세요.
PowerShell 7이나 Python을 따로 설치할 필요는 없습니다.
ERROR가 나오면 창을 캡처해 주세요. 성공 문구가 없으면 완료된 것이 아닙니다.

우선 확인할 곳
- 첫 시신 조사 중 로사의 무전 자막: 체온, 자외선, 목의 멍과 오른손 검지
- 증거 찾기 / 증거 수집 / 채취 도구, 확대와 초점 안내
- 도전 과제 이름과 제1장 설명
- 한글 자막의 잘림, 겹침, 사각형 글자 여부
같은 영문이 계속 보이면 FIX APPLIED 화면과 해당 게임 장면을 함께 보내 주세요.

W키가 간헐적으로 안 먹을 때
공식 Xenia Canary 기본 설정은 소문자 WASD를 왼쪽 스틱, 대문자 WASD를 십자키로 구분합니다.
확인한 입력 코드에서는 Shift 또는 Caps Lock이 켜지면 대문자 쪽으로 처리됩니다.
1. Caps Lock을 끄고 Shift에서 손을 뗀 뒤 W를 떼었다가 다시 눌러 보세요.
2. 게임 화면을 한 번 클릭해 입력 초점을 돌려 주세요.
3. 기본 설정에서 왼쪽 스틱 누르기(달리기)는 F입니다.
사용자 지정 설정이 있으면 해당 설정이 우선입니다.
계속 발생하면 W만 안 되는지 A/S/D도 안 되는지 확인하고 xenia-canary.config.toml을 보내 주세요.
이번 패치는 Xenia 키 설정을 변경하지 않습니다.
참고한 공식 소스:
https://github.com/xenia-canary/xenia-canary/blob/canary_experimental/src/xenia/hid/keyboard/keyboard_binding_table.inc
https://github.com/xenia-canary/xenia-canary/blob/canary_experimental/src/xenia/hid/keyboard/keyboard_input_driver.cc

원본 복원
게임을 종료하고 이 폴더의 RUN_RESTORE.bat를 실행합니다.
0.4 백업: Layer0.Arch00.pre_KoreanUI_v04.bak
0.4 설치 기록: Condemned_KoreanUI_v04.state.json

검증 범위
- 667개 DB 번역 위치의 경계·순서와 미번역 데이터 보존
- 자막 페이지, 표시 시간, 버튼 토큰, 수치 표시 형식 보존
- 실제 압축 글꼴의 한글 포함, 원본 글리프와 버튼 아이콘 보존
- Linux PowerShell에서 실제 원본 앞부분 8MiB를 이용한 0.3 적용 → 0.4 교체 → 원본 복원 테스트
- Windows 및 실제 Xenia에서 0.4 실행은 아직 미확인

translations_added_v04.json: 이번 버전의 추가·수정 번역
gameplay_translations.json: 누적 DB 번역 대조표
이 JSON을 편집하는 것만으로 패치가 바뀌지는 않습니다.
font_preview.png는 실제 패치 글꼴을 복원해 그린 미리보기이며 게임 화면이 아닙니다.
source는 후속 제작용 기록입니다. 일반 설치에는 사용할 필요가 없습니다.
글꼴과 참고 코드 라이선스는 FONT_LICENSE.txt, XENIA_LICENSE.txt에 있습니다.
'''
(OUT/'README_KR.txt').write_text(readme,encoding='utf-8-sig',newline='\r\n')

# Exact capture regressions: these source strings must resolve to the intended translation.
strings=json.loads((ROOT/'all_strings.json').read_text())
changes={r['offset']:r for r in json.loads((OUT/'build_report.json').read_text())['common_string_changes']}
ids=[2144,1714,1974,1033,854,2152,2563,746,873,1705,2694,1659,2386,1393,1206,659,1718,1730,848,561]
regressions=[]
for i in ids:
    s=strings[i];r=changes[s['offset']]
    assert r['source']==s['text'] and any('\uac00'<=c<='\ud7a3' for c in r['korean'])
    regressions.append({'catalog_index':i,'offset':r['offset'],'source':r['source'],'korean':r['korean']})
(OUT/'source/screenshot_regressions_v04.json').write_text(json.dumps(regressions,ensure_ascii=False,indent=2),encoding='utf-8')
for name in ['translate_v04.py','build_v04.py','verify_font_v04.py','test_installer_v04.py','finalize_v04.py']:
    shutil.copy2(ROOT/name,OUT/'source'/name)

logs=[]
for args in [
    ['python3',str(OUT/'source/verify_v04.py'),str(ROOT.parent/'diagnosis/00012_DARK.Strdb00p')],
    ['python3',str(ROOT/'verify_font_v04.py')],
    ['python3',str(ROOT/'test_installer_v04.py')],
]:
    p=subprocess.run(args,text=True,capture_output=True)
    logs.append(p.stdout+p.stderr)
    if p.returncode:raise RuntimeError(logs[-1])
(OUT/'source/verification_v04.txt').write_text('\n'.join(logs),encoding='utf-8')
report=json.loads((OUT/'build_report.json').read_text())
report['installer_validation']='PASS: shipped PowerShell parse; real Linux PowerShell 7.4.6, 8MiB original prefix fixture: v03 apply -> v04 upgrade -> byte-exact original restore. Windows/Xenia v04 not executed.'
report['screenshot_regression_count']=len(regressions)
report['scope_note']='Partial story subtitles; selected opening and early Metro dialogue. Not a complete game translation.'
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')

notes='''# v0.4 제작 기록

증상: 0.3 스크린샷의 도입 대사와 보고서는 한글로 표시되지만 로사 무전, 수사 HUD, 도전 과제와 장 설명은 영어였다.
확인: 해당 문구는 원본 DB에서 찾았으며 0.3 번역 목록에 없었다. 이미 검증된 항목 경계 보존 방식으로 추가했다.

- 351개 추가, 3개 수정, 누적 667개 DB 항목.
- UTF-16BE 원본 항목 경계 유지. U+200B 채움 글리프는 투명·폭 0·전진 폭 0.
- 모든 자막 page/time 토큰 및 시간값, 컨트롤러 토큰, printf 형식 순서 보존.
- 2048×2048 글꼴, 한글 675자와 원본 325개 글리프 및 패딩 1개.
- UI assets는 사용자가 표시를 확인한 이전 파일과 동일.
- 0.1/0.2/0.3 복원 스크립트와 manifest는 해당 배포본 그대로 포함.
- 시험에 쓴 작은 archive fixture와 원본 실행 파일은 배포에 포함하지 않음.

source의 제작 스크립트는 작업 폴더 기준의 기록이다. 재생성에는 이전 0.3 패키지,
원본 DB, 원본 font_pack 리소스, NotoSansCJKkr-Regular.otf 등이 필요하다.
all_strings.json의 번호는 추출 목록의 순번이며 게임 내부 문자열 ID가 아니다.
verify_v04.py는 이 패키지의 source 폴더에서 실행 가능하다:
python verify_v04.py /path/to/original_00012_DARK.Strdb00p

검증 결과는 verification_v04.txt. 실제 0.4의 Windows/Xenia 표시 검증은 사용자의 후속 플레이가 필요하다.
'''
(OUT/'source/NOTES_v04.md').write_text(notes,encoding='utf-8')
archive=ROOT.parent/'Condemned_Korean_UI_v04_RadioFix.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(OUT.rglob('*')):
        if f.is_file() and '__pycache__' not in f.parts:
            z.write(f,f.relative_to(ROOT))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print('\n'.join(line for log in logs for line in log.splitlines() if line.startswith('PASS:')))
print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'screen_regressions':len(regressions)}))
