"""Create v0.7 with an independent upper-right main-menu translation credit.
Usage: python build_v07.py V06_PACKAGE NEW_V07_PACKAGE
"""
from pathlib import Path
import hashlib,json,shutil,struct,sys,zlib
BASE,OUT=[Path(s).resolve() for s in sys.argv[1:3]]
assert BASE!=OUT and not OUT.exists()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
sha=lambda b:hashlib.sha256(b).hexdigest()
u16=lambda b,p:struct.unpack_from('>H',b,p)[0]
u32=lambda b,p:struct.unpack_from('>I',b,p)[0]
CREDIT='한글화: 슬림쉐이디'
ID='KoreanCreditText'
POSITION=(860.,24.,0.)
SIZE=(360.,48.)
POINTS=26.
shutil.copytree(BASE,OUT,ignore=shutil.ignore_patterns('__pycache__','installer_test*'))

def read_xus(b):
    assert b[:6]==b'XUIS\x01\x00' and u32(b,6)==len(b)
    p=12;rows=[]
    for _ in range(u16(b,10)):
        row=[]
        for _ in range(2):
            n=u16(b,p);p+=2;row.append(b[p:p+2*n].decode('utf-16-be'));p+=2*n
        rows.append(row)
    assert p==len(b)
    return rows
def write_xus(rows):
    body=bytearray()
    for row in rows:
        for s in row:
            b=s.encode('utf-16-be');body+=struct.pack('>H',len(b)//2)+b
    return b'XUIS\x01\x00'+struct.pack('>IH',len(body)+12,len(rows))+body

def sections(b):
    assert b[:8]==b'XUIB\0\0\0\5' and u32(b,14)==len(b)
    count=u16(b,18);rows=[]
    for i in range(count):
        tag,off,size=struct.unpack_from('>4sII',b,20+i*12)
        assert off+size<=len(b)
        rows.append((tag,b[off:off+size]))
    assert [x[0] for x in rows]==[b'DBUG',b'STRN',b'VECT',b'QUAT',b'DATA']
    assert 20+count*12+sum(len(x[1]) for x in rows)==len(b)
    return rows
def strings(data):
    out=[];p=0
    while p<len(data):
        n=u16(data,p);p+=2;out.append(data[p:p+n*2].decode('utf-16-be'));p+=n*2
    assert p==len(data)
    return out
def add_credit(raw):
    rows=sections(raw);sec={k:bytearray(v) for k,v in rows}
    oldstrings=strings(sec[b'STRN']);assert len(oldstrings)==42
    assert oldstrings[29]=='XuiText' and oldstrings[38]=='MenuLabel'
    assert ID not in oldstrings
    for s in [ID,CREDIT]:
        enc=s.encode('utf-16-be');sec[b'STRN']+=struct.pack('>H',len(enc)//2)+enc
    idref,textref=len(oldstrings)+1,len(oldstrings)+2
    vecpos=len(sec[b'VECT'])//12
    sec[b'VECT']+=struct.pack('>3f',*POSITION)
    pivot=len(sec[b'VECT'])//12
    sec[b'VECT']+=struct.pack('>3f',0,0,0)
    quat=len(sec[b'QUAT'])//16
    sec[b'QUAT']+=struct.pack('>4f',0,0,0,1)
    data=sec[b'DATA']
    # Reuse the game's existing, unskinned XuiText leaf format from the profile
    # name. Six base properties plus four text properties; it cannot take focus.
    template=bytes(data[-46:])
    assert template[:8]==bytes.fromhex('001e01000a2a012f')
    assert template[30:32]==bytes.fromhex('192b')
    assert struct.unpack_from('>HffIII',template,8)==(41,359.,47.,19,2,20)
    assert struct.unpack_from('>HIfI',template,32)==(42,0xff454e0f,26.,0x410)
    new=bytearray(template)
    struct.pack_into('>HffIII',new,8,idref,*SIZE,vecpos,quat,pivot)
    struct.pack_into('>HIfI',new,32,textref,0xfff5edde,POINTS,0x410)
    assert u16(data,0x38)==11
    struct.pack_into('>H',data,0x38,12)
    data+=new
    # Preserve every original node byte. Only the root's child count changes.
    restored=bytearray(data[:-46]);struct.pack_into('>H',restored,0x38,11)
    assert restored==dict(rows)[b'DATA']
    n=len(rows);header=bytearray(raw[:20]);table=bytearray();body=bytearray()
    for tag,_ in rows:
        content=sec[tag];table+=struct.pack('>4sII',tag,20+n*12+len(body),len(content));body+=content
    result=header+table+body;struct.pack_into('>I',result,14,len(result))
    assert dict(sections(result))=={k:bytes(v) for k,v in sec.items()}
    return bytes(result)

assets=zlib.decompress((BASE/'payload/ui_assets.bin').read_bytes())
base=22+u32(assets,16);p=22;records=[]
for _ in range(u16(assets,20)):
    size,off,n=struct.unpack_from('>IIB',assets,p)
    name=assets[p+9:p+9+n*2].decode('utf-16-be')
    records.append((p,name,base+off,size));p+=9+n*2
assert p==base
table=bytearray(assets[:base]);body=bytearray();edited=[]
for i,(entry,name,start,size) in enumerate(records):
    raw=assets[start:start+size]
    if name=='frontEndMenu.xur':
        raw=add_credit(raw);edited.append(name)
    elif name in ['en-US\\frontEndMenu.xus','ko-kR\\frontEndMenu.xus']:
        pairs=read_xus(raw)
        for pair in pairs:
            if pair[1]=='XuiScene1.MenuLabel.Text':assert pair[0]==CREDIT;pair[0]='주 메뉴'
            if pair[1]=='XuiScene1.MenuLabel.PointSize':pair[0]='-1.000000'
        pairs.extend([[CREDIT,'XuiScene1.'+ID+'.Text'],[str(int(POINTS)),'XuiScene1.'+ID+'.PointSize']])
        raw=write_xus(pairs);assert read_xus(raw)==pairs;edited.append(name)
    nxt=records[i+1][2] if i+1<len(records) else len(assets)
    trailer=assets[start+size:nxt];assert len(trailer)==10+u16(trailer,8)*2
    struct.pack_into('>II',table,entry,len(raw),len(body));body+=raw+trailer
newassets=table+body;struct.pack_into('>I',newassets,8,len(newassets))
assert sorted(edited)==sorted(['frontEndMenu.xur','en-US\\frontEndMenu.xus','ko-kR\\frontEndMenu.xus'])
for entry,name,start,size in records:
    n=u32(newassets,entry);s=base+u32(newassets,entry+4)
    if name not in edited:assert newassets[s:s+n]==assets[start:start+size],name
(OUT/'payload/ui_assets.bin').write_bytes(zlib.compress(newassets,9))
manifest=read(BASE/'manifest.json')
for t in manifest['targets']:
    b=(OUT/t['payload']).read_bytes();t.update(payload_size=len(b),payload_sha256=sha(b),raw_size=len(zlib.decompress(b)))
write(OUT/'manifest.json',manifest)
(OUT/'upgrade_v06').mkdir()
for name in ['Patch.ps1','manifest.json']:shutil.copy2(BASE/name,OUT/'upgrade_v06'/name)
for name in ['Patch.ps1','Upgrade.ps1']:
    s=(BASE/name).read_text(encoding='utf-8-sig')
    s=s.replace('Korean_UI_v06','Korean_UI_v07').replace('KoreanUI_v06','KoreanUI_v07').replace("version='0.6'","version='0.7'").replace('v0.6','v0.7')
    if name=='Upgrade.ps1':s=s.replace("@('v05','v04','v03','v02','v01')","@('v06','v05','v04','v03','v02','v01')")
    (OUT/name).write_text(s,encoding='utf-8-sig',newline='\r\n')
info={'version':'0.7','credit':CREDIT,'node_id':ID,'class':'XuiText','position':POSITION,
      'size':SIZE,'point_size':POINTS,'color_argb':'FFF5EDDE','alignment':0x410,
      'design_size':[1280,720],'edited_resources':edited,
      'change':'Independent upper-right unskinned text; original paper menu title restored.',
      'runtime_tested':False}
write(OUT/'source/menu_credit_v07.json',info)
report=read(BASE/'build_report.json');report.update(version='0.7',runtime_tested=False,
    runtime_evidence_v06='User screenshot: existing paper label clipped the last two Hangul characters. Requested upper-right credit.',
    v07_menu_credit=info,installer_validation='Pending v06 -> v07 fixture verification.')
write(OUT/'build_report.json',report)
shutil.copy2(__file__,OUT/'source/build_v07.py')
print(json.dumps(info,ensure_ascii=False))
