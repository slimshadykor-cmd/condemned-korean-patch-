from pathlib import Path
import importlib.util,json,struct,zlib,hashlib,shutil,re
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'Condemned_Korean_UI_v04'
OUT=ROOT/'Condemned_Korean_UI_v05'
RES=ROOT/'resources'
BUILD=ROOT/'v05_build'
sha=lambda b:hashlib.sha256(b).hexdigest()
if not OUT.exists():shutil.copytree(BASE,OUT)
BUILD.mkdir(exist_ok=True);(BUILD/'prior').mkdir(exist_ok=True)
for name in ['NotoSansCJKkr-Regular.otf','asset_770.bin']:
    shutil.copy2(RES/name,BUILD/'prior'/name)
shutil.copy2(BASE/'source/build_ui_patch.py',BUILD/'build_ui_patch.py')
T=json.loads((BASE/'ui_translations.json').read_text())
new=json.loads((ROOT/'gameplay_translations_v05.json').read_text())
old=json.loads((BASE/'build_report.json').read_text())['common_string_changes']
changes={r['offset']:r.copy() for r in old}
for r in new:changes[r['offset']]=r.copy();T[r['source']]=r['korean']
T['__zero_width_padding__']='\u200b'
(BUILD/'ui_translations.json').write_text(json.dumps(T,ensure_ascii=False),encoding='utf-8')
spec=importlib.util.spec_from_file_location('font_builder',BUILD/'build_ui_patch.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
font,info=m.make_font(set(T))
font=bytearray(font)
# Explicitly make U+200B an invisible, zero-advance padding glyph. This keeps
# database entry boundaries without adding long runs of visible-width spaces
# to centered dialogue or wrapping text. Its atlas pixels must be transparent.
cmap_count=struct.unpack_from('>H',font,0x88)[0]+1
glyph_index=struct.unpack_from('>H',font,0x8a+0x200b*2)[0]
glyph_base=0x8a+cmap_count*2+4
gp=glyph_base+glyph_index*16
assert glyph_index>0
struct.pack_into('>hh',font,gp+10,0,0) # width, advance
info.update(padding_codepoint='U+200B',padding_glyph_index=glyph_index,padding_advance=0)
original=(ROOT.parent/'diagnosis/00012_DARK.Strdb00p').read_bytes()
data=bytearray(original)
for p,r in sorted(changes.items()):
    enc=r['source'].encode('utf-16-be')+b'\0\0'
    assert original[p:p+len(enc)]==enc,(p,r)
    slot=(len(enc)+3)&~3
    assert original[p+len(enc):p+slot]==bytes(slot-len(enc))
    replacement=r['korean'].encode('utf-16-be')
    assert len(replacement)+2<=slot,(r['source'],r['korean'])
    before=re.findall(r'<%[^>]+%>|%\d+![^!]+!|%(?:\.\d+)?[sdf]|%%|<\?>',r['source'])
    after=re.findall(r'<%[^>]+%>|%\d+![^!]+!|%(?:\.\d+)?[sdf]|%%|<\?>',r['korean'])
    assert before==after,(r,before,after)
    # Page timings are preserved verbatim as well as format/control tokens.
    assert re.findall(r'<%time%>\s*[\d.]+',r['source'])==re.findall(r'<%time%>\s*[\d.]+',r['korean'])
    data[p:p+slot]=replacement+b'\x20\x0b'*((slot-len(replacement)-2)//2)+b'\0\0'
    r['slot_bytes']=slot
assert len(data)==len(original)
for name,raw in [('common_strings.bin',data),('korean_font.bin',font)]:
    (OUT/'payload'/name).write_bytes(zlib.compress(raw,9))
manifest=json.loads((BASE/'manifest.json').read_text())
for target in manifest['targets']:
    comp=(OUT/target['payload']).read_bytes()
    target.update(payload_size=len(comp),payload_sha256=sha(comp),raw_size=len(zlib.decompress(comp)))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')

patch=(BASE/'Patch.ps1').read_text(encoding='utf-8-sig').replace('Korean_UI_v04','Korean_UI_v05').replace('KoreanUI_v04','KoreanUI_v05').replace("version='0.4'","version='0.5'")
patch=patch.replace('Scope: menus, objectives, forensic HUD, awards and selected early radio dialogue. Partial translation.',
    'Scope: identified campaign dialogue, documents, menus, objectives and forensic prompts from the supplied text database. Full playthrough validation pending.')
(OUT/'Patch.ps1').write_text(patch,encoding='utf-8-sig',newline='\r\n')
for version,path in [('v04',BASE),('v03',BASE/'upgrade_v03'),('v02',BASE/'upgrade_v02'),('v01',BASE/'upgrade_v01')]:
    folder=OUT/('upgrade_'+version);folder.mkdir(exist_ok=True)
    for name in ['Patch.ps1','manifest.json']:shutil.copy2(path/name,folder/name)
upgrade=(BASE/'Upgrade.ps1').read_text(encoding='utf-8-sig').replace('Korean_UI_v04','Korean_UI_v05').replace('KoreanUI_v04','KoreanUI_v05').replace('v0.4','v0.5')
upgrade=upgrade.replace("@('v03','v02','v01')","@('v04','v03','v02','v01')")
upgrade=upgrade.replace('with radio and forensic translations','with campaign text translations').replace('check Korean radio dialogue and forensic tool prompts','check Korean dialogue, documents and menus')
(OUT/'Upgrade.ps1').write_text(upgrade,encoding='utf-8-sig',newline='\r\n')

(OUT/'translations_added_v05.json').write_text(json.dumps(new,ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'gameplay_translations.json').write_text(json.dumps(list(changes.values()),ensure_ascii=False,indent=2),encoding='utf-8')
(OUT/'ui_translations.json').write_text(json.dumps({k:v for k,v in T.items() if not k.startswith('__')},ensure_ascii=False,indent=2),encoding='utf-8')
report=json.loads((BASE/'build_report.json').read_text())
retained=json.loads((ROOT/'retained_catalog_v05.json').read_text())
report.update(version='0.5',runtime_tested=False,
    story_dialogue_translated='All identified campaign dialogue in supplied English/default DB, including endings and radio greetings; not full-playthrough tested.',
    gameplay_translation_count=len(changes),v05_new_translation_count=sum(r['offset'] not in {x['offset'] for x in old} for r in new),
    v05_revised_count=sum(r['offset'] in {x['offset'] for x in old} for r in new),
    common_string_changes=list(changes.values()),common_original_sha256=sha(original),common_fixed_sha256=sha(data),font=info,
    runtime_evidence_v04='User reports radio dialogue now translated after English first greeting. Captures confirm Korean phone subtitles and forensic descriptions; Investigate and checkpoint warning still English, now covered.',
    installer_validation='Pending v04 -> v05 fixture validation.',
    source_catalog_notes='Original ASCII catalogue contains one invalid suffix at index 630. v05 replaces the complete German-language March 25 report at 0x2ae7c instead.',
    untranslated_paged_dialogue_count=sum('<%page%>' in r['text'] or '<%time%>' in r['text'] for r in retained),
    retained_catalog_count=len(retained),
    scope_note='All identified campaign text from supplied DB. Retains legacy other-game/multiplayer/engine strings and identifiers. Embedded image/video text and executable/system UI are outside this text-resource patch.')
report['validation']=['Every original sequential DB entry start preserved','Bytes outside translated entries unchanged',
 'Format placeholders, page markers, time tokens and values preserved','All translated characters mapped to font glyphs',
 'Original 325 glyph records and texture region preserved','U+200B padding transparent with width/advance zero',
 'XUI assets remain the previously user-confirmed payload','No remaining source-catalog dialogue with page/time markers']
(OUT/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
for name in ['translate_v05.py','build_v05.py']:
    shutil.copy2(ROOT/name,OUT/'source'/name)
shutil.copy2(ROOT/'retained_catalog_v05.json',OUT/'source/retained_catalog_v05.json')
print(json.dumps({'total':len(changes),'new':report['v05_new_translation_count'],'revised':report['v05_revised_count'],'font':info},ensure_ascii=False))
