﻿param([string]$GpdPath='', [ValidateSet('Apply','Restore')][string]$Mode='Apply')
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
$package=Split-Path -Parent $MyInvocation.MyCommand.Path
$temp='';$created=$false
try {
    if (@(Get-Process -Name 'xenia*' -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Xenia를 완전히 종료한 뒤 다시 실행하세요.' }
    Add-Type -Path @((Join-Path $package 'XexPatch.cs'),(Join-Path $package 'GpdText.cs'))
    if ([string]::IsNullOrWhiteSpace($GpdPath)) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
        try {
            $dialog.Description='Xenia 폴더 또는 Xenia의 content 폴더를 선택하세요.'
            if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }
            $root=$dialog.SelectedPath
        } finally { $dialog.Dispose() }
        $files=@(Get-ChildItem -LiteralPath $root -Filter '534507D2.gpd' -File -Recurse -ErrorAction Stop)
        if ($files.Count -eq 0) { throw '534507D2.gpd를 찾지 못했습니다. Xenia content 폴더를 확인하세요. GPD가 없는 구버전은 이 보조 도구가 필요하지 않을 수 있습니다.' }
        if ($files.Count -eq 1) { $GpdPath=$files[0].FullName }
        else {
            for ($i=0; $i -lt $files.Count; $i++) { Write-Host ('{0}: {1}' -f ($i+1),$files[$i].FullName) }
            [int]$selected=0
            if (![int]::TryParse((Read-Host '사용 중인 프로필의 번호를 입력하세요 (취소: 0)'),[ref]$selected) -or $selected -lt 1 -or $selected -gt $files.Count) { exit 0 }
            $GpdPath=$files[$selected-1].FullName
        }
    }
    $GpdPath=[IO.Path]::GetFullPath($GpdPath)
    if ([IO.Path]::GetFileName($GpdPath) -ine '534507D2.gpd') { throw 'Condemned의 534507D2.gpd만 선택할 수 있습니다.' }
    [byte[]]$original=[IO.File]::ReadAllBytes($GpdPath)
    [byte[]]$updated=[CondemnedKorean.GpdText]::Build($original,($Mode -eq 'Restore'))
    $originalHash=[CondemnedKorean.XexPatch]::Hash($original)
    $updatedHash=[CondemnedKorean.XexPatch]::Hash($updated)
    if ($originalHash -eq $updatedHash) { Write-Host '이미 요청한 언어로 되어 있습니다. 변경하지 않았습니다.'; exit 0 }
    $stamp=[DateTime]::UtcNow.ToString('yyyyMMddTHHmmssfff')+'-'+[Guid]::NewGuid().ToString('N')
    $backup=$GpdPath+'.before_text_v10.'+$stamp+'.bak'
    $temp=$GpdPath+'.text_v10.'+$stamp+'.tmp'
    $fs=[IO.File]::Open($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);$created=$true
    try { $fs.Write($updated,0,$updated.Length);$fs.Flush($true) } finally { $fs.Dispose() }
    if ((Get-FileHash -LiteralPath $temp -Algorithm SHA256).Hash.ToLowerInvariant() -ne $updatedHash) { throw '저장 결과가 일치하지 않아 중단했습니다.' }
    if (@(Get-Process -Name 'xenia*' -ErrorAction SilentlyContinue).Count -gt 0 -or (Get-FileHash -LiteralPath $GpdPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $originalHash) { throw '검사 중 프로필이 변경되었거나 Xenia가 실행되었습니다. 중단했습니다.' }
    [IO.File]::Replace($temp,$GpdPath,$backup);$created=$false
    Write-Host '완료: 도전 과제 50개의 제목·설명만 교체했습니다. 획득 상태·시각·점수·다른 프로필 데이터는 보존했습니다.' -ForegroundColor Green
    Write-Host ('백업: '+$backup)
    Write-Host '게임에서 도전 과제 화면을 다시 확인하세요.'
    exit 0
} catch { Write-Host ('오류: '+$_.Exception.Message) -ForegroundColor Red; exit 1 }
finally { if ($created -and (Test-Path -LiteralPath $temp)) { Remove-Item -LiteralPath $temp -ErrorAction SilentlyContinue } }
