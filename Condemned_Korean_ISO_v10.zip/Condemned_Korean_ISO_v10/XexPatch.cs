using System;
using System.IO;
using System.Security.Cryptography;
namespace CondemnedKorean {
 public static class XexPatch {
  public const string OriginalHash="9d2dbd7a709b68f587e59564819315f3955585b91a533ddae241cc832da59fcf";
  public const string PatchedHash="dd5a92f4867bbd60af19be0231f7cfb7d076eb671174b5123adac1c585f4062d";
  public static string Hash(byte[] b) { using(var sha=SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(b)).Replace("-", "").ToLowerInvariant(); }
  public static byte[] Apply(byte[] original, string deltaPath) {
   if(original.Length!=19841024 || Hash(original)!=OriginalHash) throw new InvalidDataException("Unsupported default.xex. Select the original game edition.");
   byte[] delta=File.ReadAllBytes(deltaPath);
   if(delta.Length!=450318 || Hash(delta)!="e3b5f765faff31f962412b28e9ef90382c5432610f126ba638f437cf3988676f") throw new InvalidDataException("Achievement patch payload is damaged.");
   byte[] result=(byte[])original.Clone();
   using(var r=new BinaryReader(new MemoryStream(delta))) {
    if(BitConverter.ToString(r.ReadBytes(8))!="43-4B-58-31-30-00-00-00") throw new InvalidDataException("Invalid XEX delta.");
    uint count=r.ReadUInt32(); long previous=0;
    if(count>1024) throw new InvalidDataException("Invalid delta count.");
    for(uint i=0;i<count;i++) {
     uint at=r.ReadUInt32(), n=r.ReadUInt32();
     if(at<previous || (long)at+n>result.Length || n>r.BaseStream.Length-r.BaseStream.Position) throw new InvalidDataException("Invalid delta range.");
     byte[] d=r.ReadBytes((int)n);for(int j=0;j<d.Length;j++) result[at+j]^=d[j];previous=(long)at+n;
    }
    if(r.BaseStream.Position!=r.BaseStream.Length) throw new InvalidDataException("Trailing delta data.");
   }
   if(Hash(result)!=PatchedHash) throw new InvalidDataException("Patched default.xex verification failed.");
   return result;
  }
 }
}
