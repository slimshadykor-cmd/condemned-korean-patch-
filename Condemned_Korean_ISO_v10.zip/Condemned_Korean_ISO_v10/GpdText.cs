using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
namespace CondemnedKorean {
 public static class GpdText {
  sealed class Entry {public int Table;public int Section;public ulong Id;public byte[] Data;}
  static void Need(bool ok,string m){if(!ok)throw new InvalidDataException(m);}
  static uint U32(byte[] b,int p){return ((uint)b[p]<<24)|((uint)b[p+1]<<16)|((uint)b[p+2]<<8)|b[p+3];}
  static ulong U64(byte[] b,int p){return ((ulong)U32(b,p)<<32)|U32(b,p+4);}
  static void Put(byte[] b,int p,uint n){b[p]=(byte)(n>>24);b[p+1]=(byte)(n>>16);b[p+2]=(byte)(n>>8);b[p+3]=(byte)n;}
  static byte[] Slice(byte[] b,int p,int n){byte[] x=new byte[n];Buffer.BlockCopy(b,p,x,0,n);return x;}
  static bool Same(byte[] a,byte[] b){if(a.Length!=b.Length)return false;for(int i=0;i<a.Length;i++)if(a[i]!=b[i])return false;return true;}
  static List<Entry> Parse(byte[] b,out int dataBase,out int freeAt,out int freeCount) {
   Need(b.Length>=24 && b.Length<128*1024*1024,"Unsupported GPD size.");
   Need(U32(b,0)==0x58444246 && U32(b,4)==0x10000,"Select an unpacked Xenia 534507D2.gpd file.");
   uint ec=U32(b,8),eu=U32(b,12),fc=U32(b,16),fu=U32(b,20);
   long db=24L+18L*ec+8L*fc;
   Need(ec<=100000 && eu<=ec && fc>=1 && fc<=100000 && fu>=1 && fu<=fc && db<=b.Length,"Invalid GPD tables.");
   dataBase=(int)db;freeAt=24+(int)ec*18;freeCount=(int)fc;
   var list=new List<Entry>();var ids=new HashSet<string>();var spans=new List<Tuple<int,int>>();
   for(int i=0;i<eu;i++){
    int p=24+18*i,sec=b[p]*256+b[p+1];ulong id=U64(b,p+2);uint at=U32(b,p+10),sz=U32(b,p+14);
    Need((long)at+sz<=b.Length-db,"GPD entry out of bounds.");Need(ids.Add(sec+":"+id),"Duplicate GPD entry.");
    list.Add(new Entry{Table=p,Section=sec,Id=id,Data=Slice(b,(int)db+(int)at,(int)sz)});
    if(sz>0)spans.Add(Tuple.Create((int)at,(int)(at+sz)));
   }
   spans.Sort((a,z)=>a.Item1.CompareTo(z.Item1));for(int i=1;i<spans.Count;i++)Need(spans[i-1].Item2<=spans[i].Item1,"Overlapping GPD entries.");
   for(int i=0;i<fu;i++){
    uint at=U32(b,freeAt+8*i),sz=U32(b,freeAt+8*i+4);
    if(i==(int)fu-1){Need(at==b.Length-db,"GPD end marker mismatch.");continue;}
    Need((long)at+sz<=b.Length-db,"Invalid GPD free region.");
    foreach(var span in spans)Need(sz==0 || (long)at>=span.Item2 || (long)at+sz<=span.Item1,"GPD free region overlaps data.");
   }
   return list;
  }
  static string ReadString(byte[] b,ref int p){int start=p;while(p+1<b.Length && (b[p]!=0||b[p+1]!=0))p+=2;Need(p+1<b.Length,"Unterminated achievement text.");string value=new UnicodeEncoding(true,false,true).GetString(b,start,p-start);p+=2;return value;}
  // generated, matched by achievement ID plus original/current title and description
  static readonly Dictionary<ulong,string[]> Texts = new Dictionary<ulong,string[]> {
   {27UL, new string[] {"Gold Detective Badge","You found the Gold Detective Badge TV","\ud669\uae08 \ud0d0\uc815 \ubc30\uc9c0","\ud669\uae08 \ud0d0\uc815 \ubc30\uc9c0 TV\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {28UL, new string[] {"Silver Detective Badge","You found the Silver Detective Badge TV","\uc740\ube5b \ud0d0\uc815 \ubc30\uc9c0","\uc740\ube5b \ud0d0\uc815 \ubc30\uc9c0 TV\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {29UL, new string[] {"Bronze Detective Badge","You found the Bronze Detective Badge TV","\uccad\ub3d9 \ud0d0\uc815 \ubc30\uc9c0","\uccad\ub3d9 \ud0d0\uc815 \ubc30\uc9c0 TV\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {30UL, new string[] {"Gold Melee Master Award","You completed Condemned: Criminal Origins with only melee weapons","\uadfc\uc811\uc804 \ub2ec\uc778 \uae08\uc0c1","\uadfc\uc811 \ubb34\uae30\ub9cc\uc73c\ub85c \uac8c\uc784\uc744 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {31UL, new string[] {"Silver Melee Master Award","You completed three levels of Condemned: Criminal Origins with only melee weapons","\uadfc\uc811\uc804 \ub2ec\uc778 \uc740\uc0c1","\uadfc\uc811 \ubb34\uae30\ub9cc\uc73c\ub85c \uc138 \uac1c\uc758 \uc7a5\uc744 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {32UL, new string[] {"Bronze Melee Master Award","You completed single level of Condemned: Criminal Origins with only melee weapons","\uadfc\uc811\uc804 \ub2ec\uc778 \ub3d9\uc0c1","\uadfc\uc811 \ubb34\uae30\ub9cc\uc73c\ub85c \ud55c \uac1c\uc758 \uc7a5\uc744 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {33UL, new string[] {"Chapter 1 Completion Award","You finished Chapter 1: Weisman Office Building","\uc81c1\uc7a5 \uc644\ub8cc\uc0c1","\uc81c1\uc7a5(\uc640\uc774\uc988\uba3c \uc0ac\ubb34\uc2e4 \uac74\ubb3c)\uc744 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {34UL, new string[] {"Chapter 2 Completion Award","You finished Chapter 2: Central Metro Station","\uc81c2\uc7a5 \uc644\ub8cc\uc0c1","\uc81c2\uc7a5(\uc911\uc559 \uc9c0\ud558\ucca0\uc5ed)\uc744 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {35UL, new string[] {"Chapter 3 Completion Award","You finished Chapter 3: Metro Station Platforms","\uc81c3\uc7a5 \uc644\ub8cc\uc0c1","\uc81c3\uc7a5(\uc9c0\ud558\ucca0\uc5ed \uc2b9\uac15\uc7a5)\uc744 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {36UL, new string[] {"Chapter 4 Completion Award","You finished Chapter 4: Grid 4 Subway Tunnels","\uc81c4\uc7a5 \uc644\ub8cc\uc0c1","\uc81c4\uc7a5(4\uad6c\uc5ed \uc9c0\ud558\ucca0 \ud130\ub110)\uc744 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {37UL, new string[] {"Chapter 5 Completion Award","You finished Chapter 5: Bart's Department Store","\uc81c5\uc7a5 \uc644\ub8cc\uc0c1","\uc81c5\uc7a5(\ubc14\ud2b8 \ubc31\ud654\uc810)\uc744 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {38UL, new string[] {"Chapter 6 Completion Award","You finished Chapter 6: Burnback Alley","\uc81c6\uc7a5 \uc644\ub8cc\uc0c1","\uc81c6\uc7a5(\ubc88\ubc31 \uace8\ubaa9)\uc744 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {39UL, new string[] {"Chapter 7 Completion Award","You finished Chapter 7: the Metro City Library","\uc81c7\uc7a5 \uc644\ub8cc\uc0c1","\uc81c7\uc7a5(\uc2dc\ub9bd \ub3c4\uc11c\uad00)\uc744 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {40UL, new string[] {"Chapter 8 Completion Award","You finished Chapter 8: St. Joseph's Secondary School","\uc81c8\uc7a5 \uc644\ub8cc\uc0c1","\uc81c8\uc7a5(\uc138\uc778\ud2b8 \uc870\uc9c0\ud504 \uc911\ub4f1\ud559\uad50)\uc744 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {41UL, new string[] {"Chapter 9 Completion Award","You finished Chapter 9: Apple Seed Orchard","\uc81c9\uc7a5 \uc644\ub8cc\uc0c1","\uc81c9\uc7a5(\uc560\ud50c \uc2dc\ub4dc \uacfc\uc218\uc6d0)\uc744 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {42UL, new string[] {"Gold Game Completion Award","You finished the complete game of Condemned: Criminal Origins","\uac8c\uc784 \uc644\ub8cc \uae08\uc0c1","\ucee8\ub380\ub4dc: \ud06c\ub9ac\ubbf8\ub110 \uc624\ub9ac\uc9c4\uc744 \ub05d\uae4c\uc9c0 \uc644\ub8cc\ud588\uc2b5\ub2c8\ub2e4."}},
   {43UL, new string[] {"Compassion Award","You did not shoot SKX","\uc790\ube44\uc0c1","\uc5f0\uc1c4\uc0b4\uc778\ubc94 X\ub97c \uc3d8\uc9c0 \uc54a\uc558\uc2b5\ub2c8\ub2e4."}},
   {44UL, new string[] {"Revenge Award","You killed SKX","\ubcf5\uc218\uc0c1","\uc5f0\uc1c4\uc0b4\uc778\ubc94 X\ub97c \uc8fd\uc600\uc2b5\ub2c8\ub2e4."}},
   {45UL, new string[] {"Melee Mayhem Award","You found every type of melee weapon and fire-arm","\uadfc\uc811\uc804 \ub300\uac00\uc0c1","\ubaa8\ub4e0 \uc885\ub958\uc758 \uadfc\uc811 \ubb34\uae30\uc640 \ucd1d\uae30\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {46UL, new string[] {"Fire-Arm Freedom Award","You found every available fire-arm","\ucd1d\uae30 \uc219\ub828\uc0c1","\ubaa8\ub4e0 \uc885\ub958\uc758 \ucd1d\uae30\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {47UL, new string[] {"Chief Investigator Award","You found every piece of evidence","\uc218\uc11d \uc218\uc0ac\uad00\uc0c1","\ubaa8\ub4e0 \uc99d\uac70\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {48UL, new string[] {"Chapter 1 Bronze Bird Award","You found a dead bird in the Weisman Office Building","\uc81c1\uc7a5 \uc0c8 \uc218\uc9d1 \ub3d9\uc0c1","\uc640\uc774\uc988\uba3c \uc0ac\ubb34\uc2e4 \uac74\ubb3c\uc5d0\uc11c \uc8fd\uc740 \uc0c8\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {49UL, new string[] {"Chapter 2 Bronze Bird Award","You found a dead bird in the Central Metro Station","\uc81c2\uc7a5 \uc0c8 \uc218\uc9d1 \ub3d9\uc0c1","\uc911\uc559 \uc9c0\ud558\ucca0\uc5ed\uc5d0\uc11c \uc8fd\uc740 \uc0c8\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {50UL, new string[] {"Chapter 3 Bronze Bird Award","You found a dead bird in the Metro Station Platforms","\uc81c3\uc7a5 \uc0c8 \uc218\uc9d1 \ub3d9\uc0c1","\uc9c0\ud558\ucca0\uc5ed \uc2b9\uac15\uc7a5\uc5d0\uc11c \uc8fd\uc740 \uc0c8\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {51UL, new string[] {"Chapter 4 Bronze Bird Award","You found a dead bird in Grid 4 Subway Tunnels","\uc81c4\uc7a5 \uc0c8 \uc218\uc9d1 \ub3d9\uc0c1","4\uad6c\uc5ed \uc9c0\ud558\ucca0 \ud130\ub110\uc5d0\uc11c \uc8fd\uc740 \uc0c8\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {52UL, new string[] {"Chapter 5 Bronze Bird Award","You found a dead bird in Bart's Department Store","\uc81c5\uc7a5 \uc0c8 \uc218\uc9d1 \ub3d9\uc0c1","\ubc14\ud2b8 \ubc31\ud654\uc810\uc5d0\uc11c \uc8fd\uc740 \uc0c8\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {53UL, new string[] {"Chapter 6 Bronze Bird Award","You found a dead bird in Burnback Alley","\uc81c6\uc7a5 \uc0c8 \uc218\uc9d1 \ub3d9\uc0c1","\ubc88\ubc31 \uace8\ubaa9\uc5d0\uc11c \uc8fd\uc740 \uc0c8\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {54UL, new string[] {"Chapter 7 Bronze Bird Award","You found a dead bird in the Metro City Library","\uc81c7\uc7a5 \uc0c8 \uc218\uc9d1 \ub3d9\uc0c1","\uc2dc\ub9bd \ub3c4\uc11c\uad00\uc5d0\uc11c \uc8fd\uc740 \uc0c8\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {55UL, new string[] {"Chapter 8 Bronze Bird Award","You found a dead bird in St. Joseph's Secondary School","\uc81c8\uc7a5 \uc0c8 \uc218\uc9d1 \ub3d9\uc0c1","\uc138\uc778\ud2b8 \uc870\uc9c0\ud504 \uc911\ub4f1\ud559\uad50\uc5d0\uc11c \uc8fd\uc740 \uc0c8\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {56UL, new string[] {"Chapter 9 Bronze Bird Award","You found a dead bird at Apple Seed Orchard","\uc81c9\uc7a5 \uc0c8 \uc218\uc9d1 \ub3d9\uc0c1","\uc560\ud50c \uc2dc\ub4dc \uacfc\uc218\uc6d0\uc5d0\uc11c \uc8fd\uc740 \uc0c8\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {57UL, new string[] {"Chapter 10 Bronze Bird Award","You found a dead bird at the Apple Seed Orchard Processing Center","\uc81c10\uc7a5 \uc0c8 \uc218\uc9d1 \ub3d9\uc0c1","\uc560\ud50c \uc2dc\ub4dc \uacfc\uc218\uc6d0 \uac00\uacf5 \uc2dc\uc124\uc5d0\uc11c \uc8fd\uc740 \uc0c8\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {58UL, new string[] {"Chapter 1 Silver Bird Award","You found all six birds in the Weisman Office Building","\uc81c1\uc7a5 \uc0c8 \uc218\uc9d1 \uc740\uc0c1","\uc640\uc774\uc988\uba3c \uc0ac\ubb34\uc2e4 \uac74\ubb3c\uc5d0\uc11c \uc0c8 \uc5ec\uc12f \ub9c8\ub9ac\ub97c \ubaa8\ub450 \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {59UL, new string[] {"Chapter 2 Silver Bird Award","You found all six birds in the Central Metro Station","\uc81c2\uc7a5 \uc0c8 \uc218\uc9d1 \uc740\uc0c1","\uc911\uc559 \uc9c0\ud558\ucca0\uc5ed\uc5d0\uc11c \uc0c8 \uc5ec\uc12f \ub9c8\ub9ac\ub97c \ubaa8\ub450 \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {60UL, new string[] {"Chapter 3 Silver Bird Award","You found all six birds in the Metro Station Platforms","\uc81c3\uc7a5 \uc0c8 \uc218\uc9d1 \uc740\uc0c1","\uc9c0\ud558\ucca0\uc5ed \uc2b9\uac15\uc7a5\uc5d0\uc11c \uc0c8 \uc5ec\uc12f \ub9c8\ub9ac\ub97c \ubaa8\ub450 \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {61UL, new string[] {"Chapter 4 Silver Bird Award","You found all six birds in Grid 4 Subway Tunnels","\uc81c4\uc7a5 \uc0c8 \uc218\uc9d1 \uc740\uc0c1","4\uad6c\uc5ed \uc9c0\ud558\ucca0 \ud130\ub110\uc5d0\uc11c \uc0c8 \uc5ec\uc12f \ub9c8\ub9ac\ub97c \ubaa8\ub450 \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {62UL, new string[] {"Chapter 5 Silver Bird Award","You found all six birds in Bart's Department Store","\uc81c5\uc7a5 \uc0c8 \uc218\uc9d1 \uc740\uc0c1","\ubc14\ud2b8 \ubc31\ud654\uc810\uc5d0\uc11c \uc0c8 \uc5ec\uc12f \ub9c8\ub9ac\ub97c \ubaa8\ub450 \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {63UL, new string[] {"Chapter 6 Silver Bird Award","You found all six birds in Burnback Alley","\uc81c6\uc7a5 \uc0c8 \uc218\uc9d1 \uc740\uc0c1","\ubc88\ubc31 \uace8\ubaa9\uc5d0\uc11c \uc0c8 \uc5ec\uc12f \ub9c8\ub9ac\ub97c \ubaa8\ub450 \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {64UL, new string[] {"Chapter 7 Silver Bird Award","You found all six birds in the Metro City Library","\uc81c7\uc7a5 \uc0c8 \uc218\uc9d1 \uc740\uc0c1","\uc2dc\ub9bd \ub3c4\uc11c\uad00\uc5d0\uc11c \uc0c8 \uc5ec\uc12f \ub9c8\ub9ac\ub97c \ubaa8\ub450 \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {65UL, new string[] {"Chapter 8 Silver Bird Award","You found all six birds in St. Joseph's Secondary School","\uc81c8\uc7a5 \uc0c8 \uc218\uc9d1 \uc740\uc0c1","\uc138\uc778\ud2b8 \uc870\uc9c0\ud504 \uc911\ub4f1\ud559\uad50\uc5d0\uc11c \uc0c8 \uc5ec\uc12f \ub9c8\ub9ac\ub97c \ubaa8\ub450 \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {66UL, new string[] {"Chapter 9 Silver Bird Award","You found all six birds at Apple Seed Orchard","\uc81c9\uc7a5 \uc0c8 \uc218\uc9d1 \uc740\uc0c1","\uc560\ud50c \uc2dc\ub4dc \uacfc\uc218\uc6d0\uc5d0\uc11c \uc0c8 \uc5ec\uc12f \ub9c8\ub9ac\ub97c \ubaa8\ub450 \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {67UL, new string[] {"Chapter 10 Silver Bird Award","You found all six birds at the Apple Seed Orchard Processing Center","\uc81c10\uc7a5 \uc0c8 \uc218\uc9d1 \uc740\uc0c1","\uc560\ud50c \uc2dc\ub4dc \uacfc\uc218\uc6d0 \uac00\uacf5 \uc2dc\uc124\uc5d0\uc11c \uc0c8 \uc5ec\uc12f \ub9c8\ub9ac\ub97c \ubaa8\ub450 \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {68UL, new string[] {"Golden Bird Award","You found all birds in the game","\ud669\uae08 \uc0c8 \uc218\uc9d1\uc0c1","\uac8c\uc784\uc5d0 \uc788\ub294 \ubaa8\ub4e0 \uc0c8\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {69UL, new string[] {"First Propaganda Report","You unlocked the first propaganda report","\uccab \ubc88\uc9f8 \uc120\uc804 \ubcf4\uace0\uc11c","\uccab \ubc88\uc9f8 \uc120\uc804 \ubcf4\uace0\uc11c\ub97c \ud574\uc81c\ud588\uc2b5\ub2c8\ub2e4."}},
   {70UL, new string[] {"Second Propaganda Report","You unlocked the second propaganda report and the Internal Affairs report","\ub450 \ubc88\uc9f8 \uc120\uc804 \ubcf4\uace0\uc11c","\ub450 \ubc88\uc9f8 \uc120\uc804 \ubcf4\uace0\uc11c\uc640 \ub0b4\uc0ac \ubcf4\uace0\uc11c\ub97c \ud574\uc81c\ud588\uc2b5\ub2c8\ub2e4."}},
   {71UL, new string[] {"Third Propaganda Report","You unlocked the third propaganda report and the DUO report.","\uc138 \ubc88\uc9f8 \uc120\uc804 \ubcf4\uace0\uc11c","\uc138 \ubc88\uc9f8 \uc120\uc804 \ubcf4\uace0\uc11c\uc640 DUO \ubcf4\uace0\uc11c\ub97c \ud574\uc81c\ud588\uc2b5\ub2c8\ub2e4."}},
   {72UL, new string[] {"Fourth Propaganda Report","You unlocked the fourth propaganda report","\ub124 \ubc88\uc9f8 \uc120\uc804 \ubcf4\uace0\uc11c","\ub124 \ubc88\uc9f8 \uc120\uc804 \ubcf4\uace0\uc11c\ub97c \ud574\uc81c\ud588\uc2b5\ub2c8\ub2e4."}},
   {73UL, new string[] {"Static TV Xbox 360","You found the Static TV","\uc7a1\uc74c \ud654\uba74 Xbox 360","\uc7a1\uc74c \ud654\uba74 TV\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {74UL, new string[] {"Ripple TV Xbox 360","You found the Ripple TV","\ubb3c\uacb0 \ud654\uba74 Xbox 360","\ubb3c\uacb0 \ud654\uba74 TV\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {75UL, new string[] {"Test Pattern TV Xbox 360","You found the Test Pattern TV","\uc2dc\ud5d8 \ud654\uba74 Xbox 360","\uc2dc\ud5d8 \ud654\uba74 TV\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
   {76UL, new string[] {"Bird Bath Xbox 360","You found the Bird Bath TV","\uc0c8 \ubaa9\uc695 Xbox 360","\uc0c8 \ubaa9\uc695 \ud654\uba74 TV\ub97c \ucc3e\uc558\uc2b5\ub2c8\ub2e4."}},
  };
  public static byte[] Build(byte[] original,bool restore){
   int db,fp,fc;var entries=Parse(original,out db,out fp,out fc);var before=new List<byte[]>();int matched=0;bool changed=false;
   foreach(var e in entries){
    before.Add(e.Data);
    if(e.Section!=1 || e.Id==0x100000000UL || e.Id==0x200000000UL)continue;
    string[] t;Need(Texts.TryGetValue(e.Id,out t),"Unexpected achievement ID; unsupported game profile.");
    Need(e.Data.Length>=34 && U32(e.Data,0)==28 && U32(e.Data,4)==e.Id,"Unsupported achievement record.");
    int p=28;string title=ReadString(e.Data,ref p),desc=ReadString(e.Data,ref p);int tail=p;ReadString(e.Data,ref p);Need(p==e.Data.Length,"Unexpected achievement extension.");
    Need((title==t[0]||title==t[2]) && (desc==t[1]||desc==t[3]),"Achievement strings do not match this game/language. No profile data was changed.");
    int at=restore?0:2;matched++;
    if(title==t[at] && desc==t[at+1])continue;
    byte[] text=Encoding.BigEndianUnicode.GetBytes(t[at]+"\0"+t[at+1]+"\0");
    byte[] updated=new byte[28+text.Length+e.Data.Length-tail];Buffer.BlockCopy(e.Data,0,updated,0,28);Buffer.BlockCopy(text,0,updated,28,text.Length);Buffer.BlockCopy(e.Data,tail,updated,28+text.Length,e.Data.Length-tail);e.Data=updated;changed=true;
   }
   Need(matched==50,"Expected 50 Condemned achievements. No profile data was changed.");
   if(!changed)return (byte[])original.Clone();
   long total=db;foreach(var e in entries)total+=e.Data.Length;Need(total<128*1024*1024,"GPD too large.");byte[] result=new byte[(int)total];Buffer.BlockCopy(original,0,result,0,db);Array.Clear(result,fp,fc*8);Put(result,20,1);
   int pos=db;foreach(var e in entries){Put(result,e.Table+10,(uint)(pos-db));Put(result,e.Table+14,(uint)e.Data.Length);Buffer.BlockCopy(e.Data,0,result,pos,e.Data.Length);pos+=e.Data.Length;}
   Put(result,fp,(uint)(pos-db));Put(result,fp+4,UInt32.MaxValue-(uint)(pos-db));
   int unused1,unused2,unused3;var verified=Parse(result,out unused1,out unused2,out unused3);Need(verified.Count==entries.Count,"GPD verification failed.");
   for(int i=0;i<entries.Count;i++){
    Need(Same(verified[i].Data,entries[i].Data),"Written GPD data differs.");
    if(entries[i].Section==1 && Texts.ContainsKey(entries[i].Id))Need(Same(Slice(before[i],0,28),Slice(verified[i].Data,0,28)),"Achievement progress changed.");
    else Need(Same(before[i],verified[i].Data),"Unrelated profile data changed.");
   }
   return result;
  }
 }
}
