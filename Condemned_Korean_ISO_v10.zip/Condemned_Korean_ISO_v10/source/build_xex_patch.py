from pathlib import Path
import json,struct,hashlib
from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes
R=Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
b=(R/'default/default.xex').read_bytes(); inv=json.loads((R/'xex_inventory.json').read_text());res=inv['resources'][0]
image=bytearray((R/'default_image.bin').read_bytes());old=bytes(image); raw=bytearray((R/'534507D2.xdbf').read_bytes());xstr=(R/'korean_xstr.bin').read_bytes()
base=res['data_base'];ec=res['entry_capacity'];fc=res['free_capacity'];i=next(i for i,e in enumerate(res['entries']) if e['section']==3 and e['id']==1);entry=res['entries'][i]
newstart=len(raw);raw+=xstr
struct.pack_into('>II',raw,24+18*i+10,newstart-base,len(xstr))
struct.pack_into('>I',raw,20,2)
fp=24+18*ec;raw[fp:fp+8*fc]=bytes(8*fc)
struct.pack_into('>IIII',raw,fp,entry['offset'],entry['size'],len(raw)-base,0)
raw[base+entry['offset']:base+entry['offset']+entry['size']]=bytes(entry['size'])
start=res['image_offset'];end=start+len(raw)
assert not any(image[start+res['size']:end]) and end<=len(image)
image[start:end]=raw
headers=dict(struct.iter_unpack('>II',b[24:24+struct.unpack_from('>I',b,20)[0]*8]));head=bytearray(b[:inv['header_size']]);struct.pack_into('>I',head,headers[0x2ff]+16,len(raw))
security=struct.unpack_from('>I',b,16)[0]
c=Cipher(algorithms.AES(bytes.fromhex('20b185a59d28fdc340583fbb0896bf91')),modes.CBC(bytes(16))).decryptor();key=c.update(b[security+0x150:security+0x160])+c.finalize()
packed=b''.join(image[m['image_offset']:m['image_offset']+m['data_size']] for m in inv['blocks'])
c=Cipher(algorithms.AES(key),modes.CBC(bytes(16))).encryptor();new=bytes(head)+c.update(packed)+c.finalize()
assert len(b)==len(new)
# XOR delta: only differing runs with <=32-byte equal gaps. No complete executable distributed.
ranges=[];p=0
while p<len(b):
 if b[p]==new[p]:p+=1;continue
 a=p;last=p;p+=1
 while p<len(b) and p-last<=32:
  if b[p]!=new[p]:last=p
  p+=1
 ranges.append((a,last+1));p=last+1
out=b'CKX10\0\0\0'+struct.pack('<I',len(ranges))
for a,z in ranges:out+=struct.pack('<II',a,z-a)+bytes(x^y for x,y in zip(b[a:z],new[a:z]))
(R/'xex_achievement.delta').write_bytes(out);(R/'default_patched.xex').write_bytes(new);(R/'534507D2_patched.xdbf').write_bytes(raw)
# Independently decode resulting XEX then reparse every table/reference.
c=Cipher(algorithms.AES(key),modes.CBC(bytes(16))).decryptor();pck=c.update(new[len(head):])+c.finalize();im=bytearray()
for m in inv['blocks']:im+=pck[m['packed_offset']:m['packed_offset']+m['data_size']]+bytes(m['zero_size'])
assert im[:start]==old[:start] and im[end:]==old[end:]
entries=[];strings={}
for j in range(res['entry_used']):
 sec,id,off,size=struct.unpack_from('>HQII',raw,24+j*18);assert off+size<=len(raw)-base
 payload=raw[base+off:base+off+size];entries.append((off,off+size))
 if j!=i:
  e=res['entries'][j];assert payload==(R/'534507D2.xdbf').read_bytes()[base+e['offset']:base+e['offset']+e['size']]
 else:
  assert payload[:4]==b'XSTR' and struct.unpack_from('>I',payload,8)[0]==len(payload)
  count=struct.unpack_from('>H',payload,12)[0];p=14
  for _ in range(count):
   sid,sz=struct.unpack_from('>HH',payload,p);p+=4;strings[sid]=payload[p:p+sz].decode('utf-8');p+=sz
  assert p==len(payload)
entries.sort();assert all(a[1]<=z[0] for a,z in zip(entries,entries[1:]))
translations=json.loads((R/'achievement_translations.json').read_text());assert all(strings[t['id']]==t['korean'] for t in translations)
assert all(a['unachieved_id']==65535 for a in res['achievements'])
meta={'format':1,'original_sha256':sha(b),'patched_sha256':sha(new),'original_size':len(b),'delta_sha256':sha(out),'delta_size':len(out),'delta_path':'payload/xex_achievement.delta','translated_achievements':50,'translated_strings':100,'code_unchanged':True,'ranges':ranges,'resource_size':len(raw),'unchanged_other_string_rows':137}
(R/'xex_patch.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
