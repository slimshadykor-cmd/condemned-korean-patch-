from pathlib import Path
import json,struct,subprocess
R=Path(__file__).resolve().parent.parent;T=R/'v10_tests';p=T/'profile/534507D2.gpd';old=(p.parent/'original.gpd').read_bytes();p.write_bytes(old);inv=json.loads((R/'achievement_work/xex_inventory.json').read_text())['resources'][0];ts={x['id']:x for x in json.loads((R/'achievement_work/achievement_translations.json').read_text())};ids={a['id'] for a in inv['achievements']}
def parse(b):
 ec,eu,fc=struct.unpack_from('>3I',b,8);base=24+18*ec+8*fc;d={}
 for i in range(eu):
  sec,id,off,sz=struct.unpack_from('>HQII',b,24+18*i);d[sec,id]=b[base+off:base+off+sz]
 return d
cmd=[str(R/'achievement_work/pwsh/pwsh'),'-NoLogo','-NoProfile','-File',str(R/'v10_build/Condemned_Korean_UI_v10/AchievementText.ps1'),'-GpdPath',str(p)]
r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr
new=p.read_bytes();a=parse(old);b=parse(new);assert a.keys()==b.keys()
for ach in inv['achievements']:
 id=ach['id'];assert a[1,id][:28]==b[1,id][:28]
 strings=b[1,id][28:].decode('utf-16-be').split('\0');assert strings[:2]==[ts[ach['label_id']]['korean'],ts[ach['description_id']]['korean']]
for k in a:
 if k[0]!=1 or k[1] not in ids:assert a[k]==b[k]
r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0 and p.read_bytes()==new,r.stdout+r.stderr
# Simulate further play, then restore only strings.
ec,eu,fc=struct.unpack_from('>3I',new,8);db=24+18*ec+8*fc;new=bytearray(new);off=struct.unpack_from('>I',new,34)[0]+db
struct.pack_into('>IQ',new,off+16,0x20003,0x1dddeadcafebeef);p.write_bytes(new);progress=parse(new)
r=subprocess.run(cmd+['-Mode','Restore'],capture_output=True,text=True);assert r.returncode==0,r.stdout+r.stderr
restored=parse(p.read_bytes())
for k in a:
 if k[0]==1 and k[1] in ids:assert restored[k][:28]==progress[k][:28] and restored[k][28:]==a[k][28:]
 else:assert restored[k]==a[k]
bad=bytearray(p.read_bytes());bad[db+28:db+30]=b'\x00Z';p.write_bytes(bad);before=len(list(p.parent.glob('*.bak')))
r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode!=0 and p.read_bytes()==bad and len(list(p.parent.glob('*.bak')))==before
(T/'gpd_results.txt').write_text('PASS: 50 Korean achievement title/description pairs\nPASS: IDs, scores, flags, unlock times and unrelated entries unchanged\nPASS: already translated profile is a no-op\nPASS: restoring English text preserves newer earned progress\nPASS: unsupported profile rejected without mutation\nLIMIT: synthetic GPD based on Xenia source; user profile/game UI not tested\n')
print((T/'gpd_results.txt').read_text())
