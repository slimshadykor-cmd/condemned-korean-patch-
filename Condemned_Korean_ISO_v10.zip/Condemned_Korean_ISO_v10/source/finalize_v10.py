from pathlib import Path
import json,hashlib,shutil,zipfile
W=Path(__file__).resolve().parent.parent;B=W/'v10_build';R=W/'achievement_work'
sha=lambda b:hashlib.sha256(b).hexdigest()
qa='''컨뎀드 한글 패치 v0.10 검증 기록 (2026-10-09)

수정 계기
v0.9 사용자 화면에서 도전 과제 목록은 한글이지만 오른쪽 제목·설명이 영어인 누락을 확인했습니다.
일반 문자열 DB·UI 외에 default.xex 내 XDBF 도전 과제 메타데이터가 별도로 사용되었습니다.
v0.9의 검수 범위가 이 저장 위치를 포함하지 못했습니다.

이번 수정
- 도전 과제 50개의 제목 50개와 설명 50개, 총 100개 문자열 번역.
- 제1장 새 수집 동상 설명: 와이즈먼 사무실 건물에서 죽은 새를 찾았습니다.
- 일반 대사·UI·폰트·신발자국 분석 대사는 v0.9 그대로입니다.
- original default.xex를 대상으로 하는 XOR 차분만 배포합니다. 원본 실행파일은 포함하지 않습니다.
- 실행파일 내 도전 과제 문자열 표와 그 위치·크기 정보가 바뀝니다. 게임 코드 바이트는 보존합니다.
- 기존 Xenia Canary 프로필의 영어 설명은 GPD 보조 도구로 제목·설명만 교체할 수 있습니다.

검증한 내용
1. 수정 XEX를 다시 복호화·분해해 XDBF 전체 항목의 범위·겹침을 검사했습니다.
2. 50개 도전 과제의 제목·설명 참조 100개가 번역문과 일치합니다. 기존 폰트에 필요한 글자 누락은 0개입니다.
3. 50개 도전 과제 ID·이미지 ID·점수·조건 플래그, 이미지 및 다른 언어 표가 원본과 일치합니다.
4. XDBF 밖 실행 이미지 바이트 및 기존 데이터가 동일합니다. 새 표는 확인한 기존 0 패딩 범위에 배치했습니다.
5. ISO 설치기를 실제 PowerShell/C# 런타임에서 실행했습니다. 원본 보존, 전체 출력 해시, 수정 범위 밖 바이트 일치, 잘못된 입력·손상된 차분의 거부를 확인했습니다.
6. 폴더판 v0.9 설치 → v0.10 업그레이드 → 원본 복원을 실제 실행했습니다. Layer0.Arch00와 default.xex가 원본 해시로 복원됩니다. 설치 후 변경된 실행파일은 복원 전에 거부합니다.
7. GPD 도구를 잠금·획득 상태가 섞인 50개 항목과 다른 프로필 데이터가 있는 시험 파일에 실행했습니다. 획득 플래그·시각·점수·기타 항목을 보존합니다. 한글 적용 후 새로 획득한 기록도 영어 설명 복원 시 유지합니다. 지원하지 않는 문자열은 수정하지 않고 거부합니다.
8. 최종 ZIP 파일 무결성 및 포함 파일별 SHA-256을 확인했습니다.

시험 환경 및 한계
PowerShell 7.4.6 / Linux. 사용자가 제공한 실제 Layer0 앞 8MiB와 원본 default.xex를 사용했습니다.
전체 크기의 합성 ISO·아카이브와 공식 Xenia 구조에 맞춘 합성 GPD로 설치·복원을 시험했습니다.
원본 전체 ISO 부팅, 사용자의 실제 GPD, Windows 선택 창, 게임 내 한글 표시·줄바꿈·엔딩까지 완주는 아직 확인하지 않았습니다.
데이터 검증은 모든 환경에서의 무튕김 또는 모든 화면의 번역 완료를 의미하지 않습니다.
XEX 서명 검증을 요구하는 실기 환경은 지원·검증 대상이 아닙니다. Xenia용입니다.
작업 중 전원 차단 등으로 두 파일 교체가 중단되면 백업을 보존한 채 오류 내용과 폴더 상태를 제보하세요.
source에 포함된 v0.9 이하 기록은 과거 버전의 기록입니다.
'''
common='''
도전 과제 상세 설명이 계속 영어인 경우
일부 Xenia Canary 버전은 도전 과제 설명을 기존 프로필에도 저장합니다.
1. 게임과 Xenia를 완전히 종료합니다.
2. 이번 ZIP의 RUN_ACHIEVEMENT_TEXT.bat를 실행합니다.
3. Xenia 폴더 또는 Xenia가 사용하는 content 폴더를 선택합니다.
4. 프로필이 여러 개면 사용 중인 프로필의 번호를 선택합니다.
5. 완료 후 게임의 도전 과제 화면을 다시 확인합니다.
대상 파일은 534507D2.gpd입니다. 일반적인 위치는 content/사용자ID/FFFE07D1/00010000/사용자ID/ 아래입니다.
이 도구는 50개의 제목·설명만 바꾸고 획득 상태·시각·점수와 다른 항목은 보존합니다. 적용 전 원본 GPD를 .bak로 남깁니다.
GPD가 없는 구버전은 이 보조 도구가 필요하지 않을 수 있습니다. 찾지 못했다고 프로필이나 세이브를 삭제하지 마세요.
영어 설명으로 되돌리려면 RESTORE_ACHIEVEMENT_TEXT.bat를 사용합니다. 그동안의 새 획득 기록도 보존합니다.
오래된 GPD 백업을 현재 파일 위에 직접 덮어쓰면 이후 기록을 잃을 수 있으므로 설명 복원에는 위 도구를 사용하세요.

검수 범위
도전 과제 메타데이터·폰트 수록 문자, 설치·업그레이드·복원, 시험 GPD 기록 보존을 검사했습니다.
실제 Xenia 게임 화면의 표시 및 전체 플레이 검수는 아직 완료하지 않았습니다. 자세한 기록은 QA_KR.txt를 보세요.
일반 대사와 UI·폰트, 신발자국 분석 대사는 v0.9와 같습니다. 이전 번역과 v0.9 수정 8건이 포함된 통합판입니다.
게임 전체에서 미번역이 0개라고 보장하는 배포본은 아닙니다.
원본 게임 데이터는 포함하지 않습니다. Windows PowerShell용 설치기이며 Xenia에서 사용합니다.
한글화: 슬림쉐이디 / FONT_LICENSE.txt 및 XENIA_LICENSE.txt 참고.
'''
for kind in ['ISO','UI']:
 p=B/f'Condemned_Korean_{kind}_v10'
 if kind=='ISO':
  readme='''컨뎀드 Xbox 360 한글 패치 v0.10 — 도전 과제 상세 설명 수정 통합판

설치 방법
1. ZIP 전체를 압축 해제합니다.
2. RUN_ISO_PATCH.bat를 실행하고 패치하지 않은 원본 Condemned Xbox 360 ISO를 선택합니다.
3. 완료 메시지가 나올 때까지 창을 닫지 마세요. ISO 한 개 크기 이상의 여유 공간이 필요합니다.
4. 생성된 원본이름_Korean_v10.iso를 Xenia에서 실행합니다. 콘솔 언어는 English 또는 Korean입니다.
이전 패치된 ISO에 덧씌우지 마세요. v0.9 사용자도 원본 ISO에 새로 적용합니다.
원본 ISO는 변경하지 않습니다. 원본으로 되돌아가려면 원본 ISO를 실행하세요.
이번 패치는 Layer0의 번역 리소스와 default.xex의 도전 과제 메타데이터를 함께 수정합니다.
'''
 else:
  readme='''컨뎀드 Xbox 360 한글 패치 v0.10 — 도전 과제 상세 설명 수정 통합판

설치 및 업데이트
1. 게임과 Xenia를 완전히 종료합니다.
2. Condemned_Korean_UI_v10 폴더를 default.xex, Layer0.Arch00와 나란히 놓습니다.
3. 새 패치 폴더의 RUN_FIX.bat를 실행합니다. 깨끗한 원본에도 같은 파일을 사용합니다.
4. FIX APPLIED를 확인한 뒤 게임 폴더의 default.xex를 실행합니다. 콘솔 언어는 English 또는 Korean입니다.
기존 v0.1~v0.9의 정상 백업(.bak)과 설치 기록(.state.json)이 있으면 원본 검증·복원 후 업데이트합니다.
이전 백업과 설치 기록을 지우거나 이름을 바꾸지 마세요. 약 1.6GB 이상의 여유 공간이 필요합니다.
ISO 패치판에서 추출한 폴더에는 이 업데이트를 적용하지 말고 깨끗한 원본을 사용하세요.

원본 게임 파일 복원
게임과 Xenia를 종료한 뒤 v0.10 폴더의 RUN_RESTORE.bat를 실행합니다.
이번 버전은 Layer0.Arch00와 default.xex 두 파일을 백업·복원합니다.
백업: Layer0.Arch00.pre_KoreanUI_v10.bak / default.xex.pre_KoreanUI_v10.bak
기록: Condemned_KoreanUI_v10.state.json
게임 파일 복원과 프로필 설명 복원은 별도입니다. 프로필 설명 복원은 아래 보조 도구를 사용하세요.
'''
 (p/'README_KR.txt').write_text(readme+common,encoding='utf-8-sig');(p/'QA_KR.txt').write_text(qa,encoding='utf-8-sig')
 for name in ['build_v10.py','build_xex_patch.py','inspect_xex.py','translate_achievements.py','test_iso_v10.py','test_folder_v10.py','test_gpd_v10.py','prepare_tests.py','finalize_v10.py']:
  shutil.copyfile(R/name,p/'source'/name)
 for src,name in [(W/'v10_tests/iso/test_results.txt','iso_results_v10.txt'),(Path('/tmp/condemned-v10-folder-final/folder_results.txt'),'folder_results_v10.txt'),(W/'v10_tests/gpd_results.txt','gpd_results_v10.txt')]:shutil.copyfile(src,p/'source'/name)
 # All old resource payloads are exact v0.9, and all new runtime files match tested copies.
 for old in (W/'v09_build'/f'Condemned_Korean_{kind}_v09'/'payload').iterdir():assert (p/'payload'/old.name).read_bytes()==old.read_bytes()
 checks=[]
 for f in sorted(p.rglob('*')):
  if f.is_file() and f.name!='SHA256SUMS.txt':checks.append(sha(f.read_bytes())+'  '+f.relative_to(p).as_posix())
 (p/'SHA256SUMS.txt').write_text('\n'.join(checks)+'\n')
 target=B/(p.name+'.zip')
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for f in sorted(p.rglob('*')):
   if f.is_file():z.write(f,f.relative_to(B))
 with zipfile.ZipFile(target) as z:
  assert z.testzip() is None
  assert not any(n.lower().endswith('.xex') or '/default_image.bin' in n for n in z.namelist())
  for row in checks:
   h,name=row.split('  ',1);assert sha(z.read(p.name+'/'+name))==h
 print(target.name,target.stat().st_size,sha(target.read_bytes()))
(B/'Condemned_v10_Changes_QA_20261009.txt').write_text(qa,encoding='utf-8-sig')
checks=[sha(p.read_bytes())+'  '+p.name for p in sorted(B.glob('*.zip'))];(B/'SHA256SUMS_v10.txt').write_text('\n'.join(checks)+'\n')
repo='https://github.com/slimshadykor-cmd/condemned-korean-patch-'
post='''제목: [한글 패치] 컨뎀드: 크리미널 오리진 Xbox 360 / Xenia v0.10 업데이트

한글화: 슬림쉐이디

도전 과제 화면에서 목록은 한글인데 오른쪽 제목과 설명이 영어로 남아 있던 누락을 수정했습니다.
실행파일 안에 별도로 저장된 도전 과제 50개의 제목·설명, 총 100개 문자열을 번역했습니다.
이전 한글화와 v0.9 수정 사항을 모두 포함한 통합 패치입니다.

다운로드 및 자세한 설치 방법:
'''+repo+'''

ISO 사용자는 원본 ISO에 v0.10을 적용해 새 ISO를 만드세요. 이전 패치 ISO에 덧씌우지 않습니다.
폴더판은 기존 백업과 설치 기록을 유지한 상태에서 새 패치의 RUN_FIX.bat를 실행하세요.

기존 Xenia Canary 프로필에 영어 설명이 남아 있다면 Xenia를 종료하고 동봉된 RUN_ACHIEVEMENT_TEXT.bat를 실행해 주세요.
도전 과제 획득 기록·점수는 보존하고 제목·설명만 교체하는 보조 도구입니다.

데이터 구조와 설치·복원은 시험했으며, 실제 게임 화면 표시 및 엔딩까지 전체 플레이 검수는 아직 완료하지 않았습니다.
번역 누락·잘림·오류가 있으면 화면, 챕터, 패치 버전과 Xenia 버전을 함께 알려 주세요.
'''
(B/'Condemned_v10_Board_Post_KR.txt').write_text(post,encoding='utf-8-sig')
readme='''# Condemned: Criminal Origins 한글 패치

**한글화: 슬림쉐이디**  
Xbox 360판 / Xenia용 · **v0.10 도전 과제 상세 설명 수정 통합판** · 2026-10-09

v0.9에서 도전 과제 목록은 한글이지만 오른쪽 제목·설명이 영어로 남는 누락이 확인되었습니다. v0.10은 실행파일의 별도 도전 과제 데이터에 있는 **50개 제목과 50개 설명**을 번역합니다.

## 다운로드

'''
for kind,label in [('ISO','ISO용'),('UI','폴더용')]:
 p=B/f'Condemned_Korean_{kind}_v10.zip';readme+=f'**[{label} v0.10 다운로드]({repo}/raw/refs/heads/main/{p.name})** · {p.stat().st_size:,}바이트\n\n'
readme+='''이전 번역과 v0.9의 수정 8건을 모두 포함한 통합판입니다. 사용하는 게임 형식에 맞는 파일 하나를 받으세요.

## ISO 설치

1. ZIP 전체를 압축 해제하고 **RUN_ISO_PATCH.bat**를 실행합니다.
2. **패치하지 않은 원본 ISO**를 선택합니다.
3. 완료 후 생성된 `원본이름_Korean_v10.iso`를 Xenia에서 실행합니다. 콘솔 언어는 English 또는 Korean으로 설정합니다.

**v0.9 등 이전 패치 ISO에도 덧씌우지 마세요. 원본 ISO에서 새로 만듭니다.** 원본은 보존되며 ISO 한 개 크기 이상의 여유 공간이 필요합니다.

## 폴더 설치·업데이트

1. 게임과 Xenia를 종료합니다.
2. `Condemned_Korean_UI_v10` 폴더를 게임의 `default.xex`, `Layer0.Arch00`와 나란히 놓습니다.
3. 새 패치 폴더의 **RUN_FIX.bat**를 실행합니다.
4. `FIX APPLIED` 확인 후 게임 폴더의 `default.xex`를 실행합니다.

v0.1~v0.9의 원본 백업과 설치 기록이 있으면 검증·복원 후 업데이트합니다. 이전 `.bak`와 `.state.json`을 지우지 마세요. ISO 패치판에서 추출한 폴더는 깨끗한 원본을 사용하세요.

v0.10은 **Layer0.Arch00와 default.xex를 함께 백업**합니다. 원본 복원은 새 패치 폴더의 RUN_RESTORE.bat입니다.

## 도전 과제 설명이 계속 영어인 경우

일부 Xenia Canary는 영어 설명을 기존 프로필에도 저장합니다.

1. Xenia를 완전히 종료합니다.
2. 동봉된 **RUN_ACHIEVEMENT_TEXT.bat**를 실행합니다.
3. Xenia 폴더 또는 실제 `content` 폴더를 선택하고, 여러 프로필이 나오면 사용 중인 프로필을 고릅니다.
4. 완료 후 도전 과제 화면을 다시 확인합니다.

`534507D2.gpd`의 제목·설명 100개만 바꾸며, 획득 상태·시각·점수와 다른 항목은 보존합니다. 적용 전 백업을 남깁니다. 구버전 등에서 GPD를 찾지 못했다고 프로필·세이브를 삭제하지 마세요.

설명만 영어로 복원하려면 **RESTORE_ACHIEVEMENT_TEXT.bat**를 사용합니다. 이후 새로 획득한 기록도 보존하도록 만들었습니다. 오래된 GPD 백업을 현재 파일 위에 직접 덮어쓰지 마세요.

## 검수 범위

수정 XEX를 다시 복호화해 문자열 참조·데이터 범위·폰트 수록 문자를 검사했습니다. 도전 과제 ID·점수·플래그와 게임 코드 바이트를 보존했습니다. 일반 대사·UI·폰트 및 신발자국 분석 대사는 v0.9와 동일합니다.

PowerShell/C# 런타임으로 합성 ISO와 전체 크기의 시험 아카이브에 설치·업그레이드·복원을 실행했습니다. 실제 제공된 앞 8MiB와 원본 실행파일을 사용했으며, GPD는 기록이 섞인 합성 파일로 적용·복원과 진행 기록 보존을 검사했습니다.

**실제 v0.10 게임 화면·사용자 프로필·Windows 선택 창과 엔딩까지 완주는 아직 확인하지 않았습니다.** 데이터 검사는 모든 환경의 무튕김이나 게임 전체의 미번역 0개를 보장하지 않습니다. 자세한 결과는 ZIP 안의 QA_KR.txt에 있습니다.

## 문제 제보

[Issues]('''+repo+'''/issues)에 챕터·장면, 스크린샷, 패치 버전과 Xenia 버전을 함께 남겨 주세요.

## 파일 확인·이전 버전

[SHA256SUMS_v10.txt](SHA256SUMS_v10.txt)에서 다운로드 파일의 해시를 확인할 수 있습니다.

이전 배포본: [v0.9 ISO](Condemned_Korean_ISO_v09.zip) · [v0.9 폴더판](Condemned_Korean_UI_v09.zip) · [v0.8 ISO](Condemned_Korean_ISO_v08.zip) · [v0.7 ISO](Condemned_Korean_ISO_v07.zip)

이전판에는 도전 과제 상세 설명 미번역이 있습니다. 신규 설치는 v0.10을 사용하세요.

원본 게임 ISO·실행파일은 포함하지 않습니다. 사용자 소유의 게임 데이터에 적용하는 패치만 배포합니다. Xenia용이며 Xbox 360 실기 사용은 검증하지 않았습니다.
'''
(B/'README.md').write_text(readme)
release={p.name:{'size':p.stat().st_size,'sha256':sha(p.read_bytes()),'git_blob_sha1':hashlib.sha1(b'blob '+str(p.stat().st_size).encode()+b'\0'+p.read_bytes()).hexdigest()} for p in B.glob('*.zip')}
(B/'release_validation_v10.json').write_text(json.dumps(release,indent=2)+'\n')
