from pathlib import Path
import json,struct,zlib
ROOT=Path(__file__).parent
db=json.loads((ROOT/'xex_inventory.json').read_text())['resources'][0]
oldmap=json.loads(Path('v09_build/Condemned_Korean_UI_v09/ui_translations.json').read_text())
translations={}
for a in db['achievements']:
    source=next(r['text'] for r in db['strings']['1'] if r['id']==a['label_id'])
    if source in oldmap:translations[a['label_id']]=oldmap[source]
translations.update({
150:'황금 탐정 배지 TV를 찾았습니다.',152:'은빛 탐정 배지 TV를 찾았습니다.',154:'청동 탐정 배지 TV를 찾았습니다.',
156:'근접 무기만으로 게임을 완료했습니다.',158:'근접 무기만으로 세 개의 장을 완료했습니다.',160:'근접 무기만으로 한 개의 장을 완료했습니다.',
179:'게임 완료 금상',180:'컨뎀드: 크리미널 오리진을 끝까지 완료했습니다.',
182:'연쇄살인범 X를 쏘지 않았습니다.',184:'연쇄살인범 X를 죽였습니다.',
186:'모든 종류의 근접 무기와 총기를 찾았습니다.',188:'모든 종류의 총기를 찾았습니다.',190:'모든 증거를 찾았습니다.',
232:'게임에 있는 모든 새를 찾았습니다.',234:'첫 번째 선전 보고서를 해제했습니다.',
236:'두 번째 선전 보고서와 내사 보고서를 해제했습니다.',238:'세 번째 선전 보고서와 DUO 보고서를 해제했습니다.',240:'네 번째 선전 보고서를 해제했습니다.',
323:'잡음 화면 Xbox 360',324:'잡음 화면 TV를 찾았습니다.',325:'물결 화면 Xbox 360',326:'물결 화면 TV를 찾았습니다.',
327:'시험 화면 Xbox 360',328:'시험 화면 TV를 찾았습니다.',330:'새 목욕 화면 TV를 찾았습니다.'})
locations=['와이즈먼 사무실 건물','중앙 지하철역','지하철역 승강장','4구역 지하철 터널','바트 백화점','번백 골목','시립 도서관','세인트 조지프 중등학교','애플 시드 과수원','애플 시드 과수원 가공 시설']
for ch,loc in enumerate(locations,1):
    translations[190+2*ch]=f'{loc}에서 죽은 새를 찾았습니다.'
    translations[210+2*ch]=f'{loc}에서 새 여섯 마리를 모두 찾았습니다.'
# Avoid particle mismatch by expressing chapter name separately.
for ch,loc in enumerate(locations[:9],1):translations[160+2*ch]=f'제{ch}장({loc})을 완료했습니다.'
refs={n for a in db['achievements'] for n in [a['label_id'],a['description_id']]}
assert set(translations)==refs and len(refs)==100
rows=[dict(id=r['id'],source=r['text'],korean=translations[r['id']]) for r in db['strings']['1'] if r['id'] in translations]
font=zlib.decompress(Path('v09_build/Condemned_Korean_ISO_v09/payload/korean_font.bin').read_bytes())
maxc=struct.unpack_from('>H',font,0x88)[0];cmap=struct.unpack_from('>'+str(maxc+1)+'H',font,0x8a)
missing=sorted({ch for r in rows for ch in r['korean'] if not ch.isspace() and (ord(ch)>maxc or not cmap[ord(ch)])})
(ROOT/'achievement_translations.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
blob=b'XSTR'+struct.pack('>IIH',1,0,len(db['strings']['1']))
for r in db['strings']['1']:
    value=translations.get(r['id'],r['text']).encode('utf-8');blob+=struct.pack('>HH',r['id'],len(value))+value
blob=blob[:8]+struct.pack('>I',len(blob))+blob[12:]
(ROOT/'korean_xstr.bin').write_bytes(blob)
image=(ROOT/'default_image.bin').read_bytes();end=db['image_offset']+db['size']
print(json.dumps({'translated_rows':len(rows),'string_table_bytes':len(blob),'original_string_table_bytes':next(e['size'] for e in db['entries'] if e['section']==3 and e['id']==1),'missing_glyphs':missing,'trailing_image_bytes':len(image)-end,'trailing_image_nonzero_bytes':sum(x!=0 for x in image[end:])},ensure_ascii=False))
for r in rows:print(r['id'],r['source'],'=>',r['korean'])
