from pathlib import Path
import subprocess,hashlib,json,sys,struct
W=Path(__file__).resolve().parent.parent;T=Path(sys.argv[1]) if len(sys.argv)>1 else W/'v10_tests';T.mkdir(parents=True,exist_ok=True);G=T/'game';P=W/'achievement_work/pwsh/pwsh';old=W/'v09_build/Condemned_Korean_UI_v09';new=W/'v10_build/Condemned_Korean_UI_v10';results=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def run(script,label,args=[],failure=False):
 r=subprocess.run([str(P),'-NoLogo','-NoProfile','-File',str(script),'-GameDirectory',str(G)]+args,capture_output=True,text=True,timeout=300)
 (T/(label+'.log')).write_text(r.stdout+r.stderr)
 assert (r.returncode!=0)==failure,r.stdout+r.stderr
 return r.stdout+r.stderr
G.mkdir(exist_ok=False)
m=json.loads((old/'manifest.json').read_text())
with (G/'Layer0.Arch00').open('wb') as f:
 f.truncate(m['original_size']);f.write((W/'qa_work/Condemned_Diagnostic/Layer0_first_8MB.bin').read_bytes());f.seek(m['original_size']-32);f.write(b'PRESERVE-ARCHIVE-END-12345')
(G/'default.xex').write_bytes((W/'achievement_work/default/default.xex').read_bytes())
layer1=bytearray(49);struct.pack_into('>4sIIII',layer1,0,b'RATL',3,1,0,0);(G/'Layer1.Arch00').write_bytes(layer1)
initial={p.name:sha(p) for p in G.iterdir() if p.is_file()};(T/'original_folder_hashes.json').write_text(json.dumps(initial,indent=2))
run(old/'Patch.ps1','folder_apply_v09',['-Mode','Apply'])
assert (G/'Condemned_KoreanUI_v09.state.json').is_file();assert sha(G/'default.xex')==initial['default.xex']
run(new/'Upgrade.ps1','folder_upgrade_v10')
assert not (G/'Condemned_KoreanUI_v09.state.json').exists();assert (G/'Condemned_KoreanUI_v10.state.json').is_file()
assert sha(G/'default.xex')=='dd5a92f4867bbd60af19be0231f7cfb7d076eb671174b5123adac1c585f4062d'
assert sha(G/'default.xex.pre_KoreanUI_v10.bak')==initial['default.xex'];assert sha(G/'Layer0.Arch00.pre_KoreanUI_v10.bak')==initial['Layer0.Arch00']
results.append('PASS: v0.9 installed then v0.10 Upgrade.ps1 restores old backup and applies integrated patch')
results.append('PASS: patched executable and both original backups match independently computed hashes')
# Refuse to erase an executable edited after installation.
f=G/'default.xex'
with f.open('r+b') as h:h.seek(100);byte=h.read(1);h.seek(100);h.write(bytes([byte[0]^1]))
before={p.name:sha(p) for p in G.iterdir() if p.is_file()}
run(new/'Patch.ps1','restore_changed_xex',['-Mode','Restore'],failure=True)
assert before=={p.name:sha(p) for p in G.iterdir() if p.is_file()}
with f.open('r+b') as h:h.seek(100);h.write(byte)
results.append('PASS: restore refuses modified executable before changing archive or either backup')
run(new/'Patch.ps1','folder_restore_v10',['-Mode','Restore'])
assert {p.name:sha(p) for p in G.iterdir() if p.is_file()}==initial
results.append('PASS: restore returns both Layer0.Arch00 and default.xex byte-exact to originals')
results.append('LIMIT: actual supplied prefix/default.xex in a full-size synthetic archive; PowerShell 7.4.6 on Linux, no Windows GUI or game runtime test')
(T/'folder_results.txt').write_text('\n'.join(results)+'\n');print('\n'.join(results))
