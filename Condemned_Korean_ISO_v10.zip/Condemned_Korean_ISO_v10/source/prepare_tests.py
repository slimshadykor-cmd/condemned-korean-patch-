from pathlib import Path
import json,struct
R=Path(__file__).parent;W=R.parent; T=W/'v10_tests';T.mkdir(exist_ok=True)
s=(W/'v09_build/Condemned_Korean_ISO_v09/source/test_iso_patcher.py').read_text()
s=s.replace("[(0,fix['l0']),(fix['l0']+len(prefix),fix['length'])]","[(0,fix['xex']),(fix['xex']+len(xex),fix['l0']),(fix['l0']+len(prefix),fix['length'])]")
s=s.replace("assert hash_file(fix['path'])==original_hash","with out.open('rb') as f:\n        f.seek(fix['xex']);assert sha(f.read(len(xex)))==m['achievement_patch']['patched_sha256']\n    assert hash_file(fix['path'])==original_hash",1)
s=s.replace("expect='already contains Korean ISO'","expect='default.xex differs'").replace('all non-prefix bytes unchanged','all bytes outside Layer0 prefix and XEX unchanged').replace('all other bytes/source unchanged','other bytes/source unchanged')
s=s.replace("payload=package/'payload/common_strings.bin'","payload=package/'payload/xex_achievement.delta'").replace("expect='payload hash mismatch'","expect='Achievement patch payload is damaged'")
(R/'test_iso_v10.py').write_text(s)
# Full-size extracted folder fixture with authentic initial resources, synthetic rest.
m=json.loads((W/'v09_build/Condemned_Korean_UI_v09/manifest.json').read_text());folder=T/'game';folder.mkdir(exist_ok=True)
with (folder/'Layer0.Arch00').open('wb') as f:
 f.truncate(m['original_size']);f.write((W/'qa_work/Condemned_Diagnostic/Layer0_first_8MB.bin').read_bytes());f.seek(m['original_size']-32);f.write(b'PRESERVE-ARCHIVE-END-12345')
(folder/'default.xex').write_bytes((R/'default/default.xex').read_bytes());layer1=bytearray(49);struct.pack_into('>4sIIII',layer1,0,b'RATL',3,1,0,0);(folder/'Layer1.Arch00').write_bytes(layer1)
# Independently construct realistic GPD with unlocked/locked achievements and unrelated records.
inv=json.loads((R/'xex_inventory.json').read_text())['resources'][0];t={x['id']:x for x in json.loads((R/'achievement_translations.json').read_text())};records=[]
for a in inv['achievements']:
 header=struct.pack('>5IQ',28,a['id'],a['image_id'],a['score'],0x20003 if a['id']%2 else 3,0x01dd123456780000+a['id'] if a['id']%2 else 0)
 text=t[a['label_id']]['source']+'\0'+t[a['description_id']]['source']+'\0'+'\0'
 records.append((1,a['id'],header+text.encode('utf-16-be')))
records.extend([(1,0x100000000,b'preserve-sync-list'),(1,0x200000000,b'preserve-sync-data'),(2,12,b'preserve-icon'),(3,0x10040012,b'preserve-settings'),(5,0x8000,'Condemned\0'.encode('utf-16-be'))])
ec=128;fc=128;db=24+18*ec+8*fc;b=bytearray(db);struct.pack_into('>4s5I',b,0,b'XDBF',0x10000,ec,len(records),fc,1)
for i,(sec,id,data) in enumerate(records):struct.pack_into('>HQII',b,24+i*18,sec,id,len(b)-db,len(data));b+=data
struct.pack_into('>II',b,24+18*ec,len(b)-db,0xffffffff-(len(b)-db))
g=T/'profile';g.mkdir(exist_ok=True);(g/'534507D2.gpd').write_bytes(b);(g/'original.gpd').write_bytes(b)
print('Fixtures ready')
