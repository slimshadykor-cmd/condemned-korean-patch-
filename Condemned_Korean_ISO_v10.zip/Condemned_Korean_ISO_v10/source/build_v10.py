from pathlib import Path
import json,shutil
R=Path(__file__).resolve().parent; W=R.parent; B=W/'v10_build';B.mkdir(exist_ok=True)
def replace(s,a,b):
 assert a in s,a[:100]
 return s.replace(a,b)
def read(p):return p.read_text(encoding='utf-8-sig')
def write(p,s):p.write_text(s,encoding='utf-8-sig' if p.suffix=='.ps1' else 'utf-8')
for kind in ['ISO','UI']:
 src=W/'v09_build'/f'Condemned_Korean_{kind}_v09';dst=B/f'Condemned_Korean_{kind}_v10'
 shutil.copytree(src,dst,dirs_exist_ok=True)
 if kind=='UI':
  old=dst/'upgrade_v09';old.mkdir(exist_ok=True)
  for name in ['Patch.ps1','manifest.json']:shutil.copyfile(src/name,old/name)
 for name in ['Patch.ps1','Upgrade.ps1','PatchISO.ps1','IsoPatcher.cs','RUN_FIX.bat','RUN_RESTORE.bat','RUN_ISO_PATCH.bat']:
  p=dst/name
  if p.exists():write(p,read(p).replace('v09','v10').replace('v0.9','v0.10').replace("'0.9'","'0.10'").replace("'0.9-ISO'","'0.10-ISO'"))
 shutil.copyfile(R/'XexPatch.cs',dst/'XexPatch.cs');shutil.copyfile(R/'xex_achievement.delta',dst/'payload/xex_achievement.delta');shutil.copyfile(R/'xex_patch.json',dst/'xex_patch.json');shutil.copyfile(R/'achievement_translations.json',dst/'achievement_translations.json')
 for f in ['build_xex_patch.py','translate_achievements.py','build_v10.py']:shutil.copyfile(R/f,dst/'source'/f)
 if kind=='ISO':
  p=dst/'iso_manifest.json';m=json.loads(read(p));m['version']='0.10-ISO';m['achievement_patch']=json.loads((R/'xex_patch.json').read_text());write(p,json.dumps(m,ensure_ascii=False,indent=2)+'\n')
  p=dst/'IsoPatcher.cs';s=read(p)
  s=replace(s,'Require(layer0==null, "Multiple Condemned game partitions were found.");','foreach (DiscEntry f in files) if (!Object.ReferenceEquals(f,exe))\n                                Require(!Overlap(exe.Offset,exe.Length,f.Offset,f.Length), "default.xex overlaps another ISO entry.");\n                            Require(layer0==null, "Multiple Condemned game partitions were found.");')
  s=replace(s,'byte[] patched=BuildPrefix(original,package,plan);','byte[] patched=BuildPrefix(original,package,plan);\n                    byte[] patchedXex=CondemnedKorean.XexPatch.Apply(Read(source,xex.Offset,(int)xex.Length),Path.Combine(package,"payload/xex_achievement.delta"));')
  s=replace(s,'patchedSha.TransformBlock(buffer,0,n,buffer,0);','low=Math.Max(pos,xex.Offset);\n                            high=Math.Min(pos+n,xex.Offset+patchedXex.Length);\n                            if (low<high) Buffer.BlockCopy(patchedXex,(int)(low-xex.Offset),buffer,(int)(low-pos),(int)(high-low));\n                            patchedSha.TransformBlock(buffer,0,n,buffer,0);')
  s=replace(s,'Require(Equal(Hash(Read(output,layer0.Offset,plan.PrefixSize)),plan.PatchedHash),"Output prefix verification failed.");','Require(Equal(Hash(Read(output,layer0.Offset,plan.PrefixSize)),plan.PatchedHash),"Output prefix verification failed.");\n                        Require(Equal(Hash(Read(output,xex.Offset,(int)xex.Length)),CondemnedKorean.XexPatch.PatchedHash),"Output executable metadata verification failed.");')
  write(p,s)
  p=dst/'PatchISO.ps1';s=read(p)
  s=replace(s,"Add-Type -TypeDefinition ([IO.File]::ReadAllText((Join-Path $package 'IsoPatcher.cs'),[Text.Encoding]::UTF8)) -Language CSharp","Add-Type -Path @((Join-Path $package 'XexPatch.cs'),(Join-Path $package 'IsoPatcher.cs'))")
  s=replace(s,"Write-Host '원본 ISO와 세이브 파일은 변경하지 않았습니다.'","Write-Host '원본 ISO와 세이브 파일은 변경하지 않았습니다.'\n        Write-Host '도전 과제 설명이 여전히 영어라면 Xenia를 종료한 뒤 RUN_ACHIEVEMENT_TEXT.bat를 실행하세요.'")
  write(p,s)
 else:
  p=dst/'manifest.json';m=json.loads(read(p));m['version']='0.10';m['achievement_patch']=json.loads((R/'xex_patch.json').read_text());write(p,json.dumps(m,ensure_ascii=False,indent=2)+'\n')
  p=dst/'Upgrade.ps1';s=read(p);s=replace(s,"@('v08','v07'","@('v09','v08','v07'")
  s=replace(s,"if (!(Test-Path -LiteralPath $psExe -PathType Leaf)) { throw 'Run this package using Windows PowerShell.' }","if (!(Test-Path -LiteralPath $psExe -PathType Leaf)) { $psExe=Join-Path $PSHOME 'pwsh' }")
  s=s.replace("('upgrade_'+$version+'\\Patch.ps1')","('upgrade_'+$version+'/Patch.ps1')");write(p,s)
  p=dst/'Patch.ps1';s=read(p)
  s=replace(s,"$statePath = ''","$statePath = ''\n$xexTemp=''; $xexCommitted=$false; $xexTempCreated=$false\nAdd-Type -Path (Join-Path $package 'XexPatch.cs')")
  s=replace(s,"Write-Host ('Game folder: '+$GameDirectory)","$xex = Join-Path $GameDirectory 'default.xex'\n    $xexBackup = Join-Path $GameDirectory 'default.xex.pre_KoreanUI_v10.bak'\n    $xexTemp = Join-Path $GameDirectory 'default.xex.KoreanUI_v10.tmp'\n    Write-Host ('Game folder: '+$GameDirectory)")
  s=replace(s,"$removed = Join-Path $GameDirectory 'Layer0.Arch00.KoreanUI_v10.removed'", "if (!(Test-Path -LiteralPath $xexBackup -PathType Leaf) -or (Get-FileHash -LiteralPath $xexBackup -Algorithm SHA256).Hash.ToLowerInvariant() -ne [CondemnedKorean.XexPatch]::OriginalHash -or (Get-FileHash -LiteralPath $xex -Algorithm SHA256).Hash.ToLowerInvariant() -ne [CondemnedKorean.XexPatch]::PatchedHash) { throw 'Executable or its backup changed. Restore stopped without changes.' }\n        $xexRemoved=Join-Path $GameDirectory 'default.xex.KoreanUI_v10.removed'\n        if (Test-Path -LiteralPath $xexRemoved) { throw 'Executable restore temporary file exists.' }\n        $removed = Join-Path $GameDirectory 'Layer0.Arch00.KoreanUI_v10.removed'")
  s=replace(s,'[IO.File]::Replace($backup,$source,$removed)\n        Remove-Item -LiteralPath $removed','[IO.File]::Replace($backup,$source,$removed)\n        try { [IO.File]::Replace($xexBackup,$xex,$xexRemoved) }\n        catch { [IO.File]::Replace($removed,$source,$backup); throw }\n        Remove-Item -LiteralPath $xexRemoved\n        Remove-Item -LiteralPath $removed')
  s=s.replace('RESTORED: original Layer0.Arch00 is back in place.','RESTORED: original Layer0.Arch00 and default.xex are back in place.')
  s=replace(s,"if (Test-Path -LiteralPath $temp) {", "if ((Test-Path -LiteralPath $xexBackup) -or (Test-Path -LiteralPath $xexTemp)) { throw 'Executable backup or temporary file already exists.' }\n    if (Test-Path -LiteralPath $temp) {")
  s=replace(s,"Write-Host 'Original verified. Creating and validating the patched archive...'", "$xexBytes=[CondemnedKorean.XexPatch]::Apply([IO.File]::ReadAllBytes($xex),(Join-Path $package 'payload/xex_achievement.delta'))\n    $xf=[IO.File]::Open($xexTemp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)\n    $xexTempCreated=$true\n    try { $xf.Write($xexBytes,0,$xexBytes.Length); $xf.Flush($true) } finally { $xf.Dispose() }\n    if ((Get-FileHash -LiteralPath $xexTemp -Algorithm SHA256).Hash.ToLowerInvariant() -ne [CondemnedKorean.XexPatch]::PatchedHash) { throw 'Executable staging verification failed.' }\n    Write-Host 'Original verified. Creating and validating the patched archive...'")
  s=replace(s,'appended=$appended','appended=$appended; original_xex_sha256=[CondemnedKorean.XexPatch]::OriginalHash; patched_xex_sha256=[CondemnedKorean.XexPatch]::PatchedHash')
  s=replace(s,"try { [IO.File]::WriteAllText($statePath,($state | ConvertTo-Json -Depth 6),[Text.Encoding]::UTF8) }", "try {\n        if ((Get-FileHash -LiteralPath $xex -Algorithm SHA256).Hash.ToLowerInvariant() -ne [CondemnedKorean.XexPatch]::OriginalHash) { throw 'Executable changed while preparing patch.' }\n        [IO.File]::Replace($xexTemp,$xex,$xexBackup); $xexCommitted=$true; $xexTempCreated=$false\n        [IO.File]::WriteAllText($statePath,($state | ConvertTo-Json -Depth 6),[Text.Encoding]::UTF8)\n    }")
  s=replace(s,'# Restore the original if recording the successful installation fails.','# Restore both originals if the second replacement or installation record fails.\n        if ($xexCommitted) { [IO.File]::Replace($xexBackup,$xex,$xexTemp); $xexCommitted=$false; $xexTempCreated=$true }\n        if (Test-Path -LiteralPath $statePath -PathType Leaf) { Remove-Item -LiteralPath $statePath }')
  s=s.replace('APPLIED: Korean UI text and font resources installed.','APPLIED: Korean UI, fonts and 50 achievement titles/descriptions installed.')
  s=replace(s,"Write-Host 'Use RUN_RESTORE.bat to restore the original.'","Write-Host 'If achievement text is still English, close Xenia and run RUN_ACHIEVEMENT_TEXT.bat.'\n    Write-Host 'Use RUN_RESTORE.bat to restore the original game files.'")
  s=replace(s,'if ($null -ne $inputStream) { $inputStream.Dispose() }',"if ($xexTempCreated -and !$xexCommitted -and (Test-Path -LiteralPath $xexTemp)) { Remove-Item -LiteralPath $xexTemp -ErrorAction SilentlyContinue }\n    if ($null -ne $inputStream) { $inputStream.Dispose() }")
  write(p,s)
print('v0.10 packages assembled')
