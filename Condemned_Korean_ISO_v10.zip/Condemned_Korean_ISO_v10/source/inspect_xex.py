from pathlib import Path
import hashlib,json,re,struct
from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes

ROOT=Path(__file__).parent
b=(ROOT/'default/default.xex').read_bytes()
u32=lambda b,p:struct.unpack_from('>I',b,p)[0]
headers=dict(struct.iter_unpack('>II',b[24:24+u32(b,20)*8]))
security=u32(b,16);base=u32(b,security+0x110);start=u32(b,8)
info=headers[0x3ff];n=u32(b,info)
encryption,compression=struct.unpack_from('>HH',b,info+4)
assert (encryption,compression)==(1,1)
blocks=list(struct.iter_unpack('>II',b[info+8:info+n]))
public_key=bytes.fromhex('20b185a59d28fdc340583fbb0896bf91')
dec=Cipher(algorithms.AES(public_key),modes.CBC(bytes(16))).decryptor()
key=dec.update(b[security+0x150:security+0x160])+dec.finalize()
dec=Cipher(algorithms.AES(key),modes.CBC(bytes(16))).decryptor()
packed=dec.update(b[start:])+dec.finalize()
assert sum(d for d,z in blocks)==len(packed)
image=bytearray();p=0;mapping=[]
for d,z in blocks:
    mapping.append({'image_offset':len(image),'packed_offset':p,'data_size':d,'zero_size':z})
    image+=packed[p:p+d]+bytes(z);p+=d
assert image[:2]==b'MZ'
(ROOT/'default_image.bin').write_bytes(image)
resources=[];p=headers[0x2ff];end=p+u32(b,p);p+=4
while p<end:
    name,addr,size=struct.unpack_from('>8sII',b,p);p+=16
    off=addr-base;raw=bytes(image[off:off+size])
    assert len(raw)==size
    rec={'name':name.decode(),'address':addr,'image_offset':off,'size':size,'magic':raw[:4].decode()}
    resources.append(rec);(ROOT/(name.decode()+'.xdbf')).write_bytes(raw)
    if raw[:4]!=b'XDBF':continue
    version,ec,eu,fc,fu=struct.unpack_from('>5I',raw,4)
    data_base=24+18*ec+8*fc;strings={};entries=[]
    for i in range(eu):
        sect,ident,rel,sz=struct.unpack_from('>HQII',raw,24+i*18)
        assert data_base+rel+sz<=len(raw)
        blob=raw[data_base+rel:data_base+rel+sz]
        entries.append({'section':sect,'id':ident,'offset':rel,'size':sz})
        if sect==3:
            assert blob[:4]==b'XSTR';cnt=struct.unpack_from('>H',blob,12)[0];q=14;rows=[]
            for _ in range(cnt):
                sid,n=struct.unpack_from('>HH',blob,q);q+=4
                text=blob[q:q+n].decode('utf-8');q+=n;rows.append({'id':sid,'text':text})
            assert q==len(blob)
            strings[str(ident)]=rows
        elif sect==1 and ident==0x58414348:
            assert blob[:4]==b'XACH';cnt=struct.unpack_from('>H',blob,12)[0]
            achievements=[]
            for k in range(cnt):
                id,label,description,unachieved,imageid,score=struct.unpack_from('>4HIH',blob,14+k*36)
                achievements.append({'id':id,'label_id':label,'description_id':description,'unachieved_id':unachieved,'image_id':imageid,'score':score})
            assert 14+36*cnt==len(blob)
    rec.update(version=version,entry_capacity=ec,entry_used=eu,free_capacity=fc,free_used=fu,data_base=data_base,entries=entries,strings=strings,achievements=achievements)
(ROOT/'xex_inventory.json').write_text(json.dumps({'xex_sha256':hashlib.sha256(b).hexdigest(),'image_base':base,'header_size':start,'blocks':mapping,'resources':resources},ensure_ascii=False,indent=2))
for r in resources:
    print({k:v for k,v in r.items() if k not in ['entries','strings','achievements']})
    print('languages',list(r['strings']),'achievements',len(r['achievements']))
    for row in r['strings'].get('1',[]):print(row['id'],row['text'])
