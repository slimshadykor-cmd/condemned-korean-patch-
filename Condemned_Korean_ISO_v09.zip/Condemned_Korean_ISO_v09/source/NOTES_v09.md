v0.9: eight reviewed string fixes. Other strings, font and UI remain identical to v0.8.
Reproduce with build_v09.py using v08 UI, v08 ISO, review_input_v09.json, original 8MiB prefix and a new output directory.
Old verification files are historical. Current results: verification_v09.txt.
The builder reproduces patch data and installer version changes. Current QA reports are created after running verification; finalize_v09.py rebuilds checksums and release ZIPs from the reviewed directories.
