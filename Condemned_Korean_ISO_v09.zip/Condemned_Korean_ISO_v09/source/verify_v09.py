from pathlib import Path
import collections, hashlib, json, re, struct, zlib

import sys
# python verify_v09.py V08_UI V09_UI V09_ISO ORIGINAL_PREFIX
BASE,UI,ISO,PREFIX=map(Path,sys.argv[1:5])
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
u32=lambda b,p:struct.unpack_from('>I',b,p)[0]
u16=lambda b,p:struct.unpack_from('>H',b,p)[0]
prefix=PREFIX.read_bytes()
entry=48+u32(prefix,8)+12*32
_,off,n,raw_n,_=struct.unpack_from('>IQQQI',prefix,entry)
old=zlib.decompress(prefix[off:off+n])
assert len(old)==raw_n
new=zlib.decompress((ISO/'payload/common_strings.bin').read_bytes())
translations=read(UI/'gameplay_translations.json')
changes={r['offset']:r for r in translations}
assert len(changes)==len(translations)==2093
assert old[:8]==b'BDKS\0\0\0\3'
count=u32(old,8);table=24+u32(old,20)
assert table+count*8==len(old)==len(new)
names=[];p=24
for _ in range(count):
    end=old.index(0,p);names.append(old[p:end].decode('latin1'));p=(end+4)&~3
assert p==0x17548
pairs=[struct.unpack_from('>II',old,table+i*8) for i in range(count)]
assert old[:p]==new[:p] and old[table:]==new[table:]
value_count=max(x[0] for x in pairs)+1
def get_values(b):
    p=0x17548;result=[]
    for _ in range(value_count):
        end=p
        while end+2<=len(b) and b[end:end+2]!=b'\0\0':end+=2
        result.append((p,b[p:end].decode('utf-16-be')));p=(end+5)&~3
    return result,p
A,endA=get_values(old);B,endB=get_values(new)
assert endA==endB and old[endA:]==new[endB:]
assert [x[0] for x in A]==[x[0] for x in B]
allowed=bytearray(len(old));exceptions={x['offset'] for x in read(UI/'source/literal_input_tag_allowlist_v06.json')}
tokens=r'<%[^>]+%>|%\d+![^!]+!|%(?:\.\d+)?[sdf]|%%|<\?>'
input_token=r'<%(?:action|flashlight|tools|fire|ammocheck|togglemelee|sprint|taser|kick|block|pause|aim|move)%>'
paged=0
for (off,source),(_,target) in zip(A,B):
    if off not in changes:
        assert source==target
        assert not ('<%page%>' in source or '<%time%>' in source)
        continue
    row=changes[off]
    assert source==row['source']
    assert target.rstrip('\u200b')==row['korean'] and row['korean'].strip()
    src_tokens=re.findall(tokens,source)
    if off in exceptions:src_tokens=[t for t in src_tokens if not re.fullmatch(input_token,t)]
    assert src_tokens==re.findall(tokens,row['korean'])
    assert re.findall(r'<%time%>\s*[\d.]+',source)==re.findall(r'<%time%>\s*[\d.]+',row['korean'])
    assert not re.search(input_token,row['korean'])
    allowed[off:off+row['slot_bytes']]=b'\1'*row['slot_bytes']
    paged+=('<%page%>' in source or '<%time%>' in source)
assert all(a==b or allowed[i] for i,(a,b) in enumerate(zip(old,new)))
assert all(off in {a[0] for a in A} for off in changes)
keyed=[]
for name,(idx,voice) in zip(names,pairs):
    off,source=A[idx];target=B[idx][1].rstrip('\u200b')
    keyed.append(dict(key=name,index=idx,offset=off,source=source,korean=target,translated=off in changes,voice_index=voice))
hints=sorted([r for r in keyed if r['key'].startswith('IDS_LOADSCREEN_HINT_')],key=lambda r:int(r['key'].rsplit('_',1)[1]))
assert len(hints)==43 and all(r['translated'] for r in hints)
font=zlib.decompress((ISO/'payload/korean_font.bin').read_bytes())
maxc=u16(font,0x88);cmap=struct.unpack_from('>'+str(maxc+1)+'H',font,0x8a)
for row in translations:
    for ch in row['korean']:
        assert ch.isspace() or (ord(ch)<=maxc and cmap[ord(ch)]>0),(row['offset'],ch)
prefix=PREFIX.read_bytes()
def archive_resource(index):
    pos=48+u32(prefix,8)+index*32
    _,off,size,raw_size,_=struct.unpack_from('>IQQQI',prefix,pos)
    raw=zlib.decompress(prefix[off:off+size]);assert len(raw)==raw_size
    return raw
assert archive_resource(11)==archive_resource(12)==old
oldfont=archive_resource(770)
gb=0x8a+(maxc+1)*2;oldgb=0x8a+(u16(oldfont,0x88)+1)*2
assert u32(oldfont,oldgb)==325 and font[gb+4:gb+4+325*16]==oldfont[oldgb+4:oldgb+4+325*16]
for t in read(UI/'manifest.json')['targets']:
    b=(ISO/t['payload']).read_bytes()
    assert len(b)==t['payload_size'] and sha(b)==t['payload_sha256']
    assert len(zlib.decompress(b))==t['raw_size']
def assets(b):
    assert b[:4]==b'XUIZ' and u32(b,8)==len(b)
    start=22+u32(b,16);p=22;rows=[]
    for _ in range(u16(b,20)):
        size,off,n=struct.unpack_from('>IIB',b,p)
        name=b[p+9:p+9+n*2].decode('utf-16-be');p+=9+n*2
        rows.append((name,start+off,size))
    assert p==start
    return {name:b[off:off+size] for name,off,size in rows}
def xus(b):
    assert b[:6]==b'XUIS\1\0' and u32(b,6)==len(b)
    p=12;result={}
    for _ in range(u16(b,10)):
        pair=[]
        for _ in range(2):
            n=u16(b,p);p+=2;pair.append(b[p:p+n*2].decode('utf-16-be'));p+=n*2
        assert pair[1] not in result;result[pair[1]]=pair[0]
    assert p==len(b)
    return result
aa=assets(zlib.decompress((ISO/'payload/ui_assets.bin').read_bytes()))
ui_count=0;ui_missing=set();residual=[]
for name,b in aa.items():
    if not name.startswith(('en-US\\','ko-kR\\')) or not name.endswith('.xus'):continue
    rows=xus(b);ui_count+=1
    for key,value in rows.items():
        if not key.endswith('.Text'):continue
        if re.search('[가-힣]',value):
            for ch in value:
                if not ch.isspace() and (ord(ch)>maxc or cmap[ord(ch)]==0):ui_missing.add(ch)
        elif re.search('[A-Za-z]',value):residual.append(dict(resource=name,key=key,text=value))
assert not ui_missing
for locale in ['en-US','ko-kR']:
    rows=xus(aa[locale+'\\E3LoadScreen.xus'])
    assert rows['XuiScene1.HintText.Text']==''
    assert rows['XuiScene1.HintText.PointSize']=='20.000000'
campaign=[r for r in keyed if re.match(r'(M\d|XV_|hint\d|HINTTEXT|IDS_LOADSCREEN)',r['key'],re.I)]
missing=[r for r in campaign if re.search('[A-Za-z]{2}',r['source']) and r['source'].strip() not in ['<empty>','<unused>'] and not r['translated']]
assert not missing


# v0.9 release-specific regression checks.
fixes=read(UI/'translations_revised_v09.json')
expected={r['offset'] for r in fixes}
assert expected=={130596,293328,143904,338292,219308,276492,404688,181448}
previous=zlib.decompress((BASE/'payload/common_strings.bin').read_bytes())
PV,_=get_values(previous)
assert {a[0] for a,b in zip(PV,B) if a!=b}==expected
for r in fixes:
    assert r['applied'] and changes[r['offset']]['korean']==r['suggested']
    assert changes[r['offset']]['source']==r['source']
for name in ['korean_font.bin','ui_assets.bin']:
    assert (BASE/'payload'/name).read_bytes()==(UI/'payload'/name).read_bytes()==(ISO/'payload'/name).read_bytes()
assert (UI/'payload/common_strings.bin').read_bytes()==(ISO/'payload/common_strings.bin').read_bytes()
for name in ['Patch.ps1','manifest.json']:
    assert (UI/'upgrade_v08'/name).read_bytes()==(BASE/name).read_bytes()
assert (BASE/'Patch.ps1').read_text(encoding='utf-8-sig').replace('v08','v09').replace('0.8','0.9')==(UI/'Patch.ps1').read_text(encoding='utf-8-sig')
s=(BASE/'Upgrade.ps1').read_text(encoding='utf-8-sig').replace('v08','v09').replace('0.8','0.9')
s=s.replace("@('v07','v06','v05','v04','v03','v02','v01')","@('v08','v07','v06','v05','v04','v03','v02','v01')")
assert s==(UI/'Upgrade.ps1').read_text(encoding='utf-8-sig')
for version in ['v01','v02','v03','v04','v05','v06','v07','v08']:
    restore=(UI/('upgrade_'+version)/'Patch.ps1').read_text(encoding='utf-8-sig')
    assert 'Condemned_KoreanUI_'+version+'.state.json' in restore
    assert 'Layer0.Arch00.pre_KoreanUI_'+version+'.bak' in restore
assert read(ISO/'iso_manifest.json')['version']=='0.9-ISO'
assert "'0.9-ISO'" in (ISO/'PatchISO.ps1').read_text(encoding='utf-8-sig')
# Read appended-resource layout independently for the folder patch plan.
m=read(UI/'manifest.json');cursor=m['original_size'];spans=[]
for t in m['targets']:
    cursor=(cursor+15)//16*16
    blob=(UI/t['payload']).read_bytes()
    spans.append({'index':t['index'],'offset':cursor,'size':len(blob),'sha256':sha(blob)})
    cursor+=len(blob)
assert all(s['offset']>=m['original_size'] and s['offset']%16==0 for s in spans)
assert all(a['offset']+a['size']<=b['offset'] for a,b in zip(spans,spans[1:]))
actual_translated=sum(a[1]!=b[1].rstrip('\u200b') for a,b in zip(A,B))
summary={'status':'PASS','version':'0.9','managed_string_entries':len(translations),
 'source_text_changed_slots':actual_translated,'original_slots':len(A),'id_records':len(names),
 'v08_changed_slots':sorted(expected),'other_strings_preserved':True,'font_and_ui_preserved':True,
 'loading_hint_keys':len(hints),'page_and_time_tagged_translations':paged,
 'input_tag_exceptions':len(exceptions),'new_text_missing_glyphs':len(ui_missing),
 'upgrade_v08_restore_files_preserved':True,'old_upgrade_routes':8,
 'folder_append_plan':spans,'folder_output_size':cursor,
 'runtime_tested':False,'installer_runtime_tested':False}
(UI/'source/static_v09.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
