"""Build the eight reviewed fixes over v0.8. No original game files are shipped.
Usage: python build_v09.py V08_UI V08_ISO FINDINGS_JSON ORIGINAL_PREFIX OUTPUT_DIR
"""
from pathlib import Path
import hashlib,json,re,shutil,struct,subprocess,sys,zlib

BASE,IBASE,FINDINGS,PREFIX,OUT=map(Path,sys.argv[1:6])
UI=OUT/'Condemned_Korean_UI_v09';ISO=OUT/'Condemned_Korean_ISO_v09'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def win(p,s):p.write_bytes(b'\xef\xbb\xbf'+s.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8'))
assert not UI.exists() and not ISO.exists()
shutil.copytree(BASE,UI,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copytree(IBASE,ISO,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
fixes=read(FINDINGS)
assert {f['id'] for f in fixes}=={f'F{i:02}' for i in range(1,9)}
for f in fixes:
    if f['id']=='F05':
        f['suggested']='공격 속도'
        f['decision']='Use the broader attack-speed term because the exact firearm/melee scope is unconfirmed.'
    if f['id']=='F06':
        f['decision']='Keep the standard abbreviation SMG: the correct Korean name exceeds this fixed slot.'
rows=read(UI/'gameplay_translations.json');byoff={r['offset']:r for r in rows}
before=zlib.decompress((BASE/'payload/common_strings.bin').read_bytes())
data=bytearray(before);allowed=bytearray(len(data))
for f in fixes:
    off=f['offset'];size=f['slot_bytes'];end=off
    while before[end:end+2]!=b'\0\0':end+=2
    assert before[off:end].decode('utf-16-be').rstrip('\u200b')==f['current']
    assert (end+5)&~3==off+size
    r=byoff.get(off)
    if r:
        assert r['source']==f['source'] and r['korean']==f['current'] and r['slot_bytes']==size
    else:
        assert f['source']==f['current']
        r={'offset':off,'source':f['source'],'korean':f['current'],'slot_bytes':size}
        rows.append(r);byoff[off]=r
    enc=f['suggested'].encode('utf-16-be')
    assert len(enc)+2<=size and size%4==0
    assert re.findall(r'<%[^>]+%>',f['current'])==re.findall(r'<%[^>]+%>',f['suggested'])
    data[off:off+size]=enc+b'\x20\x0b'*((size-len(enc)-2)//2)+b'\0\0'
    allowed[off:off+size]=b'\1'*size
    r['korean']=f['suggested'];f['applied']=True;f['applied_version']='0.9'
assert len(rows)==len(byoff)==2093
assert len(data)==len(before) and all(a==b or allowed[i] for i,(a,b) in enumerate(zip(before,data)))
rows.sort(key=lambda r:r['offset'])
(UI/'payload/common_strings.bin').write_bytes(zlib.compress(data,9))
write(UI/'gameplay_translations.json',rows)
mapping=read(UI/'ui_translations.json')
for f in fixes:mapping[f['source']]=f['suggested']
write(UI/'ui_translations.json',mapping)
manifest=read(UI/'manifest.json')
for t in manifest['targets']:
    blob=(UI/t['payload']).read_bytes()
    t.update(payload_size=len(blob),payload_sha256=sha(blob),raw_size=len(zlib.decompress(blob)))
write(UI/'manifest.json',manifest)
history=UI/'upgrade_v08';history.mkdir()
for n in ['Patch.ps1','manifest.json']:shutil.copyfile(BASE/n,history/n)
for name in ['Patch.ps1','Upgrade.ps1']:
    text=(BASE/name).read_text(encoding='utf-8-sig').replace('v08','v09').replace('0.8','0.9')
    if name=='Upgrade.ps1':
        old="@('v07','v06','v05','v04','v03','v02','v01')"
        assert old in text
        text=text.replace(old,"@('v08','v07','v06','v05','v04','v03','v02','v01')")
    win(UI/name,text)

buildertext=(IBASE/'source/build_iso_v08.py').read_text().replace('v0.8','v0.9').replace('v08','v09').replace('V08','V09').replace("version='0.8-ISO'","version='0.9-ISO'")
builder=OUT/'build_iso_v09.py';builder.write_text(buildertext)
subprocess.run([sys.executable,str(builder),str(UI),str(PREFIX),str(ISO)],check=True)
for name in ['PatchISO.ps1','IsoPatcher.cs']:
    text=(IBASE/name).read_text(encoding='utf-8-sig').replace('v08','v09').replace('0.8','0.9')
    if name.endswith('.ps1'):win(ISO/name,text)
    else:(ISO/name).write_text(text)
report=read(UI/'build_report.json')
report.update(version='0.9',common_fixed_sha256=sha(data),common_string_changes=rows,
    gameplay_translation_count=len(rows),retained_catalog_count=3012-len(rows),
    installer_validation='v0.9 runtime not executed. The v0.8 installer logic is retained; version identifiers and upgrade_v08 routing updated. See QA_KR.txt.',
    runtime_tested=False,v09_reviewed_fix_count=8,v09_new_managed_entries=2,
    v09_scope='Exactly eight reviewed string slots differ from v0.8. All other strings, font and UI assets are byte-identical.',
    v09_validation='Pending final verification; see source/verification_v09.txt.')
write(UI/'build_report.json',report)
common='''이번 변경 (2026-10-09)
- Desktop: 바탕 화면 → 책상 상판
- Draw: 꺼내기 → 무승부
- Boot: 장화로 번역
- 체크포인트 저장 공간 부족: 내부 코드 대신 한국어 안내문 표시
- Rate: 비율 → 공격 속도
- SMG: 부정확한 기관총 대신 표준 약어 SMG 사용
- Last Weapon: 마지막 무기 → 직전 무기
- 로딩 팁 22: 피해 표시 → 공격력 표시

SMG는 기관단총을 뜻합니다. 기존 문자열 공간에 정확한 한국어 명칭이 들어가지 않아 약어를 유지했습니다.
이전 v0.8의 대사 수정과 전체 번역 데이터가 포함된 통합 패치입니다.
이번 수정은 위 8개 문자열뿐이며 다른 대사, 신발자국 분석 대사, 글꼴 및 UI 레이아웃은 v0.8과 동일합니다.
43개 로딩 팁 ID의 번역을 유지합니다. 장화·무승부 등 잔존 항목의 본편 화면 사용 여부는 미확인입니다.

검수 범위
문자열 공간·태그·글꼴·UI 참조·아카이브 위치 및 압축 데이터 검사는 QA_KR.txt에 기록했습니다.
실제 Xenia 플레이, 자막 잘림·음성 싱크 및 엔딩까지 무중단 진행은 별도 실행 확인이 필요합니다.
source의 v0.8 이하 기록은 해당 과거 버전의 기록입니다. v0.9 결과는 source/verification_v09.txt를 참고하세요.
'''
ui_readme='''컨뎀드 Xbox 360 한글화 v0.9 — 검수 수정 통합판
한글화: 슬림쉐이디

설치 및 업데이트
1. 게임과 Xenia를 완전히 종료합니다.
2. Condemned_Korean_UI_v09 폴더를 default.xex, Layer0.Arch00와 나란히 놓습니다.
3. 새 폴더 안의 RUN_FIX.bat를 실행합니다. 깨끗한 원본에도 같은 파일을 사용합니다.
4. FIX APPLIED를 확인한 뒤 그 게임 폴더의 default.xex를 실행합니다.
   Xenia 콘솔 언어는 English 또는 Korean으로 설정합니다.
기존 v0.1~v0.8의 정상 백업(.bak)과 설치 기록(.state.json)이 있으면 검증·복원 후 업데이트합니다.
이전 백업과 설치 기록을 지우거나 이름을 바꾸지 마세요.
약 1.6GB 이상의 여유 공간이 필요하며, 작업 중 창을 닫지 마세요.
ISO 패치판에서 추출한 폴더에는 이 업데이트를 적용하지 말고 깨끗한 원본을 사용하세요.

원본 복원
게임과 Xenia를 종료한 뒤 v0.9 폴더의 RUN_RESTORE.bat를 실행합니다.
백업: Layer0.Arch00.pre_KoreanUI_v09.bak
설치 기록: Condemned_KoreanUI_v09.state.json

'''+common+'''
원본 게임 파일은 포함하지 않습니다.
Windows PowerShell용 설치기입니다. FONT_LICENSE.txt와 XENIA_LICENSE.txt를 참고하세요.
font_preview.png는 글꼴 견본이며 실제 게임 화면이 아닙니다.
'''
iso_readme='''Condemned: Criminal Origins — 한글 ISO 패치 v0.9
한글화: 슬림쉐이디

사용 방법
1. ZIP을 폴더에 전부 압축 해제합니다.
2. RUN_ISO_PATCH.bat를 실행하고 패치하지 않은 원본 ISO를 선택합니다.
3. 복사와 검사가 끝나면 원본 옆에 '원본이름_Korean_v09.iso'가 생깁니다.
4. Xenia에서 새 ISO를 엽니다. 콘솔 언어는 English 또는 Korean으로 설정합니다.

기존 v0.8 등을 적용한 ISO 위에 덧씌우지 마세요. 반드시 깨끗한 원본 ISO로 새로 만드세요.
이 파일은 전체 번역을 포함한 통합 패치이므로 이전 패치를 먼저 적용할 필요가 없습니다.
원본 ISO 한 개 크기만큼의 여유 공간이 필요합니다. '완료!' 메시지까지 창을 닫지 마세요.
원본 ISO는 덮어쓰지 않습니다. 세이브 파일도 변경하지 않습니다.

'''+common+'''
지원 원본과 오류 처리
기존 v0.8에서 지원한 Xbox 360 원본 판본과 같은 판본입니다.
실행 파일, Layer0 크기와 원본 해시, Layer1 리소스 충돌 여부를 검사합니다.
압축 파일·분할 ISO·다른 판본·수정된 ISO에는 강제로 적용하지 않습니다.
- Output already exists: 같은 이름의 결과 ISO를 옮기거나 이름을 변경하세요.
- Layer0 differs / default.xex differs: 지원 원본과 다르거나 이미 패치된 파일입니다.
- No compatible XDVDFS: 지원하는 Xbox 360 ISO 구조를 찾지 못했습니다.
- Insufficient free space: 출력 드라이브에 ISO 크기만큼의 공간이 필요합니다.
- payload mismatch: ZIP을 다시 받아 새 폴더에 압축 해제하세요.
오류가 계속되면 iso_patch_error.txt와 오류 화면을 확인해 주세요.

원본과 복구
원본으로 돌아가려면 Xenia에서 보관한 원본 ISO를 열면 됩니다.
결과 ISO와 같은 이름의 .patch-info.txt에 원본/결과 SHA-256이 기록됩니다.
복사 후 전체 결과 ISO를 다시 읽어 검증한 다음 최종 파일명으로 저장합니다.

선택 사항: 다른 드라이브에 생성
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\\PatchISO.ps1 -IsoPath "D:\\Games\\Condemned.iso" -OutputPath "E:\\Games\\Condemned_Korean.iso"

선택 사항: 파일 생성 없이 호환성 검사
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\\PatchISO.ps1 -IsoPath "D:\\Games\\Condemned.iso" -InspectOnly

환경 및 라이선스
Windows 10/11의 Windows PowerShell 5.1용 설치기입니다.
이전 v0.8의 설치 실행 검증과 이번 v0.9의 데이터 검증 범위는 QA_KR.txt에 구분했습니다.
Xenia용이며 실기기 구동은 검증하지 않았습니다.
원본 게임 ISO, default.xex, 원본 아카이브는 포함하지 않습니다.
FONT_LICENSE.txt / XENIA_LICENSE.txt를 참고하세요.
'''
win(UI/'README_KR.txt',ui_readme);win(ISO/'README_KR.txt',iso_readme)
for package in [UI,ISO]:
    write(package/'translations_revised_v09.json',fixes)
    shutil.copyfile(__file__,package/'source/build_v09.py')
    write(package/'source/review_input_v09.json',fixes)
    (package/'source/NOTES_v09.md').write_text('v0.9: eight reviewed string fixes. Other strings, font and UI remain identical to v0.8.\nReproduce with build_v09.py using v08 UI, v08 ISO, review_input_v09.json, original 8MiB prefix and a new output directory.\nOld verification files are historical. Current results: verification_v09.txt.\n',encoding='utf-8')
print(json.dumps({'version':'0.9','fixes':len(fixes),'managed_string_entries':len(rows),'common_raw_sha256':sha(data)},indent=2))
