"""Finalize the documented and verified v0.9 directories and validate ZIP bytes.
Usage: python finalize_v09.py OUTPUT_DIRECTORY
The data builder is build_v09.py; QA reports are written after validation.
"""
from pathlib import Path
import hashlib,json,sys,zipfile,zlib
root=Path(sys.argv[1]);sha=lambda b:hashlib.sha256(b).hexdigest()
result={}
for name in ['Condemned_Korean_ISO_v09','Condemned_Korean_UI_v09']:
    package=root/name
    files=sorted(p for p in package.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt')
    assert not any(p.suffix in ['.iso','.xex','.Arch00','.pyc'] or '__pycache__' in p.parts for p in files)
    text=''.join(sha(p.read_bytes())+'  '+p.relative_to(package).as_posix()+'\n' for p in files)
    (package/'SHA256SUMS.txt').write_text(text,encoding='utf-8')
    output=root/(name+'.zip')
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for p in sorted(package.rglob('*')):
            if p.is_file():archive.write(p,p.relative_to(root).as_posix())
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist())==len(files)+1
        for line in archive.read(name+'/SHA256SUMS.txt').decode().splitlines():
            expected,rel=line.split('  ',1)
            assert sha(archive.read(name+'/'+rel))==expected
        # Validate the bytes shipped in the ZIP, rather than only staging files.
        mf='iso_manifest.json' if '_ISO_' in name else 'manifest.json'
        manifest=json.loads(archive.read(name+'/'+mf))
        db=zlib.decompress(archive.read(name+'/payload/common_strings.bin'))
        fixes=json.loads(archive.read(name+'/translations_revised_v09.json'))
        for f in fixes:
            off=f['offset'];end=off
            while db[end:end+2]!=b'\0\0':end+=2
            assert db[off:end].decode('utf-16-be').rstrip('\u200b')==f['suggested']
        rows=manifest.get('targets',manifest.get('moves'))
        for r in rows:
            if not r['payload']:continue
            payload=archive.read(name+'/'+r['payload'])
            assert sha(payload)==r.get('payload_sha256',r.get('sha256'))
            assert len(payload)==r.get('payload_size',r.get('size'))
            assert len(zlib.decompress(payload))==r['raw_size']
    result[output.name]={'size':output.stat().st_size,'sha256':sha(output.read_bytes()),
        'manifest_file_count':len(files),'zip_crc':'PASS','shipped_eight_fixes':'PASS'}
(root/'release_validation_v09.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
