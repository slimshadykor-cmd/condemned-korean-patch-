"""Data-level crash-risk checks. No claim of game execution or runtime safety.
Usage: python check_crash_data_v09.py V09_UI V09_ISO ORIGINAL_PREFIX OUTPUT_DIR
Uses the original diagnostic prefix and v0.9 payload bytes.
"""
from pathlib import Path
import ast, copy, hashlib, json, math, re, struct, zlib, sys

ROOT = Path.cwd()
UI,ISO,PREFIX,OUT=map(Path,sys.argv[1:5])
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
u16 = lambda b,p: struct.unpack_from('>H',b,p)[0]
u32 = lambda b,p: struct.unpack_from('>I',b,p)[0]
sha = lambda b: hashlib.sha256(b).hexdigest()
result = {'version':'0.9','runtime_tested':False,'validator_modified_patch':False}

def strict_inflate(blob, expected):
    d = zlib.decompressobj()
    raw = d.decompress(blob, expected+1)
    assert d.eof and not d.unused_data and not d.unconsumed_tail
    assert len(raw)==expected and not d.flush()
    return raw

prefix = PREFIX.read_bytes()
m = read(ISO/'iso_manifest.json')
assert len(prefix)==m['prefix_size'] and sha(prefix)==m['original_prefix_sha256']
patched = bytearray(prefix)
patched[m['region_start']:m['region_end']] = bytes(m['region_end']-m['region_start'])
for move in m['moves']:
    off,size = move['source_offset'],move['source_size']
    data = (ISO/move['payload']).read_bytes() if move['payload'] else prefix[off:off+size]
    assert len(data)==move['size'] and sha(data)==move['sha256']
    patched[move['destination']:move['destination']+len(data)] = data
    struct.pack_into('>QQQ',patched,move['entry_offset']+4,move['destination'],len(data),move['raw_size'])
assert len(patched)==len(prefix) and sha(patched)==m['patched_prefix_sha256']

def archive(b):
    assert b[:8]==b'RATL\0\0\0\3'
    ns,dirs,count = struct.unpack_from('>III',b,8)
    table = 48+ns
    assert table+count*32<=m['region_start']
    rows=[]
    for i in range(count):
        name,off,size,rawsize,flag = struct.unpack_from('>IQQQI',b,table+32*i)
        assert name<ns and b.find(b'\0',48+name,48+ns)>=0
        assert off+size<=m['original_size'] and flag in [0,1]
        if size: assert off>=m['region_start'] and rawsize>0
        rows.append((name,off,size,rawsize,flag))
    return rows, table

a,table = archive(prefix)
b,_ = archive(patched)
def overlaps(rows):
    intervals=sorted((e[1],e[1]+e[2],i) for i,e in enumerate(rows) if e[2])
    found=[]
    for j,(start,end,i) in enumerate(intervals):
        for other,other_end,k in intervals[j+1:]:
            if other>=end: break
            found.append((i,k,start==other and end==other_end))
    return found
assert overlaps(a)==[]
assert overlaps(b)==[(11,12,True)],overlaps(b)
assert b[11]==b[12]
changed = {r['index'] for r in m['moves']}
assert len(changed)==len(m['moves'])==25
mask=bytearray(len(prefix))
mask[m['region_start']:m['region_end']]=b'\1'*(m['region_end']-m['region_start'])
for i in changed: mask[table+i*32+4:table+i*32+28]=b'\1'*24
assert all(x==y or mask[i] for i,(x,y) in enumerate(zip(prefix,patched)))
checked=[]
raw_a={};raw_b={}
for i,(old,new) in enumerate(zip(a,b)):
    assert old[0]==new[0] and old[4]==new[4]
    if i not in changed: assert old==new
    if old[1]+old[2]<=len(prefix):
        for buf,entry,dest in [(prefix,old,raw_a),(patched,new,raw_b)]:
            _,off,size,rawsize,flag=entry
            data=bytes(buf[off:off+size])
            dest[i]=strict_inflate(data,rawsize) if flag else data
            assert len(dest[i])==rawsize
        if i not in [11,12,769,770]: assert raw_a[i]==raw_b[i]
        checked.append(i)
result['archive']={'entry_count':len(a),'directory_count':u32(prefix,12),
    'complete_prefix_entries':len(checked),'strict_zlib_streams_per_image':sum(a[i][4]==1 for i in checked),
    'new_overlap':'Only the intentionally identical string records 11/12 share one complete blob.',
    'changed_directory_records':len(changed),'outside_write_region_preserved':True,
    'patched_prefix_sha256':sha(patched)}

def assets(raw):
    assert raw[:4]==b'XUIZ' and u32(raw,8)==len(raw)
    base=22+u32(raw,16);count=u16(raw,20);p=22;rows=[]
    for _ in range(count):
        assert p+9<=base
        size,off,n=struct.unpack_from('>IIB',raw,p)
        assert p+9+2*n<=base
        name=raw[p+9:p+9+2*n].decode('utf-16-be');p+=9+2*n
        assert base<=base+off<=len(raw)-size
        rows.append((name,base+off,size))
    assert p==base and len({n for n,_,_ in rows})==count
    assert len({n.lower() for n,_,_ in rows})==count
    output={}
    for i,(name,off,size) in enumerate(rows):
        end=rows[i+1][1] if i+1<len(rows) else len(raw)
        assert off+size<=end
        trailer=raw[off+size:end]
        assert len(trailer)>=10 and len(trailer)==10+u16(trailer,8)*2
        trailer[10:].decode('utf-16-be')
        output[name]=(raw[off:off+size],trailer)
    return output

def xus(raw):
    assert raw[:6]==b'XUIS\1\0' and u32(raw,6)==len(raw)
    rows={};p=12
    for _ in range(u16(raw,10)):
        pair=[]
        for _ in range(2):
            assert p+2<=len(raw)
            n=u16(raw,p);p+=2
            assert p+2*n<=len(raw)
            s=raw[p:p+2*n].decode('utf-16-be');p+=2*n
            assert '\x00' not in s and '\ufffd' not in s
            pair.append(s)
        value,key=pair
        assert key not in rows
        rows[key]=value
    assert p==len(raw)
    return rows

aa=assets(raw_a[769]);ab=assets(raw_b[769])
assert aa.keys()==ab.keys()
xus_count=0;section_count=0;changed_nontext=[];ui_pairs=0;xur_preserved_variants=[]
token_re=r'<%[^>]+%>|%\d+![^!]+!|%(?:\d+\$)?[-+ #0]*\d*(?:\.\d+)?[sdiufFeEgGxXocp]|%%|\{\d+[^}]*\}'
for name,(raw,trailer) in ab.items():
    assert trailer==aa[name][1]
    old=aa[name][0]
    if name.endswith('.xus'):
        oldp,newp=xus(old),xus(raw);xus_count+=1;ui_pairs+=len(newp)
        added=set(newp)-set(oldp)
        if added:
            assert name in ['en-US\\frontEndMenu.xus','ko-kR\\frontEndMenu.xus']
            assert added=={'XuiScene1.KoreanCreditText.Text','XuiScene1.KoreanCreditText.PointSize'}
        assert not set(oldp)-set(newp)
        for key,value in oldp.items():
            if value!=newp[key]:
                if not key.endswith('.Text'):
                    changed_nontext.append({'resource':name,'key':key,'source':value,'target':newp[key]})
                    assert key.endswith('.PointSize')
                    assert math.isfinite(float(newp[key])) and (float(newp[key])==-1 or float(newp[key])>0)
                else: assert re.findall(token_re,value)==re.findall(token_re,newp[key]),(name,key)
    elif name.endswith('.xur'):
        assert raw[:8]==b'XUIB\0\0\0\5' and u32(raw,14)==len(raw)
        if raw[8:12]!=bytes(4):
            # Original skin uses an additional header. This parser only knows
            # the standard form; exact original-byte preservation is checked.
            assert raw==old
            xur_preserved_variants.append(name)
            continue
        end=20+12*u16(raw,18);tags=set()
        for j in range(u16(raw,18)):
            tag,off,size=struct.unpack_from('>4sII',raw,20+12*j)
            assert tag not in tags and off==end and off+size<=len(raw), (name,j,tag,off,end,size,len(raw))
            tags.add(tag);end+=size;section_count+=1
        assert end==len(raw)
        if name!='frontEndMenu.xur': assert raw==old
    else: assert raw==old

# Reuse the prior format reader, independently of the patch writer. Extract only
# its schema and tree parser; do not execute its old package-specific test body.
source=ast.parse((UI/'source/verify_v07.py').read_text())
nodes=[n for n in source.body if isinstance(n,ast.FunctionDef) and n.name=='tree'
       or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='schema' for t in n.targets)]
env={'u16':u16,'u32':u32,'struct':struct}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'prior_xur_reader','exec'),env)
original_tree=env['tree'](aa['frontEndMenu.xur'][0])
final_tree=env['tree'](ab['frontEndMenu.xur'][0])
restored=copy.deepcopy(final_tree)
credit=restored['children'][0]['children'].pop()
assert credit['class']=='XuiText' and credit['properties']['Id']=='KoreanCreditText'
assert credit['children']==[] and restored==original_tree
def count_nodes(tree): return 1+sum(count_nodes(n) for n in tree['children'])
result['ui']={'asset_count':len(ab),'xus_files':xus_count,'xus_property_pairs':ui_pairs,
    'xur_files':sum(n.endswith('.xur') for n in ab),'xur_sections':section_count,
    'xur_variant_preserved_without_section_parse':xur_preserved_variants,
    'fully_parsed_main_menu_nodes':count_nodes(final_tree),
    'original_main_menu_tree_preserved':True,'other_changed_properties':changed_nontext,
    'resource_paths_preserved':True,'format_tokens_preserved':True}

font=raw_b[770];oldfont=raw_a[770]
assert font[:4]==b'XPR2'
cpu,gpu=struct.unpack_from('>II',font,4)
assert len(font)==12+cpu+gpu and cpu%2048==0
assert font[12:20]==oldfont[12:20] and u32(font,12)==2
for r in range(2):
    tag,off,size,nameoff=struct.unpack_from('>4sIII',font,16+16*r)
    assert off+size<=cpu and nameoff<cpu
    assert font.find(b'\0',12+nameoff,12+cpu)>=0
maxc=u16(font,0x88);cmap=struct.unpack_from('>'+str(maxc+1)+'H',font,0x8a)
gb=0x8a+2*(maxc+1);ng=u32(font,gb)
assert gb+4+ng*16==0x74+u32(font,0x28)<=12+cpu
assert max(cmap)<ng
w=(u32(font,0x64)&8191)+1;h=((u32(font,0x64)>>13)&8191)+1
assert gpu==w*h and ((u32(font,0x5c)>>22)&511)==w//32
assert not any(font[gb+4+ng*16:12+cpu])
for i in range(ng):
    x0,y0,x1,y1,bearing,width,advance,mask=struct.unpack_from('>4H3hH',font,gb+4+16*i)
    assert 0<=x0<=x1<=w and 0<=y0<=y1<=h
    if i>=325: assert width>=0 and advance>=0
translations=read(UI/'gameplay_translations.json')
used={ch for r in translations for ch in r['korean'] if not ch.isspace()}
used.update(ch for name,(raw,_) in ab.items() if name.startswith(('en-US\\','ko-kR\\')) and name.endswith('.xus') for key,val in xus(raw).items() if key.endswith('.Text') for ch in val if not ch.isspace())
used.update(credit['properties']['Text'])
missing=sorted(ch for ch in used if not ch.isspace() and (ord(ch)>maxc or cmap[ord(ch)]==0))
# Some unchanged English developer/sample text may use an original absent glyph;
# record rather than misattribute it to translation.
new_used={ch for r in translations for ch in r['korean'] if not ch.isspace()}
for name,(raw,_) in ab.items():
    if name.endswith('.xus'):
        oldp=xus(aa[name][0]);newp=xus(raw)
        new_used.update(ch for key,val in newp.items() if key.endswith('.Text') and oldp.get(key)!=val for ch in val if not ch.isspace())
assert all(ord(c)<=maxc and 0<cmap[ord(c)]<ng for c in new_used)
result['font']={'cmap_entries':len(cmap),'glyph_count':ng,'all_indices_in_bounds':True,
    'all_glyph_rectangles_in_bounds':True,'texture_dimensions':[w,h],
    'gpu_data_bytes':gpu,'raw_font_bytes_before':len(oldfont),'raw_font_bytes_after':len(font),
    'raw_growth_bytes':len(font)-len(oldfont),'unchanged_text_missing_glyphs':missing,
    'new_text_missing_glyphs':0,'runtime_memory_budget_verified':False}

# The engine's ID/index tables must remain byte-identical, and every index must
# still point to a valid, bounded, terminated UTF-16 slot.
old,new=raw_a[12],raw_b[12]
count=u32(old,8);tab=24+u32(old,20)
p=24
for _ in range(count): p=(old.index(0,p)+4)&~3
assert old[:p]==new[:p] and old[tab:]==new[tab:] and len(old)==len(new)
pairs=[struct.unpack_from('>II',new,tab+i*8) for i in range(count)]
slots=max(idx for idx,_ in pairs)+1
source_pos=p;target_pos=p;maxunits=0;terminator_shifts=0;max_shift=0
for _ in range(slots):
    ends=[]
    for raw,pos in [(old,source_pos),(new,target_pos)]:
        end=pos
        while end+2<=tab and raw[end:end+2]!=b'\0\0':end+=2
        assert end+2<=tab
        raw[pos:end].decode('utf-16-be')
        ends.append(end)
    assert source_pos==target_pos and (ends[0]+5)&~3==(ends[1]+5)&~3
    terminator_shifts+=ends[0]!=ends[1]
    max_shift=max(max_shift,ends[1]-ends[0])
    maxunits=max(maxunits,(ends[1]-target_pos)//2)
    source_pos=(ends[0]+5)&~3;target_pos=(ends[1]+5)&~3
assert old[source_pos:]==new[target_pos:]
result['strings']={'id_records':count,'slots':slots,'all_slot_starts_and_next_boundaries_preserved':True,
    'all_terminators_within_same_original_slot':True,'terminator_shift_count':terminator_shifts,
    'maximum_terminator_forward_shift_bytes':max_shift,
    'id_and_voice_tables_preserved':True,'max_stored_utf16_units':maxunits,'raw_size_unchanged':len(new)}
result['status']='PASS_WITH_RUNTIME_LIMITATIONS'
result['limits']=['No game or installer runtime was executed in this follow-up.',
    'Only 8 MiB of original Layer0 bytes is available; later entries have bounds/table checks only.',
    'Layer1, full ISO, map scripts and save data were not provided for this audit.',
    'GPU allocation limits, engine heap use, timing, driver and emulator compatibility require execution.']
(OUT/'crash_data_result_v09.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
