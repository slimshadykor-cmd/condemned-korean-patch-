﻿Condemned: Criminal Origins — 한글 ISO 패치 v0.9
한글화: 슬림쉐이디

사용 방법
1. ZIP을 폴더에 전부 압축 해제합니다.
2. RUN_ISO_PATCH.bat를 실행하고 패치하지 않은 원본 ISO를 선택합니다.
3. 복사와 검사가 끝나면 원본 옆에 '원본이름_Korean_v09.iso'가 생깁니다.
4. Xenia에서 새 ISO를 엽니다. 콘솔 언어는 English 또는 Korean으로 설정합니다.

기존 v0.8 등을 적용한 ISO 위에 덧씌우지 마세요. 반드시 깨끗한 원본 ISO로 새로 만드세요.
이 파일은 전체 번역을 포함한 통합 패치이므로 이전 패치를 먼저 적용할 필요가 없습니다.
원본 ISO 한 개 크기만큼의 여유 공간이 필요합니다. '완료!' 메시지까지 창을 닫지 마세요.
원본 ISO는 덮어쓰지 않습니다. 세이브 파일도 변경하지 않습니다.

이번 변경 (2026-10-09)
- Desktop: 바탕 화면 → 책상 상판
- Draw: 꺼내기 → 무승부
- Boot: 장화로 번역
- 체크포인트 저장 공간 부족: 내부 코드 대신 한국어 안내문 표시
- Rate: 비율 → 공격 속도
- SMG: 부정확한 기관총 대신 표준 약어 SMG 사용
- Last Weapon: 마지막 무기 → 직전 무기
- 로딩 팁 22: 피해 표시 → 공격력 표시

SMG는 기관단총을 뜻합니다. 기존 문자열 공간에 정확한 한국어 명칭이 들어가지 않아 약어를 유지했습니다.
이전 v0.8의 대사 수정과 전체 번역 데이터가 포함된 통합 패치입니다.
이번 수정은 위 8개 문자열뿐이며 다른 대사, 신발자국 분석 대사, 글꼴 및 UI 레이아웃은 v0.8과 동일합니다.
43개 로딩 팁 ID의 번역을 유지합니다. 장화·무승부 등 잔존 항목의 본편 화면 사용 여부는 미확인입니다.

검수 범위
문자열 공간·태그·글꼴·UI 참조·아카이브 위치 및 압축 데이터 검사는 QA_KR.txt에 기록했습니다.
실제 Xenia 플레이, 자막 잘림·음성 싱크 및 엔딩까지 무중단 진행은 별도 실행 확인이 필요합니다.
source의 v0.8 이하 기록은 해당 과거 버전의 기록입니다. v0.9 결과는 source/verification_v09.txt를 참고하세요.

지원 원본과 오류 처리
기존 v0.8에서 지원한 Xbox 360 원본 판본과 같은 판본입니다.
실행 파일, Layer0 크기와 원본 해시, Layer1 리소스 충돌 여부를 검사합니다.
압축 파일·분할 ISO·다른 판본·수정된 ISO에는 강제로 적용하지 않습니다.
- Output already exists: 같은 이름의 결과 ISO를 옮기거나 이름을 변경하세요.
- Layer0 differs / default.xex differs: 지원 원본과 다르거나 이미 패치된 파일입니다.
- No compatible XDVDFS: 지원하는 Xbox 360 ISO 구조를 찾지 못했습니다.
- Insufficient free space: 출력 드라이브에 ISO 크기만큼의 공간이 필요합니다.
- payload mismatch: ZIP을 다시 받아 새 폴더에 압축 해제하세요.
오류가 계속되면 iso_patch_error.txt와 오류 화면을 확인해 주세요.

원본과 복구
원본으로 돌아가려면 Xenia에서 보관한 원본 ISO를 열면 됩니다.
결과 ISO와 같은 이름의 .patch-info.txt에 원본/결과 SHA-256이 기록됩니다.
복사 후 전체 결과 ISO를 다시 읽어 검증한 다음 최종 파일명으로 저장합니다.

선택 사항: 다른 드라이브에 생성
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\PatchISO.ps1 -IsoPath "D:\Games\Condemned.iso" -OutputPath "E:\Games\Condemned_Korean.iso"

선택 사항: 파일 생성 없이 호환성 검사
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\PatchISO.ps1 -IsoPath "D:\Games\Condemned.iso" -InspectOnly

환경 및 라이선스
Windows 10/11의 Windows PowerShell 5.1용 설치기입니다.
이전 v0.8의 설치 실행 검증과 이번 v0.9의 데이터 검증 범위는 QA_KR.txt에 구분했습니다.
Xenia용이며 실기기 구동은 검증하지 않았습니다.
원본 게임 ISO, default.xex, 원본 아카이브는 포함하지 않습니다.
FONT_LICENSE.txt / XENIA_LICENSE.txt를 참고하세요.
