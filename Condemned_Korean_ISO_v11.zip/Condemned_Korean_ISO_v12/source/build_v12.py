from pathlib import Path
import collections, hashlib, json, re, shutil, struct, zlib
from credit_v12 import build_credit

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'collectible_audit/package/Condemned_Korean_ISO_v11'
OUT = ROOT / 'condemned_v12/repo'
PKG = OUT / 'Condemned_Korean_ISO_v12'
WORK = ROOT / 'condemned_v12/work'
sha = lambda b: hashlib.sha256(b).hexdigest()

# Only these eighteen existing string slots are authorized for this revision.
REPLACEMENTS = {
    1366: '통제선에 다가가 <%action%> 버튼으로\n몸을 숙여 통과하세요.',
    1373: '<%flashlight%> 버튼으로\n불을 켜고 끄세요.',
    1384: '<%tools%> 버튼으로\n수사 도구를 준비하세요.',
    1465: '복부에 채취기를 조준하고\n<%fire%> 버튼으로 자료를 수집하세요.',
    1468: '증거에 스캐너를 조준하고\n<%fire%> 버튼으로 자료를 수집하세요.',
    1472: '<%fire%> 버튼으로 총을 쏘세요.',
    1476: '<%ammocheck%> 버튼으로 탄약을 확인하세요.',
    1479: '<%togglemelee%> 버튼으로\n근접 공격으로 바꾸세요.',
    1539: '<%sprint%> 버튼으로 달리세요.',
    1555: '<%taser%> 버튼으로 테이저를 발사하세요.',
    1560: '<%kick%> 버튼으로\n적을 걷어차세요.',
    1635: '<%fire%> 버튼으로 무기를 휘두르세요.',
    1639: '<%block%> 버튼으로 막으세요.',
    1659: '<%pause%> 버튼으로\n목표를 확인하세요.',
    1732: '<%aim%> 조작으로 흰 화살표가 모두\n안쪽을 향하게 도구를 조준하세요.',
    1736: '<%move%> 조작으로 화면 테두리가 밝게\n빛나도록 확대·축소를 조절하세요.',
    1744: '<%move%> 조작으로 작은 삼각형이\n맞닿도록 초점을 조절하세요.',
    1749: '<%togglemelee%> 버튼으로\n사격과 근접 공격을 바꾸세요.',
}

def parse_strings(data):
    count = struct.unpack_from('>I', data, 8)[0]
    table = 24 + struct.unpack_from('>I', data, 20)[0]
    names = []; p = 24
    for _ in range(count):
        end = data.index(0, p)
        names.append(data[p:end].decode('latin1'))
        p = (end + 4) & ~3
    pairs = [struct.unpack_from('>II', data, table + i*8) for i in range(count)]
    slots = []
    for _ in range(max(i for i, _ in pairs) + 1):
        end = p
        while data[end:end+2] != b'\0\0':
            end += 2
        nxt = (end + 5) & ~3
        slots.append((p, end, nxt, data[p:end].decode('utf-16-be').rstrip('\u200b')))
        p = nxt
    return names, pairs, slots

def make_prefix(source, moves, manifest, package):
    result = bytearray(source)
    rs, re_ = manifest['region_start'], manifest['region_end']
    result[rs:re_] = bytes(re_-rs)
    for m in moves:
        assert source[m['entry_offset']:m['entry_offset']+32].hex() == m['original_entry_hex']
        data = (package/m['payload']).read_bytes() if m['payload'] else source[m['source_offset']:m['source_offset']+m['source_size']]
        assert len(data) == m['size'] and sha(data) == m['sha256']
        assert rs <= m['destination'] <= re_ - len(data)
        result[m['destination']:m['destination']+len(data)] = data
        struct.pack_into('>QQQ', result, m['entry_offset']+4, m['destination'], m['size'], m['raw_size'])
    return bytes(result)

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    assert sha((ROOT/'collectible_audit/Condemned_Korean_ISO_v11.zip').read_bytes()) == 'e0a0a9c7ca4092dbdfa1c483aeea03d03c9f2b75421749dcaae31523355578cc'
    if not PKG.exists():
        shutil.copytree(BASE, PKG)
    for p in PKG.glob('patch_result_*.json'):
        p.unlink()
    original = (ROOT/'collectible_audit/analysis/12_DARK.Strdb00p.original').read_bytes()
    before = zlib.decompress((BASE/'data/payload/common_strings.bin').read_bytes())
    names, pairs, slots = parse_strings(before)
    onames, opairs, oslots = parse_strings(original)
    assert names == onames and pairs == opairs
    assert [(s[0],s[2]) for s in slots] == [(s[0],s[2]) for s in oslots]
    token = lambda s: re.findall(r'<%[^%]+%>', s)
    missing = {i for i,s in enumerate(slots) if collections.Counter(token(s[3])) != collections.Counter(token(oslots[i][3]))}
    assert missing == set(REPLACEMENTS)
    after = bytearray(before); changed = []
    font = zlib.decompress((BASE/'data/payload/korean_font.bin').read_bytes())
    maxc = struct.unpack_from('>H',font,0x88)[0]
    cmap = struct.unpack_from('>'+str(maxc+1)+'H',font,0x8a)
    for i, text in REPLACEMENTS.items():
        p, end, nxt, old = slots[i]; capacity = (end-p)//2
        assert len(text) <= capacity, (i,len(text),capacity,text)
        assert collections.Counter(token(text)) == collections.Counter(token(oslots[i][3]))
        assert re.search('[가-힣]', text)
        for ch in text:
            assert ch.isspace() or (ord(ch) <= maxc and cmap[ord(ch)]), (i,ch)
        after[p:end] = (text+'\u200b'*(capacity-len(text))).encode('utf-16-be')
        changed.append(dict(index=i,keys=[k for k,(j,v) in zip(names,pairs) if j==i],offset=p,slot_bytes=nxt-p,source=oslots[i][3],before=old,after=text,tokens=token(text)))
    _, _, newslots = parse_strings(after)
    assert [s[:3] for s in newslots] == [s[:3] for s in slots]
    assert {i for i,(a,b) in enumerate(zip(slots,newslots)) if a[3]!=b[3]} == set(REPLACEMENTS)
    allowed = bytearray(len(before))
    for i in REPLACEMENTS:
        p,end,nxt,_=slots[i];allowed[p:end]=bytes([1])*(end-p)
    assert len(before)==len(after) and all(a==b or allowed[i] for i,(a,b) in enumerate(zip(before,after)))
    assert all(collections.Counter(token(a[3]))==collections.Counter(token(b[3])) for a,b in zip(oslots,newslots))
    compressor = zlib.compressobj(9,zlib.DEFLATED,15,6)
    compressed = compressor.compress(after)+compressor.flush()
    (PKG/'data/payload/common_strings.bin').write_bytes(compressed)
    ui,ui_changed=build_credit(zlib.decompress((BASE/'data/payload/ui_assets.bin').read_bytes()))
    ui_candidates=[]
    for mem in [6,7,8,9]:
        c=zlib.compressobj(9,zlib.DEFLATED,15,mem)
        ui_candidates.append((c.compress(ui)+c.flush(),mem))
    ui_compressed,ui_mem=min(ui_candidates,key=lambda x:len(x[0]))
    optimized=WORK/'ui_credit_zopfli.bin'
    if not optimized.exists():
        import zopfli.zlib  # Build-time dependency: zopfli==0.4.3; not needed by the end-user patcher.
        optimized.write_bytes(zopfli.zlib.compress(ui,numiterations=2))
    if optimized.exists():
        candidate=optimized.read_bytes()
        assert zlib.decompress(candidate)==ui
        if len(candidate)<len(ui_compressed):ui_compressed=candidate;ui_mem='zopfli-2'
    (PKG/'data/payload/ui_assets.bin').write_bytes(ui_compressed)
    manifest = json.loads((BASE/'data/iso_manifest.json').read_text())
    prior = json.loads(json.dumps(manifest))
    manifest['format_version']=2;manifest['version']='1.2-ISO';manifest['translation_data_version']='1.2'
    manifest['previous_prefix_sha256']=prior['patched_prefix_sha256']
    clean=(ROOT/'collectible_audit/inputs/Condemned_Diagnostic/Layer0_first_8MB.bin').read_bytes()
    previous=(ROOT/'collectible_audit/analysis/patched_prefix.bin').read_bytes()
    assert sha(clean)==prior['original_prefix_sha256'] and sha(previous)==prior['patched_prefix_sha256']
    # Keep every existing resource offset if the replacement fits. Otherwise move
    # the existing compressed blobs verbatim with the same original pack order.
    limit=min(m['destination'] for m in manifest['moves'] if m['index'] not in (11,12))
    common_start=manifest['moves'][0]['destination']
    old_ui=next(m for m in manifest['moves'] if m['index']==769)
    ui_limit=min(m['destination'] for m in manifest['moves'] if m['destination']>old_ui['destination'])
    preserve_offsets=common_start+len(compressed)<=limit and old_ui['destination']+len(ui_compressed)<=ui_limit
    cursor=manifest['region_start']; seen={}
    for m in manifest['moves']:
        if m['index'] in (11,12):m.update(size=len(compressed),sha256=sha(compressed))
        if m['index']==769:m.update(size=len(ui_compressed),raw_size=len(ui),sha256=sha(ui_compressed))
        if not preserve_offsets:
            identity=('common' if m['index'] in (11,12) else m['index'])
            if identity not in seen:
                cursor=(cursor+15)&~15;seen[identity]=cursor;cursor+=m['size']
            m['destination']=seen[identity]
    manifest['unused_bytes']=manifest['region_end']-max(m['destination']+m['size'] for m in manifest['moves'])
    assert manifest['unused_bytes']>=0
    manifest['previous_moves']=[]
    for m, old in zip(manifest['moves'],prior['moves']):
        up=dict(m)
        up.update(original_entry_hex=previous[m['entry_offset']:m['entry_offset']+32].hex(),source_offset=old['destination'],source_size=old['size'])
        manifest['previous_moves'].append(up)
    output=make_prefix(clean,manifest['moves'],manifest,PKG/'data')
    upgraded=make_prefix(previous,manifest['previous_moves'],manifest,PKG/'data')
    assert output==upgraded
    manifest['patched_prefix_sha256']=sha(output)
    (PKG/'data/iso_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    (WORK/'prefix_v12.bin').write_bytes(output)
    (PKG/'source/hint_changes_v12.json').write_text(json.dumps(changed,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(changed_slots=len(changed),keys=sum(len(c['keys']) for c in changed),old_compressed_size=prior['moves'][0]['size'],new_compressed_size=len(compressed),offsets_preserved=preserve_offsets,unused_bytes=manifest['unused_bytes'],prefix_sha256=sha(output),ui_compressed_size=len(ui_compressed),ui_mem=ui_mem,ui_changed=ui_changed),ensure_ascii=False))

if __name__=='__main__':main()
