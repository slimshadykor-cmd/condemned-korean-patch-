from pathlib import Path
import hashlib, json, os, re, struct, subprocess, zlib
from build_v12 import ROOT, BASE, PKG, WORK, REPLACEMENTS, parse_strings
from credit_v12 import asset_rows,xur_sections,strn,xus_pairs,OLD_CREDIT,NEW_CREDIT

P=PKG/'data';T=WORK/'tests_final';T.mkdir(exist_ok=True)
PW=WORK/'pwsh/pwsh';os.chmod(PW,0o755)
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((P/'iso_manifest.json').read_text())
before=(ROOT/'collectible_audit/analysis/patched_prefix.bin').read_bytes()
after=(WORK/'prefix_v12.bin').read_bytes()
clean=(ROOT/'collectible_audit/inputs/Condemned_Diagnostic/Layer0_first_8MB.bin').read_bytes()
results=[]
def passed(s):results.append('PASS: '+s);print(results[-1],flush=True)

def directory(data):
    ns, count=struct.unpack_from('>I',data,8)[0],struct.unpack_from('>I',data,16)[0]
    return [struct.unpack_from('>IQQQI',data,48+ns+32*i) for i in range(count)]
a,b=directory(before),directory(after)
assert len(a)==len(b)==1318
assert {i for i,(x,y) in enumerate(zip(a,b)) if x!=y}=={11,12,769}
for i,(x,y) in enumerate(zip(a,b)):
    assert x[0]==y[0] and x[1]==y[1] and x[4]==y[4]
    if i!=769:assert x[3]==y[3]
    if i not in (11,12,769) and x[1]+x[2]<=len(before):assert before[x[1]:x[1]+x[2]]==after[y[1]:y[1]+y[2]]
allowed=bytearray(len(before));common=a[11]
allowed[common[1]:common[1]+common[2]]=bytes([1])*common[2]
ui=a[769];allowed[ui[1]:ui[1]+ui[2]]=bytes([1])*ui[2]
for idx in (11,12,769):
    off=48+struct.unpack_from('>I',before,8)[0]+32*idx+12
    allowed[off:off+8]=bytes([1])*8
    if idx==769:allowed[off+8:off+16]=bytes([1])*8
assert all(x==y or allowed[i] for i,(x,y) in enumerate(zip(before,after)))
oldraw=zlib.decompress(before[a[11][1]:a[11][1]+a[11][2]])
newraw=zlib.decompress(after[b[11][1]:b[11][1]+b[11][2]])
on,op,oslots=parse_strings(oldraw);nn,np,nslots=parse_strings(newraw)
assert on==nn and op==np and len(nslots)==3012 and len(nn)==4976
assert [s[:3] for s in oslots]==[s[:3] for s in nslots]
assert {i for i,(x,y) in enumerate(zip(oslots,nslots)) if x!=y}==set(REPLACEMENTS)
original=(ROOT/'collectible_audit/analysis/12_DARK.Strdb00p.original').read_bytes()
_,_,srcslots=parse_strings(original)
for src,new in zip(srcslots,nslots):assert re.findall(r'<%[^%]+%>',src[3])==re.findall(r'<%[^%]+%>',new[3])
for name in ['korean_font.bin','xex_achievement.delta']:
    assert (P/'payload'/name).read_bytes()==(BASE/'data/payload'/name).read_bytes()
for name in ['XexPatch.cs','GpdText.cs','ProfileBatch.cs','ProfilePaths.ps1','achievement_translations.json','xex_patch.json']:
    assert (P/name).read_bytes()==(BASE/'data'/name).read_bytes()
passed('exactly 18 Korean string slots changed; all 4,976 keys, 3,012 slot locations and original control tags preserved')
passed('all 1,318 resource offsets unchanged; only common/English strings, UI archive and their size fields changed; all other prefix bytes identical')
passed('font, executable delta, achievements and profile-processing files byte-identical to v1.1')
_,old_ui=asset_rows(zlib.decompress((BASE/'data/payload/ui_assets.bin').read_bytes()))
_,new_ui=asset_rows(zlib.decompress((P/'payload/ui_assets.bin').read_bytes()))
expected={'frontEndMenu.xur','en-US\\frontEndMenu.xus','ko-kR\\frontEndMenu.xus'}
assert len(old_ui)==len(new_ui)==464
assert {o['name'] for o,n in zip(old_ui,new_ui) if o['data']!=n['data']}==expected
for old,new in zip(old_ui,new_ui):
    assert old['name']==new['name'] and old['trailer']==new['trailer']
    if old['name']=='frontEndMenu.xur':
        oldsec=dict(xur_sections(old['data']));newsec=dict(xur_sections(new['data']))
        assert oldsec.keys()==newsec.keys()
        for k in oldsec:
            if k!=b'STRN':assert oldsec[k]==newsec[k]
        assert strn(oldsec[b'STRN'])[:-1]==strn(newsec[b'STRN'])[:-1]
        assert strn(oldsec[b'STRN'])[-1]==OLD_CREDIT and strn(newsec[b'STRN'])[-1]==NEW_CREDIT
        assert struct.pack('>2f',360,48) in newsec[b'DATA'][-60:]
    elif old['name'] in expected:
        opairs=xus_pairs(old['data']);npairs=xus_pairs(new['data'])
        assert [(o,n) for o,n in zip(opairs,npairs) if o!=n]==[([OLD_CREDIT,'XuiScene1.KoreanCreditText.Text'],[NEW_CREDIT,'XuiScene1.KoreanCreditText.Text'])]
        assert [v for v,k in npairs if k=='XuiScene1.KoreanCreditText.PointSize']==['26']
font=zlib.decompress((P/'payload/korean_font.bin').read_bytes());mc=struct.unpack_from('>H',font,0x88)[0];cm=struct.unpack_from('>'+str(mc+1)+'H',font,0x8a);gb=0x8a+2*(mc+1)
for c in NEW_CREDIT:assert ord(c)<=mc and cm[ord(c)]>0
adv=sum(struct.unpack_from('>h',font,gb+4+cm[ord(c)]*16+12)[0] for c in NEW_CREDIT)
assert struct.unpack_from('>f',font,0x78)[0]==58
assert adv*26/58<360
passed('only main-menu credit text appends v1.2 in XUR and two locales; all other 461 assets and layout sections identical; font-metric width fits 360px box')

# Full-size synthetic disc: real original executable and archive prefix, with
# sparse zeros elsewhere. This tests installer behavior, not game execution.
xex=(ROOT/'collectible_audit/inputs/default/default.xex').read_bytes()
px=bytearray(xex);delta=(P/'payload/xex_achievement.delta').read_bytes();at=12
for _ in range(struct.unpack_from('<I',delta,8)[0]):
    off,n=struct.unpack_from('<II',delta,at);at+=8
    px[off:off+n]=bytes(x^y for x,y in zip(px[off:off+n],delta[at:at+n]));at+=n
assert at==len(delta) and sha(px)==m['achievement_patch']['patched_sha256']
base=0xFD90000;root=base+34*2048;xa=base+64*2048
l1=base+((xa-base+len(xex)+2047)//2048)*2048;l0=l1+2048;length=l0+m['original_size']+4096
layer1=bytearray(49);struct.pack_into('>4sIIII',layer1,0,b'RATL',3,1,0,0)
desc=bytearray(2048);desc[:20]=desc[-20:]=b'MICROSOFT*XBOX*MEDIA';struct.pack_into('<II',desc,20,34,2048)
table=bytearray(2048)
for at,left,right,off,size,name in [(0,8,16,l0,m['original_size'],'Layer0.Arch00'),(32,0,0,xa,len(xex),'default.xex'),(64,0,0,l1,len(layer1),'Layer1.Arch00')]:
    nm=name.encode();struct.pack_into('<HHIIBB',table,at,left,right,(off-base)//2048,size,0,len(nm));table[at+14:at+14+len(nm)]=nm
def make_iso(path,prefix,exe):
    with path.open('wb') as f:
        f.truncate(length)
        for off,data in [(base+65536,desc),(root,table),(xa,exe),(l1,layer1),(l0,prefix),(length-128,b'KEEP-UNRELATED-TAIL')]:f.seek(off);f.write(data)
iso=T/'clean original.iso';legacy=T/'existing_Korean_v11.iso'
make_iso(iso,clean,xex);make_iso(legacy,before,px)

# Generate an independent profile with mixed earned flags, scores, timestamps,
# strings and unrelated entries; every nontext byte must survive the launcher.
texts={int(i):json.loads('['+s+']') for i,s in re.findall(r'\{(\d+)UL, new string\[\] \{(.+?)\}\}',(P/'GpdText.cs').read_text())}
assert len(texts)==50
records=[]
for i,values in sorted(texts.items()):
    header=struct.pack('>7I',28,i,10,i+100,0x10000 if i%2 else 0,0x01dc1234,i*10000)
    records.append((1,i,header+('\0'.join(values[:2])+'\0UNCHANGED-TAIL\0').encode('utf-16-be')))
records.extend([(2,123456,b'KEEP-SETTINGS'),(3,42,b'KEEP-IMAGE')])
ec=len(records)+2;fc=2;db=24+18*ec+8*fc
gpd=bytearray(db);struct.pack_into('>6I',gpd,0,0x58444246,0x10000,ec,len(records),fc,1)
for j,(sec,ident,data) in enumerate(records):
    struct.pack_into('>HQII',gpd,24+j*18,sec,ident,len(gpd)-db,len(data));gpd.extend(data)
struct.pack_into('>II',gpd,24+18*ec,len(gpd)-db,0xffffffff-(len(gpd)-db))
original_gpd=bytes(gpd);uid='B13EBABEBABEBAB0';content=T/'content';profile=content/uid/'FFFE07D1/00010000'/uid/'534507D2.gpd'
profile.parent.mkdir(parents=True,exist_ok=True);profile.write_bytes(original_gpd)
def parse_gpd(data):
    ec,eu,fc=struct.unpack_from('>3I',data,8);db=24+18*ec+8*fc;out={}
    for i in range(eu):
        sec,ident,off,n=struct.unpack_from('>HQII',data,24+i*18);out[sec,ident]=data[db+off:db+off+n]
    return out
def filehash(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
def run(label,src,out=None,extra=(),ok=True):
    cmd=[str(PW),'-NoLogo','-NoProfile','-File',str(P/'Patch.ps1'),'-IsoPath',str(src),'-ContentDirectory',str(content)]
    if out is not None:cmd+=['-OutputPath',str(out)]
    cmd+=list(extra)
    r=subprocess.run(cmd,capture_output=True,text=True,timeout=300)
    (T/(label+'.log')).write_text(r.stdout+r.stderr)
    assert (r.returncode==0)==ok,(label,r.stdout,r.stderr)
    return r.stdout+r.stderr
def unchanged_outside(left,right,spans):
    pos=0
    with left.open('rb') as a,right.open('rb') as b:
        for start,end in sorted(spans)+[(length,length)]:
            a.seek(pos);b.seek(pos);remaining=start-pos
            while remaining:
                n=min(8*1024*1024,remaining);assert a.read(n)==b.read(n);remaining-=n
            pos=end
clean_hash=filehash(iso);legacy_hash=filehash(legacy)
out1=T/'clean_Korean_v12.iso';run('clean_to_v12',iso,out1)
assert out1.stat().st_size==length
with out1.open('rb') as f:
    f.seek(l0);assert f.read(len(after))==after
    f.seek(xa);assert f.read(len(px))==px
unchanged_outside(iso,out1,[(xa,xa+len(xex)),(l0,l0+len(after))])
assert filehash(iso)==clean_hash
oldrecords=parse_gpd(original_gpd);newrecords=parse_gpd(profile.read_bytes());assert oldrecords.keys()==newrecords.keys()
for k,old in oldrecords.items():
    new=newrecords[k]
    if k[0]==1:
        assert old[:28]==new[:28]
        assert new[28:].decode('utf-16-be').split('\0')==texts[k[1]][2:]+['UNCHANGED-TAIL','']
    else:assert old==new
assert len(list(profile.parent.glob('*.bak')))==1
assert next(profile.parent.glob('*.bak')).read_bytes()==original_gpd
passed('original -> v1.2 full-size synthetic ISO; full output hash and unrelated bytes verified; 50 achievement records preserve progress')
profile_hash=filehash(profile);backups=list(profile.parent.glob('*.bak'))
run('v11_to_v12',legacy)
out2=T/'existing_Korean_v12.iso';assert out2.exists() and filehash(out1)==filehash(out2)
unchanged_outside(legacy,out2,[(l0,l0+len(after))])
assert filehash(legacy)==legacy_hash and filehash(profile)==profile_hash and list(profile.parent.glob('*.bak'))==backups
passed('v1.1 -> v1.2 produces exactly the same complete ISO as clean install; old ISO and Korean profile preserved; default filename correct')
out_hash=filehash(out2);log=run('v12_rerun',out2,out2)
assert '재생성 없이' in log and filehash(out2)==out_hash and filehash(profile)==profile_hash
passed('v1.2 rerun reuses the existing ISO; no extra ISO or profile backup')

# Concrete risks in the new upgrade path: unrecognized prefix/XEX pairing,
# damaged payload, old directory entry mismatch, overwrite and partial output.
bad=T/'wrong_build.iso';make_iso(bad,before,xex)
run('wrong_pair',bad,T/'never1.iso',ok=False);assert not (T/'never1.iso').exists()
with legacy.open('r+b') as f:f.seek(l0+300000);v=f.read(1);f.seek(l0+300000);f.write(bytes([v[0]^1]))
run('modified_v11',legacy,T/'never2.iso',ok=False)
with legacy.open('r+b') as f:f.seek(l0+300000);f.write(v)
assert not (T/'never2.iso').exists() and filehash(legacy)==legacy_hash
payload=P/'payload/common_strings.bin';raw=payload.read_bytes()
try:
    payload.write_bytes(bytes([raw[0]^1])+raw[1:])
    run('corrupt_payload',legacy,T/'never3.iso',ok=False)
finally:payload.write_bytes(raw)
assert not (T/'never3.iso').exists()
run('overwrite_rejected',legacy,out2,ok=False)
run('same_path_rejected',legacy,legacy,ok=False)
assert filehash(out2)==out_hash and filehash(legacy)==legacy_hash and filehash(profile)==profile_hash
assert not list(T.glob('*.partial-*'))
passed('wrong XEX/prefix pairs, modified old ISO, corrupt payload, existing output and same-path overwrite rejected without changing input/profile')
results.append('LIMIT: PowerShell 7.4.6/Linux; real original XEX and 8 MiB archive prefix in synthetic ISO; Windows dialogs and game icon rendering not run')
(T/'test_results_v12.txt').write_text('\n'.join(results)+'\n')
(T/'test_summary_v12.json').write_text(json.dumps(dict(passed=len(results)-1,runtime_game_display_verified=False,iso_size=length,output_sha256=out_hash,changed_slots=18,resource_offsets_unchanged=1318),indent=2)+'\n')
