from pathlib import Path
import hashlib, json, shutil, zipfile
from build_v12 import ROOT, BASE, PKG, OUT, WORK
sha=lambda b:hashlib.sha256(b).hexdigest()
summary=json.loads((WORK/'tests_final/test_summary_v12.json').read_text())
assert summary['passed']==8 and summary['runtime_game_display_verified'] is False
for f in PKG.glob('patch_result_*.json'):f.unlink()
for name in ['patch_error.txt']:
    if (PKG/name).exists():(PKG/name).unlink()
readme='''컨뎀드: 크리미널 오리진 Xbox 360 / Xenia 한글 패치 v1.2
한글화: 슬림쉐이디
2026-11-01

이번 변경
테이저·손전등·공격·방어 등 조작 안내 18개 문구에서 빠졌던 원본 버튼 표시 코드를 복원했습니다.
버튼 그림과 함께 나오는 설명은 한글입니다. 원본에 버튼 표시가 없는 일반 목표 안내는 그대로입니다.
메인화면의 크레딧에 '한글화: 슬림쉐이디  v1.2'를 표시합니다.
그 외 v1.1의 나머지 번역·폰트·UI·도전 과제·신발자국 분석 대사는 그대로 포함합니다.
Xenia의 Dummy HDD 이름과 Xenia 실행파일·설정·저장 경로는 변경하지 않습니다.
버튼 코드 복원과 적용 결과는 데이터로 검사했습니다. 실제 게임의 아이콘 표시 확인은 아직 필요합니다.

설치 방법
1. ZIP 전체를 압축 해제합니다. data 폴더도 함께 유지하세요.
2. 게임과 Xenia를 완전히 종료합니다.
3. RUN_PATCH.bat 하나만 실행합니다.
4. 지원되는 원본 ISO 또는 기존 v1.1 한글 ISO를 선택합니다.
5. 이어지는 창에서 사용 중인 Xenia 폴더 또는 실제 content 폴더를 선택합니다.
6. 완료 메시지에 표시된 ISO를 Xenia에서 실행합니다. 콘솔 언어는 English 또는 Korean입니다.

출력 위치와 기존 패치
원본 또는 v1.1 ISO와 같은 폴더에 이름_Korean_v12.iso를 새로 만듭니다.
예: Condemned_Korean_v11.iso 선택 → Condemned_Korean_v12.iso 생성.
선택한 원본/기존 한글 ISO는 보존합니다. 새 ISO 한 개 크기 이상의 여유 공간이 필요합니다.
같은 이름의 출력 파일이 있으면 덮어쓰지 않고 중단합니다.
이미 v1.2인 ISO를 선택하면 해시 확인 후 재생성하지 않습니다.
v1.1은 구 v0.11과 같은 배포본입니다. 같은 게임 데이터의 v0.10 ISO도 해시가 맞으면 갱신됩니다.
v0.9 이하 또는 다른 수정이 들어간 ISO는 지원되는 원본 ISO에서 새로 적용하세요.
기존 메뉴·대사·도전 과제 번역을 포함한 통합 패치이므로 이전 버전을 먼저 적용할 필요가 없습니다.

기존 도전 과제 기록
ISO와 기존 도전 과제 설명을 같은 실행에서 처리합니다. 보조 실행 파일을 따로 실행할 필요가 없습니다.
이미 한글인 프로필은 다시 수정하거나 백업하지 않습니다.
영어 기록이 있는 경우, 기존 방식대로 제목·설명만 갱신하고 획득 여부·점수·획득 시각을 보존하며 백업합니다.
이미 게임을 실행했는데 기록이 없다고 나오면 '아니요'를 눌러 실제 content 폴더를 다시 선택하세요.
처음 실행하는 환경이거나 GPD 기록을 쓰지 않는 구버전인 경우에만 '예'로 기존 기록 없이 진행합니다.
프로필 처리에 실패했으면 오류를 해결하고 같은 RUN_PATCH.bat로 준비된 ISO를 선택해 다시 진행하세요.
세이브나 프로필을 삭제할 필요가 없습니다.

확인하기 좋은 곳
1장 테이저 사용법, 손전등, 공격·방어 안내에서 버튼 그림과 한글 설명을 함께 확인하세요.
사진으로 제보된 '도끼로 문을 부숴라.'는 원본부터 버튼 코드가 없는 문구라 변경하지 않았습니다.
문제가 있으면 버튼이 필요한 힌트의 화면, 장면, Xenia 버전을 알려 주세요.

원복
보존한 v1.1 ISO 또는 원본 ISO를 실행하면 됩니다.
도전 과제 설명만 영어로 복원하려면 명령 프롬프트에서 RUN_PATCH.bat -Mode RestoreText를 실행하세요.
오래된 GPD 백업을 직접 덮어쓰면 그 뒤의 기록을 잃을 수 있으므로 설명 복원 기능을 사용하세요.

검수 범위
실제 제공된 원본 default.xex와 Layer0 앞 8MiB를 포함한 합성 ISO로 새 설치·v1.1 갱신·재실행·오류 거부를 시험했습니다.
PowerShell 7.4.6/Linux에서 실행했으며 Windows 선택 창·실제 v1.2 게임 화면·엔딩까지 전체 플레이는 미확인입니다.
자세한 결과는 QA_KR.txt, 정확한 18개 변경은 source/hint_changes_v12.json에 있습니다.
원본 게임 ISO·실행파일은 포함하지 않습니다. Xenia용이며 Xbox 360 실기 구동은 검증하지 않았습니다.
'''
(PKG/'README_KR.txt').write_text(readme,encoding='utf-8-sig')
qa='''컨뎀드 v1.2 검수 기록 — 2026-11-01

변경 범위
- 게임 문자열 3,012개 중 승인된 조작 안내 18개 슬롯만 변경. 이 슬롯을 참조하는 힌트 키는 20개입니다.
- 각 문구에 원본의 입력 코드(action, flashlight, tools, fire, ammocheck, togglemelee, sprint, taser, kick, block, pause, aim, move)를 그대로 복원.
- 설명은 한글로 유지. 일반 도끼 안내와 신발자국 분석 대사를 포함한 나머지 문자열은 바이트 단위로 보존.
- 4,976개 내부 키·참조, 모든 문자열 시작 위치·종결 위치·슬롯 길이를 v1.1 그대로 보존.
- 게임 전체 원본 문자열의 입력/페이지/시간 코드와 새 번역의 코드 목록을 슬롯별 대조하여 일치 확인.
- 압축 방식을 조정하여 기존 문자열 저장 공간 안에 수용. 1,318개 리소스의 위치가 모두 v1.1과 동일.
- 메인화면의 크레딧 문자열에만 '  v1.2'를 추가. frontEndMenu.xur와 영어/한국어 frontEndMenu.xus에서 같은 문구를 갱신.
- XUR의 화면 구성·좌표·색상·폰트 크기 등 DATA/VECT/QUAT/DBUG 섹션 보존. 464개 UI 리소스 중 나머지 461개는 바이트 단위로 동일.
- 크레딧은 기존 26포인트/360픽셀 폭을 유지. 실제 폰트 메트릭 계산상 새 문구의 폭 약 225픽셀로 영역 안에 들어감.
- Layer0 첫 8MiB에서 변경 허용 범위는 공용/영어 문자열과 UI 압축 데이터 및 해당 디렉터리 크기 항목뿐.
- 기존 폰트·XEX 도전 과제 차분·도전 과제 번역·프로필 처리 코드는 v1.1과 완전히 동일.
- Xenia 실행파일/설정/HDD명은 변경하지 않음.

패치 프로그램 변경
- v1.2 표기와 출력 이름 갱신.
- 원본 설치와 해시가 일치하는 v1.1(구 v0.10/0.11 데이터) 갱신을 지원. 입력 ISO는 읽기 전용으로 열고 별도 ISO 생성.
- 기존 v1.2 ISO는 재생성 없이 재사용. 같은 출력 이름이 있으면 덮어쓰기 거부.
- RUN_PATCH.bat 단일 진입점과 기존 도전 과제 처리 흐름 유지.

실행 시험
- 실제 원본 실행파일·아카이브 앞 8MiB를 넣은 합성 ISO의 원본→v1.2, v1.1→v1.2 적용.
- 두 경로의 결과 ISO 전체 SHA-256 일치, 원본 보존, 수정 범위 밖 바이트 일치.
- v1.1 갱신에서는 실행파일 전체가 그대로이며 힌트 문자열과 크레딧 버전 표시만 달라짐.
- 50개 도전 과제의 혼합 획득 상태·점수·시각이 있는 합성 프로필로 기존 통합 실행 확인.
- 이미 한글인 프로필은 변경·추가 백업 없음. v1.2 재실행은 ISO도 변경하지 않음.
- 잘못된 실행파일/아카이브 조합, 변조된 기존 ISO, 손상된 패치 데이터, 같은 경로/기존 출력 덮어쓰기를 변경 전에 거부.

한계
시험 환경은 PowerShell 7.4.6/Linux입니다. 합성 ISO는 설치 검증용으로 게임 전체 데이터가 아닙니다.
Windows 파일 선택 창, 실제 v1.2의 버튼 그림·메인화면 버전 표시 및 게임 전체 완주는 아직 확인하지 않았습니다.
따라서 버튼 코드 복원 완료와 실제 화면 표시 확인을 구분합니다. 실제 게임 화면 확인은 필요합니다.
2026-11-01 사용자 확인: 기존 v1.1에서 금속 조각을 실제로 찾았다고 보고했습니다. 전체 수집물 검증을 뜻하지 않습니다.

이전 기록
source/unified_test_results.txt, source/profile_edge_results.txt 및 source/previous_data_QA_v10.txt는 이전 v0.11/v0.10 검수 이력입니다.
이번 결과는 source/test_results_v12.txt와 source/test_summary_v12.json을 기준으로 보세요.
'''
(PKG/'QA_KR.txt').write_text(qa,encoding='utf-8-sig')
(OUT/'Condemned_v12_Changes_QA_20261101.txt').write_text(qa,encoding='utf-8-sig')
for name in ['build_v12.py','credit_v12.py','test_v12.py','finalize_v12.py']:
    shutil.copyfile(WORK/name,PKG/'source'/name)
for name in ['test_results_v12.txt','test_summary_v12.json']:
    shutil.copyfile(WORK/'tests_final'/name,PKG/'source'/name)
checks=[]
for f in sorted(PKG.rglob('*')):
    if f.is_file() and f.name!='SHA256SUMS.txt':checks.append(sha(f.read_bytes())+'  '+f.relative_to(PKG).as_posix())
(PKG/'SHA256SUMS.txt').write_text('\n'.join(checks)+'\n')
zp=OUT/'Condemned_Korean_ISO_v12.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(PKG.rglob('*')):
        if f.is_file():z.write(f,f.relative_to(OUT))
with zipfile.ZipFile(zp) as z:
    assert z.testzip() is None
    assert len([n for n in z.namelist() if n.endswith('.bat')])==1
    assert not any(n.lower().endswith(('.xex','.iso','.gpd')) for n in z.namelist())
    assert not any('patch_result_' in n or n.endswith('patch_error.txt') for n in z.namelist())
    for line in checks:
        digest,name=line.split('  ',1);assert sha(z.read(PKG.name+'/'+name))==digest
b=zp.read_bytes();digest=sha(b)
(OUT/'SHA256SUMS_v12.txt').write_text(digest+'  '+zp.name+'\n')
repo='https://github.com/slimshadykor-cmd/condemned-korean-patch-'
body=f'''# Condemned: Criminal Origins 한글 패치

**한글화: 슬림쉐이디**  
Xbox 360판 / Xenia용 · **v1.2 ISO 통합 패치** · 2026-11-01

**테이저·손전등·공격·방어 등 조작 안내 18개 문구의 원본 버튼 표시 코드를 복원했습니다. 설명은 한글로 유지합니다.**

## 다운로드

**[ISO용 v1.2 다운로드]({repo}/raw/refs/heads/main/{zp.name})** · {len(b):,}바이트

기존 번역과 도전 과제 50개의 제목·설명을 포함한 통합판입니다. 이전 패치를 먼저 적용할 필요가 없습니다.

## v1.2 변경 사항

- 버튼 안내를 '테이저 버튼' 같은 글자로 바꾸면서 빠졌던 입력 코드를 18개 문구에 복원했습니다.
- 게임이 원래 버튼 표시를 넣는 부분을 한글 문장 안에 유지했습니다. 버튼이 없는 일반 목표 안내는 그대로입니다.
- 메인화면 크레딧을 **한글화: 슬림쉐이디  v1.2**로 표시합니다.
- 다른 번역·폰트·UI 구성·실행파일 차분·도전 과제·신발자국 분석 대사는 v1.1과 같습니다.
- 원본 ISO와 기존 v1.1 한글 ISO에서 모두 v1.2 ISO를 만들 수 있습니다.

**버튼 코드와 패치 결과는 데이터 검사를 마쳤습니다. 실제 v1.2 게임 화면에서 버튼 그림이 표시되는지는 아직 확인이 필요합니다.**

## 설치

1. ZIP 전체를 압축 해제합니다. `data` 폴더도 함께 유지하세요.
2. 게임과 Xenia를 종료하고 **RUN_PATCH.bat** 하나를 실행합니다.
3. **지원되는 원본 ISO 또는 기존 v1.1 한글 ISO**를 선택합니다.
4. 이어지는 창에서 사용 중인 **Xenia 폴더 또는 실제 content 폴더**를 선택합니다.
5. 완료 메시지에 표시된 ISO를 Xenia에서 실행합니다. 콘솔 언어는 English 또는 Korean입니다.

입력 ISO와 같은 폴더에 `이름_Korean_v12.iso`를 새로 만듭니다. 예를 들어 `Condemned_Korean_v11.iso`를 선택하면 `Condemned_Korean_v12.iso`가 생성됩니다. 입력 ISO는 보존하며 새 ISO 한 개 크기 이상의 공간이 필요합니다.

같은 이름의 출력 파일이 있으면 덮어쓰지 않습니다. 이미 v1.2인 ISO를 선택하면 해시 확인 후 재사용합니다.

v1.1은 구 v0.11과 같은 배포본입니다. 같은 게임 데이터의 v0.10도 해시가 일치하면 갱신됩니다. v0.9 이하 또는 다른 수정이 들어간 ISO는 지원되는 원본 ISO에서 새로 적용하세요.

## 기존 도전 과제와 저장 기록

ISO와 기존 도전 과제 설명을 한 번 실행으로 처리합니다. 보조 실행 파일을 따로 실행할 필요가 없습니다. 이미 한글인 프로필은 수정하거나 추가 백업하지 않습니다.

영어 설명이 있는 프로필은 기존 방식대로 제목·설명만 갱신하며 획득 여부·시각·점수와 다른 항목은 보존하고 자동 백업합니다. 이미 게임을 실행했는데 기록이 없다고 나오면 **아니요**를 눌러 실제 `content` 폴더를 다시 선택하세요. 처음 실행하거나 GPD 기록을 쓰지 않는 구버전인 경우에만 기존 기록 없이 진행합니다.

프로필 처리에 실패했다면 오류를 해결하고 같은 `RUN_PATCH.bat`로 준비된 ISO를 선택해 다시 진행하세요. 세이브나 프로필을 삭제할 필요가 없습니다. Xenia 실행파일·설정·저장 장치 이름은 이 패치에서 변경하지 않습니다.

## 검수 범위

게임 문자열은 정확히 18개 슬롯만 바뀌었으며 4,976개 내부 키, 모든 문자열 위치와 1,318개 리소스 위치를 보존했습니다. UI는 크레딧 버전 문구만 바꾸고 화면 구성과 좌표를 유지했습니다. 나머지 폰트·UI 리소스·실행파일 차분은 v1.1과 바이트 단위로 같습니다.

실제 원본 실행파일과 아카이브 앞 8MiB를 넣은 합성 ISO로 원본 설치·v1.1 갱신·재실행을 PowerShell 7.4.6/Linux에서 시험했습니다. 두 설치 경로의 결과 ISO 전체 해시가 같고, 입력 ISO 보존·프로필 획득 기록 보존·오류 거부를 확인했습니다.

**Windows 선택 창, 실제 v1.2 게임의 버튼·버전 표시 및 엔딩까지 전체 플레이 검수는 완료하지 않았습니다.** 상세 내용은 [v1.2 검수 기록](Condemned_v12_Changes_QA_20261101.txt)과 ZIP 안의 `QA_KR.txt`를 참고하세요.

이전 사용자 확인: 2026-10-09 도전 과제 한글 표시, 2026-11-01 금속 조각 발견이 보고되었습니다. 확인한 화면과 장면에 한정되며 전체 게임 검증을 뜻하지 않습니다.

## 문제 제보

1장의 테이저·손전등·공격·방어 안내에서 버튼 그림과 한글 설명을 함께 확인해 주세요. [Issues]({repo}/issues)에 화면, 챕터·장면, 패치 버전과 Xenia 버전을 남겨 주세요. 설치 오류는 `patch_error.txt` 또는 결과 창을 알려 주세요.

## 파일 확인과 이전 다운로드 주소

[SHA256SUMS_v12.txt](SHA256SUMS_v12.txt)

```text
{digest}  {zp.name}
```

**이전에 공유한 main 브랜치 ZIP 주소(v07·v08·v09·v10·v11)도 최신 v1.2 내용으로 교체했습니다.** 주소에 옛 버전명이 남아 있어도 압축 안의 폴더·안내문·패치 프로그램은 v1.2입니다. 이전 파일을 이미 내려받았다면 새로 다운로드해 주세요.

[이전 v1.1 릴리스 안내]({repo}/releases/tag/v1.1)에서도 최신 다운로드를 안내합니다. 과거 Git 커밋·태그의 스냅샷은 변경하지 않습니다.

신규 다운로드는 v1.2를 사용하세요. 원본 게임 ISO·실행파일은 포함하지 않으며 Xenia용 패치만 배포합니다.
'''
(OUT/'README.md').write_text(body)
for ver in ['07','08','09','10','11']:
    (OUT/f'SHA256SUMS_v{ver}.txt').write_text(digest+f'  Condemned_Korean_ISO_v{ver}.zip\n')
release=dict(filename=zp.name,size=len(b),sha256=digest,git_blob_sha1=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),prefix_sha256=json.loads((PKG/'data/iso_manifest.json').read_text())['patched_prefix_sha256'],test_summary=summary)
(WORK/'release_v12.json').write_text(json.dumps(release,indent=2)+'\n')
print(json.dumps(release,ensure_ascii=False))
