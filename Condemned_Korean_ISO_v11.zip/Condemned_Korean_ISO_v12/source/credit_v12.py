import struct,zlib

OLD_CREDIT='한글화: 슬림쉐이디'
NEW_CREDIT=OLD_CREDIT+'  v1.2'

def asset_rows(raw):
    assert raw[:4]==b'XUIZ' and struct.unpack_from('>I',raw,8)[0]==len(raw)
    base=22+struct.unpack_from('>I',raw,16)[0]
    count=struct.unpack_from('>H',raw,20)[0];p=22;rows=[]
    for _ in range(count):
        size,off,n=struct.unpack_from('>IIB',raw,p)
        name=raw[p+9:p+9+n*2].decode('utf-16-be')
        rows.append(dict(name=name,table=p,offset=base+off,size=size))
        p+=9+2*n
    assert p==base
    for i,r in enumerate(rows):
        end=rows[i+1]['offset'] if i+1<len(rows) else len(raw)
        r['data']=raw[r['offset']:r['offset']+r['size']]
        r['trailer']=raw[r['offset']+r['size']:end]
        assert len(r['trailer'])==10+struct.unpack_from('>H',r['trailer'],8)[0]*2
    return base,rows

def xur_sections(raw):
    assert raw[:8]==b'XUIB\0\0\0\5' and struct.unpack_from('>I',raw,14)[0]==len(raw)
    n=struct.unpack_from('>H',raw,18)[0];end=20+n*12;result=[]
    for i in range(n):
        tag,off,size=struct.unpack_from('>4sII',raw,20+i*12)
        assert off==end and off+size<=len(raw)
        result.append((tag,raw[off:off+size]));end+=size
    assert end==len(raw)
    return result

def strn(raw):
    p=0;out=[]
    while p<len(raw):
        n=struct.unpack_from('>H',raw,p)[0];p+=2
        out.append(raw[p:p+2*n].decode('utf-16-be'));p+=2*n
    assert p==len(raw)
    return out

def xus_pairs(raw):
    assert raw[:6]==b'XUIS\1\0' and struct.unpack_from('>I',raw,6)[0]==len(raw)
    count=struct.unpack_from('>H',raw,10)[0];p=12;out=[]
    for _ in range(count):
        pair=[]
        for _ in range(2):
            n=struct.unpack_from('>H',raw,p)[0];p+=2
            pair.append(raw[p:p+2*n].decode('utf-16-be'));p+=2*n
        out.append(pair)
    assert p==len(raw)
    return out

def patch_xus(raw):
    rows=xus_pairs(raw);matches=0;output=bytearray(raw[:12])
    for value,key in rows:
        if key=='XuiScene1.KoreanCreditText.Text':
            assert value==OLD_CREDIT;value=NEW_CREDIT;matches+=1
        for s in [value,key]:output+=struct.pack('>H',len(s))+s.encode('utf-16-be')
    assert matches==1
    struct.pack_into('>I',output,6,len(output))
    assert [(a,b) for a,b in zip(rows,xus_pairs(output)) if a!=b]==[([OLD_CREDIT,'XuiScene1.KoreanCreditText.Text'],[NEW_CREDIT,'XuiScene1.KoreanCreditText.Text'])]
    return bytes(output)

def patch_xur(raw):
    sections=xur_sections(raw);oldstrings=strn(dict(sections)[b'STRN'])
    assert oldstrings[-1]==OLD_CREDIT and oldstrings.count(OLD_CREDIT)==1
    out=bytearray(raw[:20+12*len(sections)])
    for i,(tag,data) in enumerate(sections):
        if tag==b'STRN':
            tail=struct.pack('>H',len(OLD_CREDIT))+OLD_CREDIT.encode('utf-16-be')
            assert data.endswith(tail)
            data=data[:-len(tail)]+struct.pack('>H',len(NEW_CREDIT))+NEW_CREDIT.encode('utf-16-be')
        struct.pack_into('>4sII',out,20+i*12,tag,len(out),len(data));out+=data
    struct.pack_into('>I',out,14,len(out))
    newsections=xur_sections(out)
    for (tag,a),(newtag,b) in zip(sections,newsections):
        assert tag==newtag
        if tag!=b'STRN':assert a==b
    assert strn(dict(newsections)[b'STRN'])==oldstrings[:-1]+[NEW_CREDIT]
    return bytes(out)

def build_credit(raw):
    base,rows=asset_rows(raw);out=bytearray(raw[:base]);changed=[]
    for r in rows:
        data=r['data']
        if r['name']=='frontEndMenu.xur':data=patch_xur(data)
        elif r['name'] in ['en-US\\frontEndMenu.xus','ko-kR\\frontEndMenu.xus']:data=patch_xus(data)
        if data!=r['data']:changed.append(r['name'])
        struct.pack_into('>II',out,r['table'],len(data),len(out)-base)
        out+=data+r['trailer']
    struct.pack_into('>I',out,8,len(out))
    _,newrows=asset_rows(out)
    assert len(rows)==len(newrows)==464
    assert set(changed)=={'frontEndMenu.xur','en-US\\frontEndMenu.xus','ko-kR\\frontEndMenu.xus'}
    for a,b in zip(rows,newrows):
        assert a['name']==b['name'] and a['trailer']==b['trailer']
        if a['name'] not in changed:assert a['data']==b['data']
    return bytes(out),changed
