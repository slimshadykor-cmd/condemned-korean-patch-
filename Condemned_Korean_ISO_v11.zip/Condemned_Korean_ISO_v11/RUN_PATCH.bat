@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0data\Patch.ps1" %*
set "patch_result=%errorlevel%"
echo.
pause
exit /b %patch_result%
