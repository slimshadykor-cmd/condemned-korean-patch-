from pathlib import Path
import json,hashlib,shutil,zipfile
W=Path(__file__).resolve().parent.parent;B=W/'v11_build';P=B/'Condemned_Korean_ISO_v11';R=W/'v11_work';old=W/'v10_build/Condemned_Korean_ISO_v10'
sha=lambda b:hashlib.sha256(b).hexdigest()
for f in (old/'payload').iterdir():assert (P/'data/payload'/f.name).read_bytes()==f.read_bytes()
for n in ['XexPatch.cs','GpdText.cs','achievement_translations.json','xex_patch.json']:assert (P/'data'/n).read_bytes()==(old/n).read_bytes()
assert [p.name for p in P.glob('*.bat')]==['RUN_PATCH.bat']
readme='''컨뎀드: 크리미널 오리진 Xbox 360 / Xenia 한글 패치 v0.11
한글화: 슬림쉐이디

RUN_PATCH.bat 하나만 실행하세요.
ISO 패치와 기존 도전 과제 설명 갱신을 같은 실행에서 처리합니다.
별도의 RUN_ACHIEVEMENT_TEXT.bat를 실행할 필요가 없습니다.

설치 방법
1. ZIP 전체를 압축 해제합니다. data 폴더를 함께 유지하세요.
2. 게임과 Xenia를 완전히 종료합니다.
3. RUN_PATCH.bat를 실행합니다.
4. 원본 ISO 또는 이미 만든 v0.10 / v0.11 한글 ISO를 선택합니다.
5. 같은 실행에서 나오는 선택 창에서 사용 중인 Xenia 폴더 또는 content 폴더를 선택합니다.
6. ISO와 도전 과제 설명 처리가 모두 완료되었다는 메시지를 확인합니다.
7. 화면에 표시된 ISO를 Xenia에서 실행합니다. 콘솔 언어는 English 또는 Korean입니다.

이미 v0.10 ISO를 만들어 두셨나요?
그 ISO를 그대로 선택하세요. 번역 리소스와 실행파일 메타데이터의 해시를 검사한 뒤 ISO를 재생성하지 않고 기존 프로필 설명을 갱신합니다.
v0.11의 번역 데이터는 v0.10과 동일합니다. 이번 변경은 두 설치 과정을 한 실행으로 묶은 것입니다.
v0.9 이하 패치 ISO는 원본 ISO에서 새로 만들어야 합니다.

기존 도전 과제 기록을 찾지 못한 경우
이미 영어 설명이 보였던 환경이면 '아니요'를 눌러 실제 사용 중인 content 폴더를 다시 선택하세요.
처음 실행하는 환경이거나 GPD 기록을 쓰지 않는 구버전인 경우에만 기록 없이 진행하는 '예'를 선택합니다.
기록을 찾지 못했다고 번역 완료로 표시하지 않습니다.
Xenia를 여러 곳에 설치했거나 저장 경로를 바꿨다면 현재 게임에서 사용하는 content 폴더를 선택해야 합니다.
설정의 content_root/storage_root 경로를 확인하지만 별도 실행 옵션으로 지정한 경로까지 추측하지 않습니다.

기록 보존 및 재실행
선택한 content 폴더의 활성 프로필들에서 컨뎀드 도전 과제 제목·설명만 교체합니다.
획득 여부·획득 시각·점수·다른 프로필 데이터는 보존합니다. 실제 변경 전 각 GPD 옆에 .before_text_v11...bak 백업을 만듭니다.
이미 한글이면 중복으로 수정하거나 백업하지 않습니다. 세이브와 원본 ISO는 수정하지 않습니다.
프로필 검사 실패 시 ISO 생성 전에 중단합니다. ISO 생성 도중 프로필이 바뀌면 그 변경을 덮어쓰지 않고 중단합니다.
ISO가 준비된 뒤 프로필 갱신이 실패했다면 원인을 해결한 뒤 같은 RUN_PATCH.bat를 실행해 준비된 ISO를 선택하면 됩니다.
여러 프로필 중 교체가 실패하면 앞서 바꾼 프로필을 복구합니다. 전원 차단 등으로 중단되면 .bak 파일을 보존한 채 오류를 제보하세요.

원복
게임을 원본으로 실행하려면 보존한 원본 ISO를 사용하세요.
도전 과제 설명만 영어로 복원할 필요가 있으면 명령 프롬프트에서 같은 실행 파일에 옵션을 붙입니다:
RUN_PATCH.bat -Mode RestoreText
현재 획득 기록을 유지하면서 설명만 복원합니다. 오래된 GPD 백업을 직접 덮어쓰면 그 이후의 기록이 사라질 수 있습니다.

검수 범위
실제 제공된 원본 실행파일과 아카이브 앞 8MiB를 포함한 합성 ISO, 획득 기록이 섞인 합성 프로필로 통합 실행·재실행·기록 보존·실패 복구를 검사했습니다.
시험 환경은 PowerShell 7.4.6 / Linux입니다. Windows 선택 창과 실제 게임 화면의 표시, 엔딩까지 전체 플레이는 아직 확인하지 않았습니다.
자세한 결과는 QA_KR.txt와 source/의 시험 기록에 있습니다.
원본 게임 ISO·실행파일은 포함하지 않습니다. Xenia용이며 Xbox 360 실기 사용은 검증하지 않았습니다.
'''
(P/'README_KR.txt').write_text(readme,encoding='utf-8-sig')
qa='''v0.11 검증 기록 — 2026-10-09

변경: RUN_PATCH.bat 한 번으로 ISO 준비와 기존 Xenia 프로필 도전 과제 설명 갱신을 연결했습니다.
번역 데이터·폰트·UI·실행파일 차분 및 GPD 문자열 변환 코드는 v0.10과 바이트 단위로 같습니다.
도전 과제 50개 제목·50개 설명 번역을 포함한 통합판입니다. 일반 대사와 신발자국 분석 대사는 변경하지 않았습니다.

시험한 주요 동작
- 원본 ISO 선택 → 한글 ISO 생성 → 활성 프로필 두 개의 설명 갱신까지 하나의 진입점에서 완료.
- 생성 ISO 전체 크기·수정 대상 해시 검사. 수정 범위 밖 전체 바이트와 원본 ISO 보존 확인.
- 도전 과제 ID·점수·획득 플래그·시각·기타 프로필 항목 보존과 백업 원본 일치 확인.
- 기존 v0.10/0.11 데이터의 ISO를 그대로 재사용하며 파일 전체 해시가 바뀌지 않음.
- 이미 한글인 프로필 재실행 시 수정·중복 백업 없음.
- 지원하지 않는 프로필 및 잘못된 ISO는 파일 변경 전에 거부.
- 프로필 0개이면 기본 중단. 신규 환경으로 명시한 경우만 진행하며 설명 갱신 완료로 표시하지 않음.
- 선택한 content 안에서도 활성 프로필 경로만 처리하고 별도 백업 폴더는 무시.
- 두 번째 프로필 교체 실패를 주입해 첫 번째 프로필의 원본 복구 확인.
- 사전 검사 이후 프로필이 바뀌면 다른 프로필까지 수정하기 전에 중단, 새 외부 기록 보존.
- 기본·별도 content_root·storage_root 경로 및 따옴표 표현 검사. 설정이 충돌하면 직접 content 선택을 요구.
- 최종 ZIP 무결성 및 파일별 SHA-256 확인. 실행용 BAT는 RUN_PATCH.bat 하나입니다.

시험 자료: 실제 제공된 원본 default.xex와 Layer0 첫 8MiB, 나머지는 전체 크기의 합성 ISO.
프로필 시험 자료: 공식 Xenia 구조에 맞춘 합성 GPD. 실제 사용자 프로필은 제공받지 않았습니다.
환경: PowerShell 7.4.6 / Linux. Windows 선택 창·실제 게임 실행 및 화면 표시·전체 완주는 미확인입니다.
따라서 데이터 검증을 모든 화면 번역 완료나 모든 환경의 무튕김 보장으로 해석하면 안 됩니다.

참조
Xenia Canary GPD 및 프로필 구조: https://github.com/xenia-canary/xenia-canary/tree/canary_experimental/src/xenia/kernel/xam
Xenia 저장 위치 안내: https://github.com/xenia-canary/xenia-canary/wiki/FAQ
'''
(P/'QA_KR.txt').write_text(qa,encoding='utf-8-sig')
source=P/'source';source.mkdir(exist_ok=True)
for n in ['prepare_engine.py','test_unified.py','test_profile_edges.ps1','finalize_v11.py']:shutil.copyfile(R/n,source/n)
for src,n in [(Path('/tmp/condemned-v11-final/test_results.txt'),'unified_test_results.txt'),(Path('/tmp/condemned-v11-edges/results.txt'),'profile_edge_results.txt')]:shutil.copyfile(src,source/n)
(P/'source/previous_data_QA_v10.txt').write_bytes((old/'QA_KR.txt').read_bytes())
checks=[]
for f in sorted(P.rglob('*')):
 if f.is_file() and f.name!='SHA256SUMS.txt':checks.append(sha(f.read_bytes())+'  '+f.relative_to(P).as_posix())
(P/'SHA256SUMS.txt').write_text('\n'.join(checks)+'\n')
zpath=B/(P.name+'.zip')
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in sorted(P.rglob('*')):
  if f.is_file():z.write(f,f.relative_to(B))
with zipfile.ZipFile(zpath) as z:
 assert z.testzip() is None
 assert len([n for n in z.namelist() if n.endswith('.bat')])==1
 assert not any(n.lower().endswith('.xex') for n in z.namelist())
 for r in checks:
  h,name=r.split('  ',1);assert sha(z.read(P.name+'/'+name))==h
zbytes=zpath.read_bytes();release={'name':zpath.name,'size':len(zbytes),'sha256':sha(zbytes),'git_blob_sha1':hashlib.sha1(b'blob '+str(len(zbytes)).encode()+b'\0'+zbytes).hexdigest()}
(B/'release_validation_v11.json').write_text(json.dumps(release,indent=2)+'\n');(B/'SHA256SUMS_v11.txt').write_text(release['sha256']+'  '+release['name']+'\n')
(B/'Condemned_v11_Changes_QA_20261009.txt').write_text(qa,encoding='utf-8-sig')
repo='https://github.com/slimshadykor-cmd/condemned-korean-patch-'
github='''# Condemned: Criminal Origins 한글 패치

**한글화: 슬림쉐이디**  
Xbox 360판 / Xenia용 · **v0.11 한 번 실행하는 ISO 통합 패치** · 2026-10-09

**RUN_PATCH.bat 하나로 ISO 패치와 기존 도전 과제 설명 갱신까지 처리합니다.** 이전처럼 보조 BAT를 따로 실행할 필요가 없습니다.

## 다운로드

'''+f'**[ISO용 v0.11 다운로드]({repo}/raw/refs/heads/main/{zpath.name})** · {len(zbytes):,}바이트\n\n'+'''이전 번역과 수정 사항을 포함한 통합판입니다. 도전 과제 50개의 제목·설명 100개 번역도 포함합니다. 번역 데이터는 v0.10과 같으며, v0.11에서 설치 과정을 통합했습니다.

## 설치

1. ZIP 전체를 압축 해제합니다. `data` 폴더도 함께 유지하세요.
2. 게임과 Xenia를 완전히 종료하고 **RUN_PATCH.bat**를 실행합니다.
3. **원본 ISO 또는 이미 만든 v0.10 / v0.11 한글 ISO**를 선택합니다.
4. 이어서 나오는 창에서 사용 중인 **Xenia 폴더 또는 content 폴더**를 선택합니다.
5. ISO와 도전 과제 설명 처리가 모두 완료됐다는 메시지를 확인합니다.
6. 화면에 안내된 ISO를 Xenia에서 실행합니다. 콘솔 언어는 English 또는 Korean으로 설정합니다.

**이미 v0.10 ISO가 있으면 그 파일을 선택하시면 됩니다.** 해시를 확인한 뒤 ISO를 재생성하지 않고 기존 프로필 설명을 갱신합니다. v0.9 이하 ISO는 원본에서 새로 만들어야 합니다.

원본 ISO는 보존됩니다. 새 ISO 생성 시 ISO 한 개 크기 이상의 여유 공간이 필요합니다.

## 기존 기록을 찾지 못했다면

이미 게임에서 영어 도전 과제 설명을 보셨다면, 기록 없음 안내에서 **아니요**를 눌러 실제 사용하는 `content` 폴더를 다시 선택하세요. 처음 실행하거나 GPD를 사용하지 않는 구버전인 경우에만 기존 기록 없이 진행합니다.

패치가 기록을 찾지 못한 상태를 설명 갱신 완료로 표시하지 않습니다. Xenia를 여러 위치에 설치했거나 저장 경로를 바꿨다면 현재 게임에서 쓰는 폴더를 선택해야 합니다.

## 기록 보존·재시도

선택한 content 폴더의 활성 프로필에서 컨뎀드의 제목·설명만 교체하고, 획득 여부·시각·점수와 다른 항목을 보존합니다. 실제 변경 전 자동 백업을 남깁니다. 이미 한글이면 다시 수정하지 않습니다.

프로필 처리에 실패하면 전체 완료로 표시하지 않습니다. ISO가 준비된 뒤 실패한 경우, 원인을 해결하고 **같은 RUN_PATCH.bat**를 실행해 준비된 ISO를 선택하면 이어서 처리할 수 있습니다. 세이브나 프로필을 삭제할 필요가 없습니다.

## 검수 범위

제공된 원본 실행파일과 아카이브 첫 8MiB를 넣은 합성 ISO, 획득 기록이 섞인 합성 프로필로 통합 설치·기존 ISO 재사용·기록 보존·실패 시 복구를 실제 PowerShell/C# 런타임에서 시험했습니다. v0.10의 번역 데이터·폰트·UI와 신발자국 분석 대사는 그대로입니다.

**Windows 선택 창과 실제 v0.11 게임 화면·사용자 프로필·엔딩까지 전체 플레이는 아직 확인하지 않았습니다.** 데이터 검사가 게임 전체의 미번역 0개나 모든 환경의 무튕김을 보장하지는 않습니다. 자세한 결과는 ZIP 안의 `QA_KR.txt`에 있습니다.

## 문제 제보

[Issues]('''+repo+'''/issues)에 화면, 챕터·장면, 패치 버전과 Xenia 버전을 함께 남겨 주세요. 설치 오류는 `patch_error.txt` 또는 결과 창도 알려 주세요.

## 파일 확인·이전 버전

[SHA256SUMS_v11.txt](SHA256SUMS_v11.txt)에서 다운로드 파일의 SHA-256을 확인할 수 있습니다.

이전 ISO 배포본: [v0.10](Condemned_Korean_ISO_v10.zip) · [v0.9](Condemned_Korean_ISO_v09.zip) · [v0.8](Condemned_Korean_ISO_v08.zip) · [v0.7](Condemned_Korean_ISO_v07.zip)

신규 다운로드는 v0.11을 사용하세요. 원본 게임 ISO·실행파일은 포함하지 않으며 Xenia용 패치만 배포합니다.
'''
(B/'README.md').write_text(github)
print(json.dumps(release))
