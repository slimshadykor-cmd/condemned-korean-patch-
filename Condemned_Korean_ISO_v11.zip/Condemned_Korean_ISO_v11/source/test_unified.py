from pathlib import Path
import json,struct,hashlib,subprocess,shutil
W=Path(__file__).resolve().parent.parent
T=Path('/tmp/condemned-v11-final');T.mkdir(exist_ok=False)
P=W/'v11_build/Condemned_Korean_ISO_v11/data';pw=W/'achievement_work/pwsh/pwsh'
m=json.loads((P/'iso_manifest.json').read_text());originalGpd=(W/'v10_tests/profile/original.gpd').read_bytes();originalXex=(W/'achievement_work/default/default.xex').read_bytes();prefix=(W/'qa_work/Condemned_Diagnostic/Layer0_first_8MB.bin').read_bytes()
content=T/'content';gpds=[]
for i in range(2):
 uid='B13EBABEBABEBAB'+str(i);p=content/uid/'FFFE07D1/00010000'/uid/'534507D2.gpd';p.parent.mkdir(parents=True);p.write_bytes(originalGpd);gpds.append(p)
# Backups outside the active layout must not be touched.
backupCopy=content/'archive_backup/534507D2.gpd';backupCopy.parent.mkdir();backupCopy.write_bytes(originalGpd)
iso=T/'clean original.iso';base=0xFD90000;root=base+34*2048;xat=base+64*2048;l1at=base+((xat-base+len(originalXex)+2047)//2048)*2048;l0at=l1at+2048;length=l0at+m['original_size']+4096
layer1=bytearray(49);struct.pack_into('>4sIIII',layer1,0,b'RATL',3,1,0,0)
desc=bytearray(2048);desc[:20]=desc[-20:]=b'MICROSOFT*XBOX*MEDIA';struct.pack_into('<II',desc,20,34,2048);table=bytearray(2048)
for at,left,right,off,size,name in [(0,8,16,l0at,m['original_size'],'Layer0.Arch00'),(32,0,0,xat,len(originalXex),'default.xex'),(64,0,0,l1at,len(layer1),'Layer1.Arch00')]:
 nm=name.encode();struct.pack_into('<HHIIBB',table,at,left,right,(off-base)//2048,size,0,len(nm));table[at+14:at+14+len(nm)]=nm
with iso.open('wb') as f:
 f.truncate(length)
 for off,data in [(base+65536,desc),(root,table),(xat,originalXex),(l1at,layer1),(l0at,prefix),(length-128,b'KEEP-TAIL-OF-ISO')]:f.seek(off);f.write(data)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def run(label,src=iso,out=None,contentRoot=content,extra=[],ok=True):
 if out is None:out=T/(label+'.iso')
 r=subprocess.run([str(pw),'-NoLogo','-NoProfile','-File',str(P/'Patch.ps1'),'-IsoPath',str(src),'-OutputPath',str(out),'-ContentDirectory',str(contentRoot)]+extra,capture_output=True,text=True,timeout=300)
 (T/(label+'.log')).write_text(r.stdout+r.stderr)
 assert (r.returncode==0)==ok,r.stdout+r.stderr
 return out,r.stdout+r.stderr
def records(b):
 ec,eu,fc=struct.unpack_from('>3I',b,8);db=24+18*ec+8*fc;d={}
 for i in range(eu):
  sec,id,off,sz=struct.unpack_from('>HQII',b,24+18*i);d[sec,id]=b[db+off:db+off+sz]
 return d
before=sha(iso);results=[]
out,log=run('one_launch_apply');assert '모두 마쳤습니다' in log
assert out.stat().st_size==length
with iso.open('rb') as a,out.open('rb') as b:
 b.seek(xat);assert hashlib.sha256(b.read(len(originalXex))).hexdigest()==m['achievement_patch']['patched_sha256']
 b.seek(l0at);assert hashlib.sha256(b.read(len(prefix))).hexdigest()==m['patched_prefix_sha256']
 for start,end in [(0,xat),(xat+len(originalXex),l0at),(l0at+len(prefix),length)]:
  a.seek(start);b.seek(start);left=end-start
  while left:
   n=min(8*1024*1024,left);assert a.read(n)==b.read(n);left-=n
assert sha(iso)==before
inv=json.loads((W/'achievement_work/xex_inventory.json').read_text())['resources'][0];tr={r['id']:r for r in json.loads((P/'achievement_translations.json').read_text())};ids={a['id']:a for a in inv['achievements']}
def verifyGpd(source,patched):
 a=records(source);b=records(patched);assert a.keys()==b.keys()
 for k in a:
  if k[0]==1 and k[1] in ids:
   ach=ids[k[1]];assert a[k][:28]==b[k][:28];assert b[k][28:].decode('utf-16-be').split('\0')[:2]==[tr[ach['label_id']]['korean'],tr[ach['description_id']]['korean']]
  else:assert a[k]==b[k]
for p in gpds:
 verifyGpd(originalGpd,p.read_bytes());assert len(list(p.parent.glob('*.bak')))==1;assert next(p.parent.glob('*.bak')).read_bytes()==originalGpd
assert backupCopy.read_bytes()==originalGpd
results.append('PASS: one launcher creates Korean ISO and translates both existing profiles; originals and progress preserved; unrelated backup ignored')
# Already-patched v0.10/v0.11 ISO is used directly, even if output equals source.
isoHash=sha(out)
for p in gpds:p.write_bytes(originalGpd)
_,log=run('reuse_existing_iso',src=out,out=out);assert '재생성 없이' in log and '모두 마쳤습니다' in log;assert sha(out)==isoHash
for p in gpds:verifyGpd(originalGpd,p.read_bytes())
results.append('PASS: already-patched ISO reused byte-exact; profile changes finish through same launcher without recopying ISO')
oldBackups={str(p):len(list(p.parent.glob('*.bak'))) for p in gpds};_,log=run('idempotent',src=out,out=out)
assert oldBackups=={str(p):len(list(p.parent.glob('*.bak'))) for p in gpds};assert '변경 필요 0개' in log
results.append('PASS: rerun with Korean profiles is a no-op, no duplicate backup')
# Invalid second profile must prevent both first-profile changes and ISO creation.
for p in gpds:p.write_bytes(originalGpd)
bad=bytearray(originalGpd);ec,eu,fc=struct.unpack_from('>3I',bad,8);db=24+18*ec+8*fc;bad[db+28:db+30]=b'\x00Z';gpds[1].write_bytes(bad)
failure,_=run('invalid_second_profile',ok=False);assert not failure.exists();assert gpds[0].read_bytes()==originalGpd and gpds[1].read_bytes()==bad
gpds[1].write_bytes(originalGpd)
results.append('PASS: invalid profile stops entire operation before ISO creation or any profile mutation')
# Corrupt ISO also leaves every profile untouched.
with iso.open('r+b') as f:f.seek(xat+100);v=f.read(1);f.seek(xat+100);f.write(bytes([v[0]^1]))
failure,_=run('wrong_iso',ok=False);assert not failure.exists();assert all(p.read_bytes()==originalGpd for p in gpds)
with iso.open('r+b') as f:f.seek(xat+100);f.write(v)
results.append('PASS: wrong ISO rejected before changing profiles')
empty=T/'empty_content';empty.mkdir()
failure,_=run('no_profile_blocked',contentRoot=empty,ok=False);assert not failure.exists()
_,log=run('no_profile_explicit',src=out,out=out,contentRoot=empty,extra=['-AllowNoProfile']);assert '프로필 변경은 없었습니다' in log and '모두 마쳤습니다' not in log
results.append('PASS: missing profile is not silently treated as translated; explicit new-environment confirmation required')
assert sha(iso)==before and sha(out)==isoHash
results.append('LIMIT: full-size synthetic ISO with real supplied executable/prefix; synthetic profiles; PowerShell 7.4.6 Linux, Windows dialogs/game display not run')
(T/'test_results.txt').write_text('\n'.join(results)+'\n');print('\n'.join(results))
