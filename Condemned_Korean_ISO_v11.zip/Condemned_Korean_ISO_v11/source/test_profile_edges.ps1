$ErrorActionPreference='Stop'
$work='/tmp/condemned-v11-edges'
[void][IO.Directory]::CreateDirectory($work)
$source=[IO.File]::ReadAllBytes('v10_tests/profile/original.gpd')
Add-Type -Path @('v11_build/Condemned_Korean_ISO_v11/data/XexPatch.cs','v11_build/Condemned_Korean_ISO_v11/data/GpdText.cs','v11_build/Condemned_Korean_ISO_v11/data/ProfileBatch.cs')
. ./v11_build/Condemned_Korean_ISO_v11/data/ProfilePaths.ps1
function Need($v,$m){if(!$v){throw $m}}
$paths=@()
foreach($n in @('a','b')){$dir=Join-Path $work $n;[void][IO.Directory]::CreateDirectory($dir);$p=Join-Path $dir '534507D2.gpd';[IO.File]::WriteAllBytes($p,$source);$paths+=$p}
$oldHash=[CondemnedKorean.XexPatch]::Hash($source)
$batch=[CondemnedKorean.ProfileBatch]::Prepare([string[]]$paths,$false)
$batch.Items[1].Backup=Join-Path $work 'missing-directory/never.bak'
$rejected=$false;try{$batch.Commit()}catch{$rejected=$true}
Need $rejected 'Expected second replace failure'
foreach($p in $paths){Need ((Get-FileHash $p -Algorithm SHA256).Hash.ToLowerInvariant() -eq $oldHash) 'Rollback did not restore original'}
Need (@(Get-ChildItem $work -Recurse -Filter '*.tmp').Count -eq 0) 'Staging files remain'
$results=@('PASS: second-profile replacement failure rolls first profile back byte-exact; no staging files remain')
$batch=[CondemnedKorean.ProfileBatch]::Prepare([string[]]$paths,$false)
$changed=[byte[]]$source.Clone();$changed[$changed.Length-3]=$changed[$changed.Length-3] -bxor 1;[IO.File]::WriteAllBytes($paths[1],$changed)
$rejected=$false;try{$batch.Commit()}catch{$rejected=$true}
Need $rejected 'Expected concurrent-change rejection'
Need ((Get-FileHash $paths[0] -Algorithm SHA256).Hash.ToLowerInvariant() -eq $oldHash) 'First profile mutated on preflight failure'
Need ((Get-FileHash $paths[1] -Algorithm SHA256).Hash.ToLowerInvariant() -eq [CondemnedKorean.XexPatch]::Hash($changed)) 'New external profile contents overwritten'
$results+='PASS: profile changed after preparation stops whole batch without overwriting newer data'
$xenia=Join-Path $work 'xenia';$custom=Join-Path $work 'custom-content';[void][IO.Directory]::CreateDirectory($xenia);[void][IO.Directory]::CreateDirectory($custom)
$config=Join-Path $xenia 'xenia-canary.config.toml'
[IO.File]::WriteAllText($config,('content_root = '+($custom | ConvertTo-Json)+' # comment'))
Need ((Resolve-ContentDirectory $xenia) -eq $custom) 'Custom quoted content_root resolution failed'
[IO.File]::WriteAllText($config,("content_root = '"+$custom+"' # comment"))
Need ((Resolve-ContentDirectory $xenia) -eq $custom) 'Literal content_root resolution failed'
[IO.File]::WriteAllText($config,("content_root = ''`nstorage_root = '"+$work+"'"))
Need ((Resolve-ContentDirectory $xenia) -eq (Join-Path $work 'content')) 'storage_root resolution failed'
[IO.File]::WriteAllText($config,"content_root = ''`nstorage_root = ''")
Need ((Resolve-ContentDirectory $xenia) -eq (Join-Path $xenia 'content')) 'Default content path resolution failed'
[IO.File]::WriteAllText((Join-Path $xenia 'xenia.config.toml'),("content_root = '"+$custom+"'"))
$rejected=$false;try{[void](Resolve-ContentDirectory $xenia)}catch{$rejected=$true}
Need $rejected 'Ambiguous configurations not rejected'
$results+='PASS: quoted/literal custom paths, storage_root and default path resolve; ambiguous configurations require direct content selection'
$results | Set-Content -LiteralPath (Join-Path $work 'results.txt') -Encoding UTF8
$results
