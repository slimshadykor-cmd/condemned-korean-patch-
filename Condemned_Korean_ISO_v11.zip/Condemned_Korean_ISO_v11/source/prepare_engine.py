from pathlib import Path
import json
p=Path('v11_build/Condemned_Korean_ISO_v11/data/IsoPatcher.cs');s=p.read_text()
s=s.replace('public long IsoSize;','public bool AlreadyPatched;\n        public long IsoSize;',1)
gates='''            Require(!Equal(sourcePath,outputPath), "Source and output paths must be different.");
            Require(!File.Exists(outputPath) && !Directory.Exists(outputPath), "Output already exists. Choose another output name.");
'''
assert gates in s;s=s.replace(gates,'',1)
a='''                    Require(Equal(Hash(Read(source,xex.Offset,(int)xex.Length)),plan.XexHash),
                        "default.xex differs from the supported game edition.");'''
assert a in s;s=s.replace(a,'''                    string xexHash=Hash(Read(source,xex.Offset,(int)xex.Length));''')
a='''                    Require(!Equal(prefixHash,plan.PatchedHash), "This ISO already contains Korean ISO v0.10. Select the original ISO.");'''
assert a in s;s=s.replace(a,'''                    if (Equal(prefixHash,plan.PatchedHash) && Equal(xexHash,CondemnedKorean.XexPatch.PatchedHash)) {
                        CheckLayer1(source,layer1);
                        Console.WriteLine("Existing Korean ISO metadata and resource hashes verified; ISO is reused without copying.");
                        return new Result {AlreadyPatched=true,IsoSize=source.Length,PartitionOffset=gameBase,Layer0Offset=layer0.Offset,OutputPath=sourcePath};
                    }
                    Require(Equal(xexHash,plan.XexHash), "default.xex differs from the supported game edition.");
                    Require(!Equal(prefixHash,plan.PatchedHash), "Earlier Korean ISO without translated achievement metadata. Select a clean original ISO.");''')
s=s.replace('                    if (inspectOnly) return result;','''                    Require(!Equal(sourcePath,outputPath), "Source and output paths must be different.");
                    Require(!File.Exists(outputPath) && !Directory.Exists(outputPath), "Output already exists. Choose another output name.");
                    if (inspectOnly) return result;''')
p.write_text(s)
p=Path('v11_build/Condemned_Korean_ISO_v11/data/iso_manifest.json');m=json.loads(p.read_text());m['version']='0.11-ISO';m['translation_data_version']='0.10';p.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
