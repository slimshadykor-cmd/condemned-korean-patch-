﻿function Get-ProfilePaths([string]$ContentDirectory) {
    $root=[IO.Path]::GetFullPath($ContentDirectory)
    if (!(Test-Path -LiteralPath $root -PathType Container)) { throw ('content 폴더를 찾을 수 없습니다: '+$root) }
    $files=New-Object 'System.Collections.Generic.List[string]'
    # Only active profile layout. Do not recursively search backups or game saves.
    foreach ($user in @(Get-ChildItem -LiteralPath $root -Directory)) {
        if ($user.Name -notmatch '^[0-9a-fA-F]{16}$' -or ($user.Attributes -band [IO.FileAttributes]::ReparsePoint)) { continue }
        $profileRoot=Join-Path $user.FullName 'FFFE07D1/00010000'
        if (!(Test-Path -LiteralPath $profileRoot -PathType Container)) { continue }
        foreach ($profile in @(Get-ChildItem -LiteralPath $profileRoot -Directory)) {
            if ($profile.Name -notmatch '^[0-9a-fA-F]{16}$' -or ($profile.Attributes -band [IO.FileAttributes]::ReparsePoint)) { continue }
            $file=Join-Path $profile.FullName '534507D2.gpd'
            if (Test-Path -LiteralPath $file -PathType Leaf) { $files.Add([IO.Path]::GetFullPath($file)) }
        }
    }
    return $files.ToArray()
}
function Get-QuotedConfigValue([string]$Config,[string]$Key) {
    $pattern='(?m)^\s*'+[regex]::Escape($Key)+'\s*=\s*("(?:\\.|[^"\\])*"|''[^'']*'')\s*(?:#.*)?$'
    $matches=[regex]::Matches($Config,$pattern)
    if ($matches.Count -eq 0) { return '' }
    if ($matches.Count -gt 1) { throw '설정에 경로가 중복되어 있습니다. 실제 content 폴더를 직접 선택해 주세요.' }
    $v=$matches[0].Groups[1].Value
    if ($v.StartsWith("'")) { return $v.Substring(1,$v.Length-2) }
    try { return [string]($v | ConvertFrom-Json) }
    catch { throw '설정의 경로를 읽지 못했습니다. 실제 content 폴더를 직접 선택해 주세요.' }
}
function Resolve-ContentDirectory([string]$SelectedDirectory) {
    $selected=[IO.Path]::GetFullPath($SelectedDirectory)
    if (!(Test-Path -LiteralPath $selected -PathType Container)) { throw '선택한 폴더를 찾을 수 없습니다.' }
    if ((Split-Path $selected -Leaf) -ieq 'content' -or @(Get-ProfilePaths $selected).Count -gt 0) { return $selected }
    $configured=New-Object 'System.Collections.Generic.List[string]'
    foreach ($name in @('xenia-canary.config.toml','xenia.config.toml')) {
        $path=Join-Path $selected $name
        if (!(Test-Path -LiteralPath $path -PathType Leaf)) { continue }
        $config=[IO.File]::ReadAllText($path)
        $content=Get-QuotedConfigValue $config 'content_root'
        $storage=Get-QuotedConfigValue $config 'storage_root'
        if ($content) { $candidate=$content }
        elseif ($storage) { $candidate=Join-Path $storage 'content' }
        else { $candidate=Join-Path $selected 'content' }
        if (![IO.Path]::IsPathRooted($candidate)) { $candidate=Join-Path $selected $candidate }
        $candidate=[IO.Path]::GetFullPath($candidate)
        if (!$configured.Contains($candidate)) { $configured.Add($candidate) }
    }
    if ($configured.Count -gt 1) { throw 'Xenia 설정마다 저장 폴더가 다릅니다. 사용 중인 content 폴더를 직접 선택해 주세요.' }
    if ($configured.Count -eq 1) { return $configured[0] }
    if (Test-Path -LiteralPath (Join-Path $selected 'content') -PathType Container) { return (Join-Path $selected 'content') }
    return $selected
}
function Assert-XeniaClosed {
    if (@(Get-Process -Name 'xenia*' -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Xenia를 완전히 종료한 뒤 같은 패치 파일을 다시 실행해 주세요.' }
}
