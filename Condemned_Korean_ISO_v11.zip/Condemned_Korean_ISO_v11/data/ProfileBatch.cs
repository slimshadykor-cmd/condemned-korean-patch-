using System;
using System.IO;
using System.Collections.Generic;
namespace CondemnedKorean {
 public sealed class ProfileEdit {
  public string Path,OriginalHash,UpdatedHash,Backup,Temp;
  public byte[] Updated;
  public bool Committed;
 }
 public sealed class ProfileBatch {
  public List<ProfileEdit> Items=new List<ProfileEdit>();
  public int Count,ChangedCount;
  public static ProfileBatch Prepare(string[] paths,bool restore) {
   var batch=new ProfileBatch();var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
   foreach(string path in paths){
    string full=System.IO.Path.GetFullPath(path);
    if(!String.Equals(System.IO.Path.GetFileName(full),"534507D2.gpd",StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("Only Condemned profile files are supported.");
    if(!seen.Add(full))continue;
    var fi=new FileInfo(full);
    if(fi.Length>128*1024*1024 || (fi.Attributes&FileAttributes.ReparsePoint)!=0)throw new InvalidDataException("Unsupported profile file: "+full);
    byte[] original=File.ReadAllBytes(full),updated=GpdText.Build(original,restore);
    string oldHash=XexPatch.Hash(original),newHash=XexPatch.Hash(updated);batch.Count++;
    if(oldHash==newHash)continue;
    string token=DateTime.UtcNow.ToString("yyyyMMddTHHmmssfff")+"-"+Guid.NewGuid().ToString("N");
    batch.Items.Add(new ProfileEdit {Path=full,OriginalHash=oldHash,UpdatedHash=newHash,Updated=updated,
     Temp=full+".text_v11."+token+".tmp",Backup=full+".before_text_v11."+token+".bak"});
   }
   batch.ChangedCount=batch.Items.Count;return batch;
  }
  public void Commit(){
   var staged=new List<ProfileEdit>();
   try {
    // Validate every profile before replacing any; later changes are never silently overwritten.
    foreach(var e in Items)if(XexPatch.Hash(File.ReadAllBytes(e.Path))!=e.OriginalHash)throw new IOException("Profile changed during ISO creation. Close Xenia and run this same patch again: "+e.Path);
    foreach(var e in Items){
     using(var f=new FileStream(e.Temp,FileMode.CreateNew,FileAccess.Write,FileShare.None)){staged.Add(e);f.Write(e.Updated,0,e.Updated.Length);f.Flush(true);}
     if(XexPatch.Hash(File.ReadAllBytes(e.Temp))!=e.UpdatedHash)throw new IOException("Profile staging verification failed.");
    }
    foreach(var e in Items){
     if(XexPatch.Hash(File.ReadAllBytes(e.Path))!=e.OriginalHash)throw new IOException("Profile changed before replacement.");
     File.Replace(e.Temp,e.Path,e.Backup);e.Committed=true;
     if(XexPatch.Hash(File.ReadAllBytes(e.Path))!=e.UpdatedHash)throw new IOException("Written profile verification failed.");
    }
   } catch(Exception originalError) {
    var errors=new List<string>();
    for(int i=Items.Count-1;i>=0;i--){var e=Items[i];if(!e.Committed)continue;
     try {
      if(XexPatch.Hash(File.ReadAllBytes(e.Path))!=e.UpdatedHash)throw new IOException("Profile changed externally; original retained at "+e.Backup);
      File.Replace(e.Backup,e.Path,e.Temp);e.Committed=false;
     } catch(Exception rollbackError){errors.Add(rollbackError.Message);}
    }
    if(errors.Count>0)throw new IOException(originalError.Message+" Rollback needs review; preserve backups. "+String.Join("; ",errors.ToArray()),originalError);
    throw;
   } finally {
    foreach(var e in staged)if(File.Exists(e.Temp)){try{File.Delete(e.Temp);}catch{}}
   }
  }
 }
}
