﻿param([string]$GameDirectory = '')
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$package = Split-Path -Parent $MyInvocation.MyCommand.Path
try {
    if ([string]::IsNullOrWhiteSpace($GameDirectory)) {
        foreach ($candidate in @($package,(Split-Path -Parent $package))) {
            if (Test-Path -LiteralPath (Join-Path $candidate 'Layer0.Arch00') -PathType Leaf) {
                $GameDirectory = $candidate
                break
            }
        }
    }
    if ([string]::IsNullOrWhiteSpace($GameDirectory)) {
        throw 'Put Condemned_Korean_UI_v10 beside default.xex and Layer0.Arch00, then run RUN_FIX.bat.'
    }
    $GameDirectory = [IO.Path]::GetFullPath($GameDirectory)
    $psExe = Join-Path $PSHOME 'powershell.exe'
    if (!(Test-Path -LiteralPath $psExe -PathType Leaf)) { $psExe=Join-Path $PSHOME 'pwsh' }
    $newState = Join-Path $GameDirectory 'Condemned_KoreanUI_v10.state.json'
    $newBackup = Join-Path $GameDirectory 'Layer0.Arch00.pre_KoreanUI_v10.bak'
    if ((Test-Path -LiteralPath $newState) -or (Test-Path -LiteralPath $newBackup)) {
        throw 'A v0.10 installation record or backup already exists. Use this folder RUN_RESTORE.bat before reapplying.'
    }
    $installed = @()
    foreach ($version in @('v09','v08','v07','v06','v05','v04','v03','v02','v01')) {
        $oldState = Join-Path $GameDirectory ('Condemned_KoreanUI_'+$version+'.state.json')
        $oldBackup = Join-Path $GameDirectory ('Layer0.Arch00.pre_KoreanUI_'+$version+'.bak')
        if ((Test-Path -LiteralPath $oldState) -or (Test-Path -LiteralPath $oldBackup)) {
            if (!(Test-Path -LiteralPath $oldState -PathType Leaf) -or !(Test-Path -LiteralPath $oldBackup -PathType Leaf)) {
                throw ('Both the '+$version+' record and original backup are required. No files were changed.')
            }
            $installed += $version
        }
    }
    if ($installed.Count -gt 1) { throw 'Multiple installation records found. No files were changed. Send a screenshot of this game folder.' }
    if ($installed.Count -eq 1) {
        $version=$installed[0]
        Write-Host ('STEP 1/2: Verifying and restoring the original '+$version+' backup...')
        $restore = Join-Path $package ('upgrade_'+$version+'/Patch.ps1')
        & $psExe -NoProfile -ExecutionPolicy Bypass -File $restore -Mode Restore -GameDirectory $GameDirectory
        if ($LASTEXITCODE -ne 0) { throw 'Restoration stopped. v0.10 was not applied. See the error above.' }
    }
    Write-Host 'STEP 2/2: Applying Korean UI v0.10 with campaign text translations...'
    & $psExe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $package 'Patch.ps1') -Mode Apply -GameDirectory $GameDirectory
    if ($LASTEXITCODE -ne 0) { throw 'v0.10 installation stopped. See the error above and patch_error.txt.' }
    Write-Host 'FIX APPLIED: Open default.xex and check Korean dialogue, documents and menus.' -ForegroundColor Green
    exit 0
} catch {
    $message = $_.Exception.Message
    Write-Host ('ERROR: '+$message) -ForegroundColor Red
    try { [IO.File]::WriteAllText((Join-Path $package 'upgrade_error.txt'),$message,[Text.Encoding]::UTF8) } catch {}
    exit 1
}
