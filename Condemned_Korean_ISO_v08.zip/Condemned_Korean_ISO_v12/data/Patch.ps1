﻿param(
    [string]$IsoPath='',
    [ValidateSet('Xenia','Xbox360')][string]$Target='',
    [string]$OutputPath='',
    [string]$ContentDirectory='',
    [switch]$AllowNoProfile,
    [switch]$InspectOnly,
    [ValidateSet('Apply','RestoreText')][string]$Mode='Apply'
)
$ErrorActionPreference='Stop'
Set-StrictMode -Version 2.0
$package=Split-Path -Parent $MyInvocation.MyCommand.Path
$release=Split-Path -Parent $package
$isoReady=$false;$effectiveIso='';$profileBatch=$null
. (Join-Path $package 'ProfilePaths.ps1')
try {
    Write-Host '컨뎀드 한글 패치 v1.2 / 한글화: 슬림쉐이디' -ForegroundColor Cyan
    Write-Host '선택한 환경에 맞춰 별도의 한글 ISO를 생성합니다.'
    Add-Type -Path @((Join-Path $package 'XexPatch.cs'),(Join-Path $package 'IsoPatcher.cs'),(Join-Path $package 'GpdText.cs'),(Join-Path $package 'ProfileBatch.cs'))
    if ([string]::IsNullOrWhiteSpace($Target)) {
        if ($Mode -eq 'RestoreText' -or $InspectOnly) { $Target='Xenia' }
        else {
            Add-Type -AssemblyName System.Windows.Forms
            $form=New-Object System.Windows.Forms.Form
            $form.Text='컨뎀드 v1.2 - 사용 환경 선택';$form.Width=540;$form.Height=260
            $form.StartPosition='CenterScreen';$form.FormBorderStyle='FixedDialog';$form.MaximizeBox=$false;$form.MinimizeBox=$false
            $label=New-Object System.Windows.Forms.Label
            $label.Text='패치를 사용할 환경을 선택하세요.';$label.SetBounds(20,15,490,30)
            $xenia=New-Object System.Windows.Forms.RadioButton
            $xenia.Text='Xenia용 - 게임 + 도전 과제 한글화';$xenia.SetBounds(20,55,490,30)
            $retail=New-Object System.Windows.Forms.RadioButton
            $retail.Text='Xbox 360 실기용 - 게임 한글화 / 원본 XEX 유지';$retail.SetBounds(20,95,490,30)
            $ok=New-Object System.Windows.Forms.Button
            $ok.Text='다음';$ok.SetBounds(290,160,100,35);$ok.Enabled=$false;$ok.DialogResult='OK'
            $cancel=New-Object System.Windows.Forms.Button
            $cancel.Text='취소';$cancel.SetBounds(400,160,100,35);$cancel.DialogResult='Cancel'
            $xenia.Add_CheckedChanged({$ok.Enabled=$true});$retail.Add_CheckedChanged({$ok.Enabled=$true})
            $form.Controls.AddRange(@($label,$xenia,$retail,$ok,$cancel));$form.AcceptButton=$ok;$form.CancelButton=$cancel
            try {
                if ($form.ShowDialog() -ne 'OK') {Write-Host '취소했습니다. 변경된 파일이 없습니다.';exit 0}
                if ($retail.Checked) {$Target='Xbox360'} else {$Target='Xenia'}
            } finally {$form.Dispose()}
        }
    }
    if ($Target -eq 'Xbox360' -and $Mode -ne 'Apply') {throw '실기용은 프로필 문구 처리 기능을 사용하지 않습니다.'}
    if ($Target -eq 'Xenia') {Assert-XeniaClosed}
    Write-Host ('선택한 환경: '+$Target)
    if ($Mode -eq 'Apply') {
        if ([string]::IsNullOrWhiteSpace($IsoPath)) {
            Add-Type -AssemblyName System.Windows.Forms
            $dialog=New-Object System.Windows.Forms.OpenFileDialog
            try {
                $dialog.Title='원본 ISO 또는 v1.1 / v1.2 한글 ISO를 선택하세요'
                $dialog.Filter='Xbox 360 ISO (*.iso)|*.iso';$dialog.CheckFileExists=$true
                if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Write-Host '취소했습니다. 변경된 파일이 없습니다.';exit 0 }
                $IsoPath=$dialog.FileName
            } finally { $dialog.Dispose() }
        }
        $IsoPath=[IO.Path]::GetFullPath($IsoPath)
        if ([string]::IsNullOrWhiteSpace($OutputPath)) { $suffix='_Korean_v12.iso';if ($Target -eq 'Xbox360') {$suffix='_Korean_Xbox360_v12.iso'};$OutputPath=Join-Path ([IO.Path]::GetDirectoryName($IsoPath)) (([IO.Path]::GetFileNameWithoutExtension($IsoPath) -replace '_Korean_(?:Xbox360_)?v(?:10|11|12)$','')+$suffix) }
        $OutputPath=[IO.Path]::GetFullPath($OutputPath)
        $manifest=Get-Content -LiteralPath (Join-Path $package 'iso_manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($manifest.format_version -ne 2 -or $manifest.version -ne '1.2-ISO') { throw 'Unsupported patch manifest.' }
        $plan=New-Object CondemnedKoreanISO.Plan
        $plan.Retail=($Target -eq 'Xbox360')
        $plan.OriginalSize=[long]$manifest.original_size;$plan.PrefixSize=[int]$manifest.prefix_size
        $plan.OriginalHash=$manifest.original_prefix_sha256;$plan.PatchedHash=$manifest.patched_prefix_sha256
        $plan.PreviousHash=$manifest.previous_prefix_sha256
        $plan.XexHash=$manifest.xex_sha256;$plan.RegionStart=[int]$manifest.region_start;$plan.RegionEnd=[int]$manifest.region_end
        $moves=New-Object 'System.Collections.Generic.List[CondemnedKoreanISO.Move]'
        foreach ($r in $manifest.moves) {
            $m=New-Object CondemnedKoreanISO.Move
            $m.EntryOffset=[int]$r.entry_offset;$m.OriginalEntryHex=$r.original_entry_hex
            $m.SourceOffset=[int]$r.source_offset;$m.SourceSize=[int]$r.source_size
            $m.Destination=[int]$r.destination;$m.Size=[int]$r.size;$m.RawSize=[long]$r.raw_size
            $m.Payload=$r.payload;$m.Sha256=$r.sha256;$moves.Add($m)
        }
        $plan.Moves=$moves.ToArray()
        $previousMoves=New-Object 'System.Collections.Generic.List[CondemnedKoreanISO.Move]'
        foreach ($r in $manifest.previous_moves) {
            $m=New-Object CondemnedKoreanISO.Move
            $m.EntryOffset=[int]$r.entry_offset;$m.OriginalEntryHex=$r.original_entry_hex
            $m.SourceOffset=[int]$r.source_offset;$m.SourceSize=[int]$r.source_size
            $m.Destination=[int]$r.destination;$m.Size=[int]$r.size;$m.RawSize=[long]$r.raw_size
            $m.Payload=$r.payload;$m.Sha256=$r.sha256;$previousMoves.Add($m)
        }
        $plan.PreviousMoves=$previousMoves.ToArray()
        Write-Host '1/3 ISO 상태를 검사합니다.'
        $check=[CondemnedKoreanISO.Patcher]::Run($IsoPath,$OutputPath,$package,$plan,$true)
        if ($check.AlreadyPatched) { Write-Host '선택한 환경의 v1.2 ISO입니다. 재생성 없이 검증된 ISO를 사용합니다.' }
        if ($InspectOnly -and [string]::IsNullOrWhiteSpace($ContentDirectory)) { Write-Host 'ISO 검사 통과. 프로필 검사는 요청되지 않았으며 파일을 변경하지 않았습니다.';exit 0 }
    }
    if ($Target -eq 'Xbox360') {
        if ($InspectOnly) {Write-Host '실기용 사전 검사 통과. 변경된 파일이 없습니다.';exit 0}
        if ($check.AlreadyPatched) {$result=$check} else {$result=[CondemnedKoreanISO.Patcher]::Run($IsoPath,$OutputPath,$package,$plan,$false)}
        $effectiveIso=$result.OutputPath;$isoReady=$true
        Write-Host ('완료: Xbox 360 실기용 ISO / 원본 XEX 해시 검증 완료: '+$effectiveIso) -ForegroundColor Green
        Write-Host '프로필과 도전 과제 문구는 변경하지 않았습니다. 실기 전체 플레이 검수는 미완료입니다.'
        $report=[ordered]@{version='1.2';target=$Target;utc=[DateTime]::UtcNow.ToString('o');iso=$effectiveIso;iso_reused=[bool]$result.AlreadyPatched;source_sha256=$result.SourceSha256;output_sha256=$result.OutputSha256;xex_sha256=$plan.XexHash;profiles_changed=0;runtime_game_display_verified=$false}
        try {[IO.File]::WriteAllText((Join-Path $release ('patch_result_'+[DateTime]::UtcNow.ToString('yyyyMMdd_HHmmssfff')+'.json')),($report|ConvertTo-Json -Depth 6),[Text.Encoding]::UTF8)} catch {Write-Host '결과 기록 파일을 저장하지 못했습니다.'}
        exit 0
    }
    Write-Host '2/3 도전 과제 기록을 검사합니다. 획득 상태와 점수는 보존합니다.'
    if ([string]::IsNullOrWhiteSpace($ContentDirectory)) {
        Add-Type -AssemblyName System.Windows.Forms
        while ($true) {
            $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
            try {
                $dialog.Description='사용 중인 Xenia 폴더 또는 content 폴더를 선택하세요.'
                $dialog.ShowNewFolderButton=$false
                if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Write-Host '취소했습니다. 변경된 파일이 없습니다.';exit 0 }
                $selected=$dialog.SelectedPath
            } finally { $dialog.Dispose() }
            try {
                $candidate=Resolve-ContentDirectory $selected
                $profilePaths=@(Get-ProfilePaths $candidate)
            } catch {
                [void][System.Windows.Forms.MessageBox]::Show($_.Exception.Message,'content 폴더 확인',[System.Windows.Forms.MessageBoxButtons]::OK,[System.Windows.Forms.MessageBoxIcon]::Information)
                continue
            }
            if ($profilePaths.Count -gt 0) { $ContentDirectory=$candidate;break }
            $message="선택한 위치에서 컨뎀드의 기존 도전 과제 기록을 찾지 못했습니다.`n`n$candidate`n`n처음 실행하는 환경이거나 GPD 기록을 쓰지 않는 구버전이면 예를 선택하세요.`n이미 영어 설명이 보였던 환경이면 아니요를 눌러 실제 content 폴더를 다시 선택하세요.`n`n기존 기록 없이 계속하시겠습니까?"
            $answer=[System.Windows.Forms.MessageBox]::Show($message,'기존 기록 확인',[System.Windows.Forms.MessageBoxButtons]::YesNoCancel,[System.Windows.Forms.MessageBoxIcon]::Question)
            if ($answer -eq [System.Windows.Forms.DialogResult]::Cancel) { Write-Host '취소했습니다. 변경된 파일이 없습니다.';exit 0 }
            if ($answer -eq [System.Windows.Forms.DialogResult]::Yes) { $ContentDirectory=$candidate;$AllowNoProfile=$true;break }
        }
    }
    $ContentDirectory=[IO.Path]::GetFullPath($ContentDirectory)
    $profilePaths=@(Get-ProfilePaths $ContentDirectory)
    if ($profilePaths.Count -eq 0 -and !$AllowNoProfile) { throw '기존 프로필을 찾지 못해 변경 전에 중단했습니다. 실제 content 폴더를 선택하세요. 신규 환경만 AllowNoProfile로 진행할 수 있습니다.' }
    Write-Host ('사용할 content 폴더: '+$ContentDirectory)
    $profileBatch=[CondemnedKorean.ProfileBatch]::Prepare([string[]]$profilePaths,($Mode -eq 'RestoreText'))
    Write-Host ('컨뎀드 프로필 {0}개 확인 / 문구 변경 필요 {1}개' -f $profileBatch.Count,$profileBatch.ChangedCount)
    if ($InspectOnly) { Write-Host 'ISO/프로필 사전 검사 통과. 변경된 파일이 없습니다.' -ForegroundColor Green;exit 0 }
    Assert-XeniaClosed
    if ($Mode -eq 'Apply') {
        if ($check.AlreadyPatched) { $result=$check }
        else {
            Write-Host '3/3 한글 ISO를 생성하고 전체 해시를 검증합니다. 창을 닫지 마세요.'
            $result=[CondemnedKoreanISO.Patcher]::Run($IsoPath,$OutputPath,$package,$plan,$false)
        }
        $effectiveIso=$result.OutputPath;$isoReady=$true
    }
    Assert-XeniaClosed
    $profileBatch.Commit()
    if ($Mode -eq 'RestoreText') { Write-Host '완료: 기존 획득 기록을 유지하면서 도전 과제 설명을 영어로 복원했습니다.' -ForegroundColor Green }
    elseif ($profileBatch.Count -gt 0) { Write-Host '완료: 한글 ISO 확인과 기존 도전 과제 설명 처리를 모두 마쳤습니다.' -ForegroundColor Green }
    else { Write-Host 'ISO 처리가 완료됐습니다. 기존 프로필 기록이 없는 것으로 선택하셔서 프로필 변경은 없었습니다.' -ForegroundColor Yellow }
    if ($isoReady) { Write-Host ('실행할 ISO: '+$effectiveIso);Write-Host 'Xenia 콘솔 언어는 English 또는 Korean으로 설정하세요.' }
    foreach ($item in $profileBatch.Items) { if ($item.Committed) { Write-Host ('도전 과제 기록 백업: '+$item.Backup) } }
    $report=[ordered]@{version='1.2';target=$Target;utc=[DateTime]::UtcNow.ToString('o');mode=$Mode;iso=$effectiveIso;content_directory=$ContentDirectory;profiles_found=$profileBatch.Count;profiles_changed=$profileBatch.ChangedCount;no_profile_confirmed=[bool]$AllowNoProfile;backups=@($profileBatch.Items | ForEach-Object {$_.Backup});runtime_game_display_verified=$false}
    if ($isoReady) { $report['iso_reused']=[bool]$result.AlreadyPatched;$report['source_sha256']=$result.SourceSha256;$report['output_sha256']=$result.OutputSha256 }
    try { [IO.File]::WriteAllText((Join-Path $release ('patch_result_'+[DateTime]::UtcNow.ToString('yyyyMMdd_HHmmssfff')+'.json')),($report | ConvertTo-Json -Depth 6),[Text.Encoding]::UTF8) }
    catch { Write-Host '적용은 완료됐지만 결과 기록 파일은 저장하지 못했습니다.' -ForegroundColor Yellow }
    exit 0
} catch {
    $message=$_.Exception.Message
    if ($_.Exception.InnerException) { $message=$_.Exception.InnerException.Message }
    Write-Host '전체 패치 작업을 완료하지 못했습니다.' -ForegroundColor Red
    Write-Host $message -ForegroundColor Red
    if ($isoReady) {
        Write-Host ('한글 ISO는 준비되어 있습니다: '+$effectiveIso) -ForegroundColor Yellow
        Write-Host '원인을 해결한 뒤 같은 RUN_PATCH.bat를 실행하고 이 ISO를 선택하면 프로필 처리부터 다시 진행합니다.'
    } else { Write-Host '원본 ISO는 변경하지 않았습니다.' }
    try { [IO.File]::WriteAllText((Join-Path $release 'patch_error.txt'),$message,[Text.Encoding]::UTF8) } catch {}
    exit 1
}
