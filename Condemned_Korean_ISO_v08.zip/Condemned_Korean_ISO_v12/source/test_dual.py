from pathlib import Path
import hashlib,json,struct,subprocess,os
W=Path(__file__).resolve().parent;P=W/'package/Condemned_Korean_ISO_v12/data';T=W/'tests';T.mkdir(exist_ok=True)
pw=W/'pwsh/pwsh';pw.chmod(0o755)
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((P/'iso_manifest.json').read_text(encoding='utf-8-sig'))
x=(W/'inputs/default/default.xex').read_bytes();clean=(W/'inputs/diagnostic/Layer0_first_8MB.bin').read_bytes()
assert sha(x)==m['xex_sha256'] and sha(clean)==m['original_prefix_sha256']
base=0xFD90000;root=base+34*2048;xa=base+64*2048;l1=base+((xa-base+len(x)+2047)//2048)*2048;l0=l1+2048;length=l0+m['original_size']+4096
layer1=bytearray(49);struct.pack_into('>4sIIII',layer1,0,b'RATL',3,1,0,0)
desc=bytearray(2048);desc[:20]=desc[-20:]=b'MICROSOFT*XBOX*MEDIA';struct.pack_into('<II',desc,20,34,2048)
table=bytearray(2048)
for at,left,right,off,size,name in [(0,8,16,l0,m['original_size'],'Layer0.Arch00'),(32,0,0,xa,len(x),'default.xex'),(64,0,0,l1,len(layer1),'Layer1.Arch00')]:
 nm=name.encode();struct.pack_into('<HHIIBB',table,at,left,right,(off-base)//2048,size,0,len(nm));table[at+14:at+14+len(nm)]=nm
original=T/'original.iso'
with original.open('wb') as f:
 f.truncate(length)
 for off,data in [(base+65536,desc),(root,table),(xa,x),(l1,layer1),(l0,clean),(length-128,b'KEEP-UNRELATED-TAIL')]:f.seek(off);f.write(data)
def run(src,target,out=None,extra=(),success=True):
 cmd=[str(pw),'-NoProfile','-File',str(P/'Patch.ps1'),'-IsoPath',str(src),'-Target',target]
 if out:cmd+=['-OutputPath',str(out)]
 cmd+=list(extra)
 r=subprocess.run(cmd,capture_output=True,text=True);(T/(str(len(list(T.glob('*.log'))))+'.log')).write_text(r.stdout+r.stderr)
 assert (r.returncode==0)==success,(cmd,r.stdout,r.stderr)
 return r
def part(path,off,n):
 with path.open('rb') as f:f.seek(off);return f.read(n)
def filehash(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def ok(s):print('PASS: '+s,flush=True)
# PowerShell parser and C# compile run on every invocation.
retail=T/'original_Korean_Xbox360_v12.iso'
run(original,'Xbox360')
assert retail.exists() and part(retail,xa,len(x))==x
assert sha(part(retail,l0,8388608))==m['patched_prefix_sha256']
assert original.stat().st_size==retail.stat().st_size==length
ok('clean -> retail: original XEX byte-exact, verified v1.2 translation prefix, automatic target filename')
content=T/'content';content.mkdir(exist_ok=True);sentinel=content/'untouched.dat';sentinel.write_bytes(b'KEEP-PROFILE')
xenia=T/'xenia.iso';run(original,'Xenia',xenia,['-ContentDirectory',str(content),'-AllowNoProfile'])
assert sha(part(xenia,xa,len(x)))==m['achievement_patch']['patched_sha256']
assert part(xenia,l0,8388608)==part(retail,l0,8388608)
ok('clean -> Xenia: existing achievement XEX retained; translated Layer0 identical to retail')
converted=T/'converted_retail.iso';run(xenia,'Xbox360',converted,['-ContentDirectory',str(content)])
rh=filehash(retail);assert filehash(converted)==rh and sentinel.read_bytes()==b'KEEP-PROFILE'
converted.unlink();ok('existing Xenia v1.2 -> retail: full ISO matches direct retail; supplied profile folder untouched')
back=T/'back_xenia.iso';run(retail,'Xenia',back,['-ContentDirectory',str(content),'-AllowNoProfile'])
assert filehash(back)==filehash(xenia);back.unlink();ok('retail -> Xenia round-trip: full ISO matches original Xenia build')
run(retail,'Xbox360');ok('retail rerun: verified ISO reused without copying')
run(original,'Xbox360',retail,success=False);run(original,'Xbox360',original,success=False)
ok('existing output and source overwrite rejected')
before=filehash(original)
assert part(original,xa,len(x))==x and part(original,l0,8388608)==clean
assert part(retail,length-128,18)==part(original,length-128,18)
ok('input ISO and unrelated tail bytes preserved')
(T/'results.txt').write_text('PASS clean->retail; clean->Xenia; Xenia->retail; retail->Xenia; rerun; overwrite rejection; input/profile preservation\nSynthetic ISO with genuine XEX and Layer0 prefix; Linux PowerShell 7.4.6. No Windows GUI or console gameplay test.\nRetail full SHA256: '+rh+'\nOriginal fixture SHA256: '+before+'\n')
