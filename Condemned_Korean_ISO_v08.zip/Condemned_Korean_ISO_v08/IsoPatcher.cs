// ISO container reader informed by Xenia's BSD-licensed disc_image_device.cc.
// This tool never opens the source ISO with write access.
using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;

namespace CondemnedKoreanISO {
    public sealed class Move {
        public int EntryOffset;
        public string OriginalEntryHex;
        public int SourceOffset;
        public int SourceSize;
        public int Destination;
        public int Size;
        public long RawSize;
        public string Payload;
        public string Sha256;
    }
    public sealed class Plan {
        public long OriginalSize;
        public int PrefixSize;
        public string OriginalHash;
        public string PatchedHash;
        public string XexHash;
        public int RegionStart;
        public int RegionEnd;
        public Move[] Moves;
    }
    public sealed class Result {
        public long IsoSize;
        public long PartitionOffset;
        public long Layer0Offset;
        public string SourceSha256;
        public string OutputSha256;
        public string OutputPath;
    }
    internal sealed class DiscEntry {
        public string Name;
        public long Offset;
        public long Length;
        public bool Directory;
    }
    public static class Patcher {
        static readonly long[] Bases = {0, 0xFB20, 0x20600, 0x2080000, 0xFD90000};
        static void Require(bool good, string message) {
            if (!good) throw new InvalidDataException(message);
        }
        static bool Equal(string a, string b) {
            return String.Equals(a, b, StringComparison.OrdinalIgnoreCase);
        }
        static string Hex(byte[] bytes) {
            return BitConverter.ToString(bytes).Replace("-", "").ToLowerInvariant();
        }
        static string Hash(byte[] bytes) {
            using (SHA256 sha = SHA256.Create()) return Hex(sha.ComputeHash(bytes));
        }
        static byte[] Read(Stream stream, long offset, int count) {
            Require(offset >= 0 && count >= 0 && offset <= stream.Length-count, "Read outside ISO bounds.");
            stream.Position = offset;
            byte[] bytes = new byte[count];
            int done = 0;
            while (done < count) {
                int n = stream.Read(bytes, done, count-done);
                if (n <= 0) throw new EndOfStreamException("Unexpected end of ISO.");
                done += n;
            }
            return bytes;
        }
        static uint LE32(byte[] b, int p) {
            return (uint)b[p] | ((uint)b[p+1]<<8) | ((uint)b[p+2]<<16) | ((uint)b[p+3]<<24);
        }
        static int LE16(byte[] b, int p) { return b[p] | (b[p+1]<<8); }
        static uint BE32(byte[] b, int p) {
            return ((uint)b[p]<<24) | ((uint)b[p+1]<<16) | ((uint)b[p+2]<<8) | b[p+3];
        }
        static void PutBE64(byte[] b, int p, long value) {
            Require(value >= 0, "Negative archive value.");
            for (int n=7; n>=0; n--) { b[p+n] = (byte)(value & 255); value >>= 8; }
        }
        static byte[] Slice(byte[] b, int p, int n) {
            Require(p >= 0 && n >= 0 && p <= b.Length-n, "Archive slice outside prefix.");
            byte[] result = new byte[n];
            Buffer.BlockCopy(b, p, result, 0, n);
            return result;
        }
        static bool Overlap(long a, long an, long b, long bn) {
            return an > 0 && bn > 0 && a < b+bn && b < a+an;
        }
        static List<DiscEntry> ReadRoot(Stream iso, long gameBase, byte[] descriptor) {
            long root = gameBase + (long)LE32(descriptor, 20)*2048;
            uint rootSize = LE32(descriptor, 24);
            Require(rootSize >= 14 && rootSize <= 32*1024*1024, "Invalid XDVDFS root size.");
            Require(root >= gameBase+65536+2048, "Invalid XDVDFS root location.");
            byte[] table = Read(iso, root, (int)rootSize);
            var entries = new List<DiscEntry>();
            var stack = new Stack<int>();
            var visited = new HashSet<int>();
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var recordRanges = new List<Tuple<int,int>>();
            stack.Push(0);
            while (stack.Count > 0) {
                int at = stack.Pop();
                Require(visited.Add(at), "Cycle or shared node in XDVDFS directory.");
                Require(at >= 0 && at <= table.Length-14, "XDVDFS directory pointer outside table.");
                int nameLength = table[at+13];
                Require(nameLength > 0 && at <= table.Length-14-nameLength, "Invalid XDVDFS filename.");
                for (int i=0; i<nameLength; i++) {
                    byte c = table[at+14+i];
                    Require(c >= 32 && c != 127 && c != '/' && c != '\\', "Invalid XDVDFS filename characters.");
                }
                recordRanges.Add(Tuple.Create(at, at+14+nameLength));
                string name = Encoding.ASCII.GetString(table, at+14, nameLength);
                Require(names.Add(name), "Duplicate XDVDFS filename.");
                long offset = gameBase + (long)LE32(table, at+4)*2048;
                long length = LE32(table, at+8);
                Require(offset >= gameBase && offset <= iso.Length-length, "XDVDFS file extent outside ISO.");
                Require(!Overlap(offset,length,root,rootSize) && !Overlap(offset,length,gameBase+65536,2048),
                    "XDVDFS file overlaps filesystem metadata.");
                entries.Add(new DiscEntry {Name=name, Offset=offset, Length=length, Directory=(table[at+12]&16)!=0});
                int left = LE16(table,at)*4;
                int right = LE16(table,at+2)*4;
                if (left != 0) stack.Push(left);
                if (right != 0) stack.Push(right);
            }
            recordRanges.Sort((a,b) => a.Item1.CompareTo(b.Item1));
            for (int i=1; i<recordRanges.Count; i++)
                Require(recordRanges[i-1].Item2 <= recordRanges[i].Item1, "Overlapping XDVDFS directory records.");
            return entries;
        }
        static DiscEntry Find(List<DiscEntry> files, string name) {
            foreach (DiscEntry f in files) if (Equal(f.Name,name) && !f.Directory) return f;
            return null;
        }
        static void CheckLayer1(Stream iso, DiscEntry layer) {
            Require(layer.Length >= 48, "Invalid Layer1 archive size.");
            byte[] h = Read(iso,layer.Offset,48);
            Require(Encoding.ASCII.GetString(h,0,4)=="RATL" && BE32(h,4)==3, "Unsupported Layer1 archive format.");
            uint ns = BE32(h,8), fc = BE32(h,16);
            Require(ns >= 1 && ns <= 16777216 && fc <= 1000000 && 48L+ns+32L*fc <= layer.Length,
                "Invalid Layer1 archive directory.");
            byte[] names = Read(iso,layer.Offset+48,(int)ns);
            byte[] table = Read(iso,layer.Offset+48+ns,(int)(fc*32));
            for (int i=0; i<(int)fc; i++) {
                uint at = BE32(table,i*32);
                Require(at < ns, "Invalid Layer1 name offset.");
                int end = Array.IndexOf(names,(byte)0,(int)at);
                Require(end >= 0, "Unterminated Layer1 filename.");
                string name = Encoding.ASCII.GetString(names,(int)at,end-(int)at);
                Require(!Equal(name,"assets.xzp") && !Equal(name,"font_pack.xpr") && !Equal(name,"DARK.Strdb00p"),
                    "Layer1 contains conflicting translation resources. This game edition requires analysis.");
            }
        }
        static byte[] BuildPrefix(byte[] original, string package, Plan plan) {
            Require(plan.RegionStart >= 48 && plan.RegionEnd <= original.Length && plan.RegionStart < plan.RegionEnd,
                "Invalid patch region.");
            byte[] patched = (byte[])original.Clone();
            Array.Clear(patched,plan.RegionStart,plan.RegionEnd-plan.RegionStart);
            var seenEntries = new HashSet<int>();
            foreach (Move m in plan.Moves) {
                Require(m.EntryOffset >= 48 && m.EntryOffset <= plan.RegionStart-32 && seenEntries.Add(m.EntryOffset),
                    "Invalid patch directory record.");
                Require(Equal(Hex(Slice(original,m.EntryOffset,32)),m.OriginalEntryHex), "Archive entry differs from patch plan.");
                Require(m.SourceOffset >= plan.RegionStart && m.SourceSize >= 0 && m.SourceOffset <= plan.RegionEnd-m.SourceSize,
                    "Invalid patch source range.");
                Require(m.Destination >= plan.RegionStart && m.Size >= 0 && m.Destination <= plan.RegionEnd-m.Size,
                    "Invalid patch destination range.");
                byte[] data;
                if (String.IsNullOrEmpty(m.Payload)) data = Slice(original,m.SourceOffset,m.SourceSize);
                else {
                    string path = Path.GetFullPath(Path.Combine(package,m.Payload.Replace('/',Path.DirectorySeparatorChar)));
                    string payloadRoot = Path.GetFullPath(Path.Combine(package,"payload"))+Path.DirectorySeparatorChar;
                    Require(path.StartsWith(payloadRoot,StringComparison.OrdinalIgnoreCase), "Invalid payload path.");
                    Require(new FileInfo(path).Length == m.Size, "Patch payload size mismatch. Extract the ZIP again.");
                    data = File.ReadAllBytes(path);
                }
                Require(data.Length==m.Size && Equal(Hash(data),m.Sha256), "Patch payload hash mismatch. Extract the ZIP again.");
                Buffer.BlockCopy(data,0,patched,m.Destination,m.Size);
                PutBE64(patched,m.EntryOffset+4,m.Destination);
                PutBE64(patched,m.EntryOffset+12,m.Size);
                PutBE64(patched,m.EntryOffset+20,m.RawSize);
            }
            Require(Equal(Hash(patched),plan.PatchedHash), "Patched archive prefix does not match the verified build.");
            return patched;
        }
        static string VerifyStream(Stream stream) {
            stream.Position=0;
            using (SHA256 sha=SHA256.Create()) {
                byte[] buffer=new byte[4*1024*1024];
                long total=0;
                int shown=-1, n;
                while ((n=stream.Read(buffer,0,buffer.Length))>0) {
                    sha.TransformBlock(buffer,0,n,buffer,0);
                    total+=n;
                    int percent=(int)(total*100/stream.Length);
                    if (percent/10 != shown) { shown=percent/10; Console.WriteLine("  Verify: "+percent+"%"); }
                }
                sha.TransformFinalBlock(new byte[0],0,0);
                return Hex(sha.Hash);
            }
        }
        public static Result Run(string sourcePath, string outputPath, string package, Plan plan, bool inspectOnly) {
            sourcePath=Path.GetFullPath(sourcePath);
            outputPath=Path.GetFullPath(outputPath);
            Require(!Equal(sourcePath,outputPath), "Source and output paths must be different.");
            Require(!File.Exists(outputPath) && !Directory.Exists(outputPath), "Output already exists. Choose another output name.");
            Require(plan.OriginalSize >= plan.PrefixSize && plan.PrefixSize==8388608, "Invalid patch manifest.");
            string temp=outputPath+".partial-"+Guid.NewGuid().ToString("N");
            bool created=false;
            try {
                using (FileStream source=new FileStream(sourcePath,FileMode.Open,FileAccess.Read,FileShare.Read)) {
                    DiscEntry layer0=null, layer1=null, xex=null;
                    long gameBase=0;
                    string lastError="No compatible XDVDFS game partition was found.";
                    foreach (long candidate in Bases) {
                        if (source.Length < candidate+65536+2048) continue;
                        byte[] descriptor=Read(source,candidate+65536,2048);
                        if (Encoding.ASCII.GetString(descriptor,0,20)!="MICROSOFT*XBOX*MEDIA") continue;
                        try {
                            List<DiscEntry> files=ReadRoot(source,candidate,descriptor);
                            DiscEntry l0=Find(files,"Layer0.Arch00"), l1=Find(files,"Layer1.Arch00"), exe=Find(files,"default.xex");
                            Require(l0!=null && l1!=null && exe!=null, "Condemned root files were not found in this partition.");
                            foreach (DiscEntry f in files) if (!Object.ReferenceEquals(f,l0))
                                Require(!Overlap(l0.Offset,l0.Length,f.Offset,f.Length), "Layer0 overlaps another ISO entry.");
                            Require(layer0==null, "Multiple Condemned game partitions were found.");
                            layer0=l0; layer1=l1; xex=exe; gameBase=candidate;
                        } catch (InvalidDataException ex) {
                            if (layer0!=null) throw;
                            lastError=ex.Message;
                        }
                    }
                    Require(layer0!=null,lastError);
                    Require(layer0.Length==plan.OriginalSize, "Layer0 size differs. Select a clean ISO of the supported game edition.");
                    Require(xex.Length>0 && xex.Length<=128*1024*1024, "Unsupported default.xex size.");
                    Require(Equal(Hash(Read(source,xex.Offset,(int)xex.Length)),plan.XexHash),
                        "default.xex differs from the supported game edition.");
                    byte[] original=Read(source,layer0.Offset,plan.PrefixSize);
                    string prefixHash=Hash(original);
                    Require(!Equal(prefixHash,plan.PatchedHash), "This ISO already contains Korean ISO v0.8. Select the original ISO.");
                    Require(Equal(prefixHash,plan.OriginalHash), "Layer0 contents differ. Select a clean original ISO.");
                    CheckLayer1(source,layer1);
                    byte[] patched=BuildPrefix(original,package,plan);
                    var result=new Result {IsoSize=source.Length,PartitionOffset=gameBase,Layer0Offset=layer0.Offset,OutputPath=outputPath};
                    Console.WriteLine("ISO structure, original resources and patch payloads verified.");
                    if (inspectOnly) return result;

                    // Preflight local free space; network filesystems may not report it.
                    long free=-1;
                    try { free=new DriveInfo(Path.GetPathRoot(outputPath)).AvailableFreeSpace; }
                    catch (IOException) {} catch (ArgumentException) {} catch (UnauthorizedAccessException) {}
                    Require(free<0 || free>=source.Length+16*1024*1024,
                        "Insufficient free space. The output needs the full ISO size plus 16 MiB.");
                    using (FileStream output=new FileStream(temp,FileMode.CreateNew,FileAccess.ReadWrite,FileShare.None))
                    using (SHA256 originalSha=SHA256.Create())
                    using (SHA256 patchedSha=SHA256.Create()) {
                        created=true;
                        byte[] buffer=new byte[4*1024*1024];
                        source.Position=0;
                        long pos=0;
                        int n, shown=-1;
                        Console.WriteLine("Creating a separate Korean ISO...");
                        while ((n=source.Read(buffer,0,buffer.Length))>0) {
                            originalSha.TransformBlock(buffer,0,n,buffer,0);
                            long low=Math.Max(pos,layer0.Offset);
                            long high=Math.Min(pos+n,layer0.Offset+patched.Length);
                            if (low<high) Buffer.BlockCopy(patched,(int)(low-layer0.Offset),buffer,(int)(low-pos),(int)(high-low));
                            patchedSha.TransformBlock(buffer,0,n,buffer,0);
                            output.Write(buffer,0,n);
                            pos+=n;
                            int percent=(int)(pos*100/source.Length);
                            if (percent/10!=shown) {shown=percent/10; Console.WriteLine("  Copy: "+percent+"%");}
                        }
                        Require(pos==result.IsoSize && output.Length==result.IsoSize,"ISO length changed during copying.");
                        originalSha.TransformFinalBlock(new byte[0],0,0);
                        patchedSha.TransformFinalBlock(new byte[0],0,0);
                        result.SourceSha256=Hex(originalSha.Hash);
                        result.OutputSha256=Hex(patchedSha.Hash);
                        output.Flush(true);
                        Console.WriteLine("Verifying the complete output ISO...");
                        Require(Equal(VerifyStream(output),result.OutputSha256),"Output ISO verification failed.");
                        Require(Equal(Hash(Read(output,layer0.Offset,plan.PrefixSize)),plan.PatchedHash),"Output prefix verification failed.");
                    }
                    File.Move(temp,outputPath); // Two-argument Move never overwrites an existing file.
                    created=false;
                    return result;
                }
            } finally {
                if (created) { try { File.Delete(temp); } catch {} }
            }
        }
    }
}
