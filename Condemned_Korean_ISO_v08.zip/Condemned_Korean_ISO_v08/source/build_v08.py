"""Build four reviewed dialogue corrections over v0.7, retaining every other asset.
Usage: python build_v08.py V07_UI V07_ISO REVIEW_JSON ORIGINAL_PREFIX OUTPUT_DIRECTORY
"""
from pathlib import Path
import hashlib, json, re, shutil, subprocess, sys, zlib

BASE, ISO_BASE, REVIEW, PREFIX, OUT = map(Path, sys.argv[1:6])
UI = OUT/'Condemned_Korean_UI_v08'
ISO = OUT/'Condemned_Korean_ISO_v08'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda b: hashlib.sha256(b).hexdigest()
def write(p, value):
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
def windows_text(p, text):
    p.write_bytes(b'\xef\xbb\xbf'+text.replace('\r\n','\n').replace('\n','\r\n').encode('utf-8'))

assert not UI.exists() and not ISO.exists(), 'Output packages must not already exist.'
shutil.copytree(BASE, UI, ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copytree(ISO_BASE, ISO, ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
fixes = read(REVIEW)['editorial_suggestions']
assert {(r['key'],r['offset']) for r in fixes} == {('M5_010',238752),('M5_040',256968),('M5_065',278092),('M8_018',112456)}
rows = read(UI/'gameplay_translations.json')
by_offset = {r['offset']:r for r in rows}
original = zlib.decompress((BASE/'payload/common_strings.bin').read_bytes())
data = bytearray(original)
allowed = bytearray(len(data))
for f in fixes:
    r = by_offset[f['offset']]
    assert r['korean']==f['current'] and r['source']==f['original']
    encoded = f['suggested'].encode('utf-16-be')
    size = r['slot_bytes']; p = r['offset']
    assert len(encoded)+2 <= size and size%4==0
    assert re.findall(r'<%[^>]+%>',f['suggested'])==re.findall(r'<%[^>]+%>',r['korean'])
    assert re.findall(r'<%time%>\s*[\d.]+',f['suggested'])==re.findall(r'<%time%>\s*[\d.]+',r['korean'])
    data[p:p+size] = encoded+b'\x20\x0b'*((size-len(encoded)-2)//2)+b'\0\0'
    allowed[p:p+size] = b'\1'*size
    r['korean'] = f['suggested']; f['applied'] = True
assert len(data)==len(original) and all(a==b or allowed[i] for i,(a,b) in enumerate(zip(original,data)))
(UI/'payload/common_strings.bin').write_bytes(zlib.compress(data,9))
write(UI/'gameplay_translations.json',rows)
write(UI/'translations_revised_v08.json',fixes)
mapping = read(UI/'ui_translations.json')
for r in fixes: mapping[r['original']]=r['suggested']
write(UI/'ui_translations.json',mapping)
manifest = read(UI/'manifest.json')
for t in manifest['targets']:
    blob = (UI/t['payload']).read_bytes()
    t.update(payload_size=len(blob),payload_sha256=sha(blob),raw_size=len(zlib.decompress(blob)))
write(UI/'manifest.json',manifest)
history=UI/'upgrade_v07';history.mkdir()
for name in ['Patch.ps1','manifest.json']: shutil.copyfile(BASE/name,history/name)
for name in ['Patch.ps1','Upgrade.ps1']:
    s = (BASE/name).read_text(encoding='utf-8-sig')
    s = s.replace('Korean_UI_v07','Korean_UI_v08').replace('KoreanUI_v07','KoreanUI_v08').replace("version='0.7'","version='0.8'").replace('v0.7','v0.8')
    if name=='Upgrade.ps1':
        assert "@('v06','v05','v04','v03','v02','v01')" in s
        s=s.replace("@('v06','v05','v04','v03','v02','v01')","@('v07','v06','v05','v04','v03','v02','v01')")
    windows_text(UI/name,s)
report = read(UI/'build_report.json')
report.update(version='0.8',common_fixed_sha256=sha(data),common_string_changes=rows,
    runtime_tested=False,v08_revised_count=4,
    installer_validation='Pending v07 -> v08 fixture validation; see source/verification_v08.txt after release.',
    v08_scope='Exactly four dialogue slots changed; shoeprint dialogue, loading hints, font and UI assets preserved byte-exactly.')
write(UI/'build_report.json',report)
shutil.copyfile(__file__,UI/'source/build_v08.py')
write(UI/'source/review_input_v08.json',read(REVIEW))

s=(ISO_BASE/'source/build_iso_v07.py').read_text()
s=s.replace('v0.7','v0.8').replace('v07','v08').replace('V07','V08').replace("version='0.7-ISO'","version='0.8-ISO'")
builder=OUT/'build_iso_v08.py';builder.parent.mkdir(parents=True,exist_ok=True);builder.write_text(s)
subprocess.run([sys.executable,str(builder),str(UI),str(PREFIX),str(ISO)],check=True)
for name in ['PatchISO.ps1','IsoPatcher.cs']:
    s=(ISO_BASE/name).read_text(encoding='utf-8-sig').replace('v07','v08').replace('0.7','0.8')
    if name.endswith('.ps1'):windows_text(ISO/name,s)
    else:(ISO/name).write_text(s,encoding='utf-8')

s=(BASE/'source/test_installer_v07.py').read_text()
s=s.replace('v07','v08').replace('v06','v07').replace('V06','V07')
s=s.replace('import hashlib,json,os,shutil,struct,subprocess,sys,zipfile','import hashlib,json,os,shutil,struct,subprocess,sys,zipfile,zlib')
needle="run(FIX/P.name/'Upgrade.ps1')"
insert="""# Check the actually installed v0.7 data before upgrading.
b=(game/'Layer0.Arch00').read_bytes()
for t in json.loads((BASE/'manifest.json').read_text())['targets']:
    if t['index'] not in (11,12): continue
    _,off,cs,us,flag=struct.unpack_from('>IQQQI',b,t['entry_offset'])
    raw=zlib.decompress(b[off:off+cs]); p=325192; end=p
    while raw[end:end+2]!=b'\\0\\0': end+=2
    assert raw[p:end].decode('utf-16-be').rstrip('\\u200b')=='근접 무기를 휘두른 직후에 맞춰 발차기를 하세요.'
print('PASS: v0.7 installed loading tip #6 is Korean in both DB records (data check, not gameplay).')
"""
assert s.count(needle)==1;s=s.replace(needle,insert+needle)
(UI/'source/test_installer_v08.py').write_text(s,encoding='utf-8')

common='''이번 변경 (2026-09-30)
- M5_010: “괜찮아?” 대사의 말투를 주변 로사 대사와 맞춰 존댓말로 정리했습니다.
- M5_040: “훌륭해.” → “훌륭해요.”
- M5_065: “조명 끄기” → “불을 꺼요.”
- M8_018: 빠졌던 책임 부정의 뜻을 “하지만 그 애 책임은 아니야.”로 보완했습니다.
자막 페이지·시간 태그, 문자열 위치와 크기는 유지했습니다.
신발자국 분석 대사와 그 밖의 대사는 v0.7 그대로입니다.
폰트와 UI 리소스도 v0.7과 동일합니다.

오른쪽 아래 로딩 팁 확인
사진의 “Time your kicks carefully for just after a swing of a melee weapon.”는
IDS_LOADSCREEN_HINT_6이며, v0.4에서 번역되어 v0.7과 v0.8에도 포함되어 있습니다.
번역: “근접 무기를 휘두른 직후에 맞춰 발차기를 하세요.”
로딩 팁 43개 키 모두 번역 데이터가 있습니다.
이것은 데이터 확인 결과입니다. Xenia에서 실제 같은 화면을 재현한 결과는 아닙니다.
적용 후에도 영어라면, 새 ISO/패치한 폴더를 실제로 실행했는지 먼저 확인하고
새 로딩 화면과 .patch-info.txt(ISO) 또는 .state.json(폴더) 파일을 보내 주세요.

검수 범위
source/verification_v08.txt에 이번 검증 결과와 한계를 기록했습니다.
테스트용 이미지의 설치·데이터 검사는 실제 게임 플레이 검수와 다릅니다.
Xenia 부팅, 로딩 팁의 화면 표시, 줄바꿈, 음성 싱크, 엔딩까지의 플레이는 미검증입니다.
source의 v0.7 이하 기록은 과거 버전의 검증 기록입니다.
'''
ui_readme='''컨뎀드 Xbox 360 한글화 v0.8 — 대사 검수 수정
한글화: 슬림쉐이디

설치 및 업데이트
1. 게임과 Xenia를 완전히 종료합니다.
2. Condemned_Korean_UI_v08 폴더를 default.xex, Layer0.Arch00와 나란히 놓습니다.
3. 새 폴더 안의 RUN_FIX.bat를 실행합니다. 깨끗한 원본에도 같은 파일을 사용합니다.
4. FIX APPLIED를 확인한 뒤 그 게임 폴더의 default.xex를 실행합니다.
   Xenia 콘솔 언어는 English 또는 Korean으로 설정합니다.
기존 v0.1~v0.7의 정상 .bak와 .state.json이 있으면 검증·복원 후 업데이트합니다.
이전 백업과 설치 기록을 지우거나 이름을 바꾸지 마세요.
약 1.6GB 이상의 여유 공간이 필요하며, 작업 중 창을 닫지 마세요.
ISO 패치판에서 추출한 폴더에는 이 업데이트를 적용하지 말고 깨끗한 원본을 사용하세요.

원본 복원
게임과 Xenia를 종료한 뒤 v0.8 폴더의 RUN_RESTORE.bat를 실행합니다.
백업: Layer0.Arch00.pre_KoreanUI_v08.bak
설치 기록: Condemned_KoreanUI_v08.state.json

'''+common+'''
원본 게임 파일은 포함하지 않습니다.
Windows PowerShell용 설치기입니다. FONT_LICENSE.txt와 XENIA_LICENSE.txt를 참고하세요.
font_preview.png는 글꼴 견본이며 실제 게임 화면이 아닙니다.
'''
windows_text(UI/'README_KR.txt',ui_readme)
s=(ISO_BASE/'README_KR.txt').read_text(encoding='utf-8-sig')
s=s.replace('v0.7','v0.8').replace('v07','v08').replace('0.1~0.7','0.1~0.8')
s=s.replace('현재 만족하신 v0.8의 번역·한글 폰트·UI 리소스를 그대로 사용합니다.','v0.7을 바탕으로 위 대사 4곳을 수정했습니다. 한글 폰트·UI 리소스는 동일합니다.')
s=s.replace('무엇이 들어 있나요?','v0.7 ISO 사용자의 업데이트\n패치하지 않은 원본 ISO에 v0.8을 적용해 새 ISO를 만들어 주세요.\nv0.7 패치 ISO에 덧씌우는 방식은 지원하지 않습니다.\n\n'+common+'\n무엇이 들어 있나요?')
windows_text(ISO/'README_KR.txt',s)
notes='''# v0.8 dialogue review

Only the four slots in translations_revised_v08.json differ from v0.7.
Shoeprint analysis strings, loading hints, font and UI assets are byte-identical.
The screenshot tip is IDS_LOADSCREEN_HINT_6 (offset 325192), already Korean since v0.4.
Runtime display and a full playthrough remain unverified.

Build: source/build_v08.py takes v07 UI, v07 ISO, review_input_v08.json, the user's original 8MiB Layer0 prefix, and a new output directory.
The ISO relocation builder is source/build_iso_v08.py.
Historical verification files refer to their named versions only.
Current test results are in source/verification_v08.txt.
'''
for p in [UI,ISO]:(p/'source/NOTES_v08.md').write_text(notes,encoding='utf-8')
print(json.dumps({'version':'0.8','changed_dialogue_slots':len(fixes),'common_raw_sha256':sha(data)},indent=2))
