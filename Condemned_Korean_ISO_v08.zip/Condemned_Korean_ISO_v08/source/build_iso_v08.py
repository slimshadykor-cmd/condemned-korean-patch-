"""Build a same-size Layer0 prefix relocation plan from the verified v0.8 package.
No original game data is stored in the generated package.
Usage: python build_iso_v08.py UI_V08_PACKAGE ORIGINAL_8MB_PREFIX OUTPUT_PACKAGE
"""
from pathlib import Path
import hashlib, json, shutil, struct, sys, zlib

base, prefix_path, out = map(Path, sys.argv[1:4])
sha = lambda b: hashlib.sha256(b).hexdigest()
m = json.loads((base / 'manifest.json').read_text(encoding='utf-8-sig'))
old = prefix_path.read_bytes()
assert len(old) == m['prefix_size'] and sha(old) == m['original_prefix_sha256']
assert old[:8] == b'RATL\0\0\0\3'
ns, folders, files = struct.unpack_from('>III', old, 8)
table = 48 + ns
entries = [struct.unpack_from('>IQQQI', old, table + 32*i) for i in range(files)]
start, end = 85448, 6669716
selected = sorted((e[1], i) for i, e in enumerate(entries) if e[2] and start <= e[1] < end)
cursor = start
for offset, i in selected:
    assert offset == cursor
    cursor += entries[i][2]
assert cursor == end and len(selected) == 25
for i, (_, offset, size, _, _) in enumerate(entries):
    if size and i not in {i for _, i in selected}:
        assert offset + size <= start or offset >= end

out.mkdir(parents=True, exist_ok=True)
(out/'payload').mkdir(exist_ok=True)
(out/'source').mkdir(exist_ok=True)
new = bytearray(old)
new[start:end] = bytes(end-start)
targets = {t['index']: t for t in m['targets']}
moves = []
payload_positions = {}
cursor = start
for original_offset, i in selected:
    entry_offset = table + i*32
    name, _, size, raw_size, flag = entries[i]
    target = targets.get(i)
    if target:
        payload_name = target['payload']
        data = (base/payload_name).read_bytes()
        assert sha(data) == target['payload_sha256'] and len(data) == target['payload_size']
        raw_size = target['raw_size']
        assert len(zlib.decompress(data)) == raw_size
        shutil.copyfile(base/payload_name, out/payload_name)
    else:
        payload_name = ''
        data = old[original_offset:original_offset+size]
    # The original archive already uses byte-granular offsets. Align new data
    # conservatively to 16 bytes; both identical locale records share one blob.
    if payload_name and payload_name in payload_positions:
        destination = payload_positions[payload_name]
    else:
        destination = (cursor+15)//16*16
        cursor = destination + len(data)
        if payload_name:
            payload_positions[payload_name] = destination
    assert cursor <= end
    new[destination:destination+len(data)] = data
    struct.pack_into('>QQQ', new, entry_offset+4, destination, len(data), raw_size)
    moves.append(dict(index=i, entry_offset=entry_offset,
        original_entry_hex=old[entry_offset:entry_offset+32].hex(),
        source_offset=original_offset, source_size=size,
        destination=destination, size=len(data), raw_size=raw_size,
        payload=payload_name, sha256=sha(data)))

# Every untouched resource and directory record must survive byte-exactly.
changed_headers = {table+32*i for _, i in selected}
for i, original in enumerate(entries):
    no, offset, size, raw_size, flag = struct.unpack_from('>IQQQI', new, table+32*i)
    assert no == original[0] and flag == original[4]
    if i in targets:
        assert new[offset:offset+size] == (base/targets[i]['payload']).read_bytes()
    elif original[1]+original[2] <= len(old):
        assert new[offset:offset+size] == old[original[1]:original[1]+original[2]], i
    if table+32*i not in changed_headers:
        assert (no, offset, size, raw_size, flag) == original
expected_header = bytearray(old[:start])
for row in moves:
    p = row['entry_offset']
    expected_header[p:p+32] = new[p:p+32]
assert new[:start] == expected_header
assert new[end:] == old[end:]
manifest = dict(format_version=1, version='0.8-ISO', archive_name=m['archive_name'],
    original_size=m['original_size'], prefix_size=m['prefix_size'],
    original_prefix_sha256=m['original_prefix_sha256'],
    patched_prefix_sha256=sha(new), xex_sha256=m['xex_sha256'],
    region_start=start, region_end=end, unused_bytes=end-cursor, moves=moves)
(out/'iso_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8')
for filename in ['XENIA_LICENSE.txt', 'FONT_LICENSE.txt']:
    if (base/filename).exists(): shutil.copyfile(base/filename, out/filename)
shutil.copyfile(__file__, out/'source/build_iso_v08.py')
print(json.dumps(dict(relocated_records=len(moves), unused_bytes=end-cursor,
    original_size=m['original_size'], patched_prefix_sha256=sha(new)), indent=2))
