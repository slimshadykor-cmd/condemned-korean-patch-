# v0.8 dialogue review

Only the four slots in translations_revised_v08.json differ from v0.7.
Shoeprint analysis strings, loading hints, font and UI assets are byte-identical.
The screenshot tip is IDS_LOADSCREEN_HINT_6 (offset 325192), already Korean since v0.4.
Runtime display and a full playthrough remain unverified.

Build: source/build_v08.py takes v07 UI, v07 ISO, review_input_v08.json, the user's original 8MiB Layer0 prefix, and a new output directory.
The ISO relocation builder is source/build_iso_v08.py.
Historical verification files refer to their named versions only.
Current test results are in source/verification_v08.txt.
