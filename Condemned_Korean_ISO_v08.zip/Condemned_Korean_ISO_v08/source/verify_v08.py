from pathlib import Path
import collections, hashlib, json, re, struct, zlib

import sys
# python verify_v08.py V07_UI V08_UI V08_ISO ORIGINAL_DB ORIGINAL_PREFIX
BASE,UI,ISO,DB,PREFIX=map(Path,sys.argv[1:6])
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
u32=lambda b,p:struct.unpack_from('>I',b,p)[0]
u16=lambda b,p:struct.unpack_from('>H',b,p)[0]
old=DB.read_bytes()
new=zlib.decompress((ISO/'payload/common_strings.bin').read_bytes())
translations=read(UI/'gameplay_translations.json')
changes={r['offset']:r for r in translations}
assert len(changes)==len(translations)==2091
assert old[:8]==b'BDKS\0\0\0\3'
count=u32(old,8);table=24+u32(old,20)
assert table+count*8==len(old)==len(new)
names=[];p=24
for _ in range(count):
    end=old.index(0,p);names.append(old[p:end].decode('latin1'));p=(end+4)&~3
assert p==0x17548
pairs=[struct.unpack_from('>II',old,table+i*8) for i in range(count)]
assert old[:p]==new[:p] and old[table:]==new[table:]
value_count=max(x[0] for x in pairs)+1
def get_values(b):
    p=0x17548;result=[]
    for _ in range(value_count):
        end=p
        while end+2<=len(b) and b[end:end+2]!=b'\0\0':end+=2
        result.append((p,b[p:end].decode('utf-16-be')));p=(end+5)&~3
    return result,p
A,endA=get_values(old);B,endB=get_values(new)
assert endA==endB and old[endA:]==new[endB:]
assert [x[0] for x in A]==[x[0] for x in B]
allowed=bytearray(len(old));exceptions={x['offset'] for x in read(UI/'source/literal_input_tag_allowlist_v06.json')}
tokens=r'<%[^>]+%>|%\d+![^!]+!|%(?:\.\d+)?[sdf]|%%|<\?>'
input_token=r'<%(?:action|flashlight|tools|fire|ammocheck|togglemelee|sprint|taser|kick|block|pause|aim|move)%>'
paged=0
for (off,source),(_,target) in zip(A,B):
    if off not in changes:
        assert source==target
        assert not ('<%page%>' in source or '<%time%>' in source)
        continue
    row=changes[off]
    assert source==row['source']
    assert target.rstrip('\u200b')==row['korean'] and row['korean'].strip()
    src_tokens=re.findall(tokens,source)
    if off in exceptions:src_tokens=[t for t in src_tokens if not re.fullmatch(input_token,t)]
    assert src_tokens==re.findall(tokens,row['korean'])
    assert re.findall(r'<%time%>\s*[\d.]+',source)==re.findall(r'<%time%>\s*[\d.]+',row['korean'])
    assert not re.search(input_token,row['korean'])
    allowed[off:off+row['slot_bytes']]=b'\1'*row['slot_bytes']
    paged+=('<%page%>' in source or '<%time%>' in source)
assert all(a==b or allowed[i] for i,(a,b) in enumerate(zip(old,new)))
assert all(off in {a[0] for a in A} for off in changes)
keyed=[]
for name,(idx,voice) in zip(names,pairs):
    off,source=A[idx];target=B[idx][1].rstrip('\u200b')
    keyed.append(dict(key=name,index=idx,offset=off,source=source,korean=target,translated=off in changes,voice_index=voice))
hints=sorted([r for r in keyed if r['key'].startswith('IDS_LOADSCREEN_HINT_')],key=lambda r:int(r['key'].rsplit('_',1)[1]))
assert len(hints)==43 and all(r['translated'] for r in hints)
font=zlib.decompress((ISO/'payload/korean_font.bin').read_bytes())
maxc=u16(font,0x88);cmap=struct.unpack_from('>'+str(maxc+1)+'H',font,0x8a)
for row in translations:
    for ch in row['korean']:
        assert ch.isspace() or (ord(ch)<=maxc and cmap[ord(ch)]>0),(row['offset'],ch)
prefix=PREFIX.read_bytes()
def archive_resource(index):
    pos=48+u32(prefix,8)+index*32
    _,off,size,raw_size,_=struct.unpack_from('>IQQQI',prefix,pos)
    raw=zlib.decompress(prefix[off:off+size]);assert len(raw)==raw_size
    return raw
assert archive_resource(11)==archive_resource(12)==old
oldfont=archive_resource(770)
gb=0x8a+(maxc+1)*2;oldgb=0x8a+(u16(oldfont,0x88)+1)*2
assert u32(oldfont,oldgb)==325 and font[gb+4:gb+4+325*16]==oldfont[oldgb+4:oldgb+4+325*16]
for t in read(UI/'manifest.json')['targets']:
    b=(ISO/t['payload']).read_bytes()
    assert len(b)==t['payload_size'] and sha(b)==t['payload_sha256']
    assert len(zlib.decompress(b))==t['raw_size']
def assets(b):
    assert b[:4]==b'XUIZ' and u32(b,8)==len(b)
    start=22+u32(b,16);p=22;rows=[]
    for _ in range(u16(b,20)):
        size,off,n=struct.unpack_from('>IIB',b,p)
        name=b[p+9:p+9+n*2].decode('utf-16-be');p+=9+n*2
        rows.append((name,start+off,size))
    assert p==start
    return {name:b[off:off+size] for name,off,size in rows}
def xus(b):
    assert b[:6]==b'XUIS\1\0' and u32(b,6)==len(b)
    p=12;result={}
    for _ in range(u16(b,10)):
        pair=[]
        for _ in range(2):
            n=u16(b,p);p+=2;pair.append(b[p:p+n*2].decode('utf-16-be'));p+=n*2
        assert pair[1] not in result;result[pair[1]]=pair[0]
    assert p==len(b)
    return result
aa=assets(zlib.decompress((ISO/'payload/ui_assets.bin').read_bytes()))
ui_count=0;ui_missing=set();residual=[]
for name,b in aa.items():
    if not name.startswith(('en-US\\','ko-kR\\')) or not name.endswith('.xus'):continue
    rows=xus(b);ui_count+=1
    for key,value in rows.items():
        if not key.endswith('.Text'):continue
        if re.search('[가-힣]',value):
            for ch in value:
                if not ch.isspace() and (ord(ch)>maxc or cmap[ord(ch)]==0):ui_missing.add(ch)
        elif re.search('[A-Za-z]',value):residual.append(dict(resource=name,key=key,text=value))
assert not ui_missing
for locale in ['en-US','ko-kR']:
    rows=xus(aa[locale+'\\E3LoadScreen.xus'])
    assert rows['XuiScene1.HintText.Text']==''
    assert rows['XuiScene1.HintText.PointSize']=='20.000000'
campaign=[r for r in keyed if re.match(r'(M\d|XV_|hint\d|HINTTEXT|IDS_LOADSCREEN)',r['key'],re.I)]
missing=[r for r in campaign if re.search('[A-Za-z]{2}',r['source']) and r['source'].strip() not in ['<empty>','<unused>'] and not r['translated']]
assert not missing

# Independent comparison with the prior release; no collateral dialogue changes.
previous=zlib.decompress((BASE/'payload/common_strings.bin').read_bytes())
prior_values,prior_end=get_values(previous)
revisions=read(UI/'translations_revised_v08.json')
expected={r['offset'] for r in revisions}
assert expected=={238752,256968,278092,112456}
actual={a[0] for a,b in zip(prior_values,B) if a!=b}
assert actual==expected
mask=bytearray(len(new))
for r in revisions:
    off=r['offset']; n=changes[off]['slot_bytes'];mask[off:off+n]=b'\1'*n
    assert changes[off]['korean']==r['suggested'] and r['applied']
assert all(a==b or mask[i] for i,(a,b) in enumerate(zip(previous,new)))
for off in [388840,269116,389196,389968]:
    n=changes[off]['slot_bytes'];assert previous[off:off+n]==new[off:off+n]
for name in ['korean_font.bin','ui_assets.bin']:
    assert (BASE/'payload'/name).read_bytes()==(UI/'payload'/name).read_bytes()==(ISO/'payload'/name).read_bytes()
assert (UI/'payload/common_strings.bin').read_bytes()==(ISO/'payload/common_strings.bin').read_bytes()
for name in ['Patch.ps1','manifest.json']:
    assert (BASE/name).read_bytes()==(UI/'upgrade_v07'/name).read_bytes()
for old_version in range(1,7):
    for name in ['Patch.ps1','manifest.json']:
        rel=Path('upgrade_v0'+str(old_version))/name
        assert (BASE/rel).read_bytes()==(UI/rel).read_bytes()
for name in ['Patch.ps1','Upgrade.ps1']:
    normalized=(UI/name).read_text(encoding='utf-8-sig').replace('Korean_UI_v08','Korean_UI_v07').replace('KoreanUI_v08','KoreanUI_v07').replace("version='0.8'","version='0.7'").replace('v0.8','v0.7')
    if name=='Upgrade.ps1':normalized=normalized.replace("@('v07','v06','v05','v04','v03','v02','v01')","@('v06','v05','v04','v03','v02','v01')")
    assert normalized==(BASE/name).read_text(encoding='utf-8-sig')
for hint in hints:
    assert dict(prior_values)[hint['offset']].rstrip('\u200b')==hint['korean']
tip=next(x for x in hints if x['key']=='IDS_LOADSCREEN_HINT_6')
assert tip['source']=='Time your kicks carefully for just after a swing of a melee weapon.'
assert tip['korean']=='근접 무기를 휘두른 직후에 맞춰 발차기를 하세요.'
assert any(r['offset']==tip['offset'] and r['korean']==tip['korean'] for r in read(BASE/'translations_added_v04.json'))
print(json.dumps(dict(status='PASS',translated_slots=len(translations),mapped_keys=count,
    changed_slots=sorted(actual),loading_hints=len(hints),loading_tip=tip,
    shoeprint_and_all_other_dialogue='byte-identical to v0.7',font_and_ui='byte-identical to v0.7',
    glyph_coverage='PASS',tokens_timing_offsets='PASS',folder_installer_logic='unchanged except version paths and v07 upgrade recognition',
    original_db_sha256=sha(old),v07_db_sha256=sha(previous),v08_db_sha256=sha(new),runtime_tested=False),ensure_ascii=False,indent=2))
