﻿param(
    [string]$IsoPath = '',
    [string]$OutputPath = '',
    [switch]$InspectOnly
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$package = Split-Path -Parent $MyInvocation.MyCommand.Path
try {
    Write-Host 'Condemned 한글 ISO 패치 v0.8 / 한글화: 슬림쉐이디' -ForegroundColor Cyan
    Write-Host '원본 ISO를 보존하고 별도의 한글 ISO를 만듭니다.'
    if ([string]::IsNullOrWhiteSpace($IsoPath)) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.OpenFileDialog
        try {
            $dialog.Title = '패치하지 않은 Condemned 원본 ISO를 선택하세요'
            $dialog.Filter = 'Xbox 360 ISO (*.iso)|*.iso|모든 파일 (*.*)|*.*'
            $dialog.CheckFileExists = $true
            if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
                Write-Host '취소했습니다. 변경된 파일이 없습니다.'
                exit 0
            }
            $IsoPath = $dialog.FileName
        } finally { $dialog.Dispose() }
    }
    $IsoPath = [IO.Path]::GetFullPath($IsoPath)
    if ([string]::IsNullOrWhiteSpace($OutputPath)) {
        $OutputPath = Join-Path ([IO.Path]::GetDirectoryName($IsoPath)) ([IO.Path]::GetFileNameWithoutExtension($IsoPath)+'_Korean_v08.iso')
    }
    $OutputPath = [IO.Path]::GetFullPath($OutputPath)
    Write-Host ('원본: '+$IsoPath)
    Write-Host ('출력: '+$OutputPath)
    Write-Host '완료 메시지가 나올 때까지 창을 닫지 마세요. 복사 후 전체 파일을 다시 검사합니다.'

    $manifest = Get-Content -LiteralPath (Join-Path $package 'iso_manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.format_version -ne 1 -or $manifest.version -ne '0.8-ISO') { throw 'Unsupported patch manifest.' }
    Add-Type -TypeDefinition ([IO.File]::ReadAllText((Join-Path $package 'IsoPatcher.cs'),[Text.Encoding]::UTF8)) -Language CSharp
    $plan = New-Object CondemnedKoreanISO.Plan
    $plan.OriginalSize = [long]$manifest.original_size
    $plan.PrefixSize = [int]$manifest.prefix_size
    $plan.OriginalHash = $manifest.original_prefix_sha256
    $plan.PatchedHash = $manifest.patched_prefix_sha256
    $plan.XexHash = $manifest.xex_sha256
    $plan.RegionStart = [int]$manifest.region_start
    $plan.RegionEnd = [int]$manifest.region_end
    $moves = New-Object 'System.Collections.Generic.List[CondemnedKoreanISO.Move]'
    foreach ($r in $manifest.moves) {
        $m = New-Object CondemnedKoreanISO.Move
        $m.EntryOffset = [int]$r.entry_offset
        $m.OriginalEntryHex = $r.original_entry_hex
        $m.SourceOffset = [int]$r.source_offset
        $m.SourceSize = [int]$r.source_size
        $m.Destination = [int]$r.destination
        $m.Size = [int]$r.size
        $m.RawSize = [long]$r.raw_size
        $m.Payload = $r.payload
        $m.Sha256 = $r.sha256
        $moves.Add($m)
    }
    $plan.Moves = $moves.ToArray()
    $result = [CondemnedKoreanISO.Patcher]::Run($IsoPath,$OutputPath,$package,$plan,[bool]$InspectOnly)
    if ($InspectOnly) {
        Write-Host '검사 통과: 이 ISO에 패치를 적용할 수 있습니다. 파일은 만들지 않았습니다.' -ForegroundColor Green
    } else {
        Write-Host '완료! 한글 ISO를 만들고 파일 검사를 마쳤습니다.' -ForegroundColor Green
        Write-Host ('생성된 파일: '+$OutputPath)
        Write-Host 'Xenia에서 생성된 ISO를 열어 주세요. 콘솔 언어는 English 또는 Korean으로 설정하세요.'
        Write-Host '원본 ISO와 세이브 파일은 변경하지 않았습니다.'
        $report = @(
            'Condemned Korean ISO v0.8',
            ('Created: '+[DateTime]::UtcNow.ToString('o')),
            ('Source: '+$IsoPath), ('Output: '+$OutputPath),
            ('ISO bytes: '+$result.IsoSize),
            ('Partition offset: '+$result.PartitionOffset),
            ('Layer0 offset: '+$result.Layer0Offset),
            ('Source SHA256: '+$result.SourceSha256),
            ('Output SHA256: '+$result.OutputSha256),
            ('Patched Layer0 prefix SHA256: '+$plan.PatchedHash),
            'Full output hash verified. Full in-game playthrough is NOT verified.'
        ) -join [Environment]::NewLine
        try {
            $reportPath = $OutputPath+'.patch-info.txt'
            $reportStream = [IO.File]::Open($reportPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
            try {
                $bytes = [Text.Encoding]::UTF8.GetBytes($report)
                $reportStream.Write($bytes,0,$bytes.Length)
            } finally { $reportStream.Dispose() }
        } catch { Write-Host 'ISO 생성은 완료됐습니다. 검사 기록 파일은 저장하지 못했습니다.' -ForegroundColor Yellow }
    }
    exit 0
} catch {
    $message = $_.Exception.Message
    if ($_.Exception.InnerException) { $message = $_.Exception.InnerException.Message }
    Write-Host '패치를 완료하지 못했습니다. 원본 ISO는 변경하지 않았습니다.' -ForegroundColor Red
    Write-Host $message -ForegroundColor Red
    $log = ('UTC: '+[DateTime]::UtcNow.ToString('o'))+[Environment]::NewLine+$message
    try { [IO.File]::WriteAllText((Join-Path $package 'iso_patch_error.txt'),$log,[Text.Encoding]::UTF8) } catch {}
    Write-Host '오류가 계속되면 iso_patch_error.txt 또는 이 화면을 보내 주세요.'
    exit 1
}
